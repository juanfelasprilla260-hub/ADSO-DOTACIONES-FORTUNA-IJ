// Fichas técnicas de producción extraídas de Materiales_y_Tiempos_UnificadosV2
// Consumo de materia prima y tiempos de fabricación por prenda (talla M/default)

export interface MaterialConsumo {
  material: string;
  unidad: string;
  consumoXPrenda: number;
}

export interface ProcesoTiempo {
  proceso: string;
  minutosXPrenda: number;
}

export interface FichaTecnica {
  nombre: string;
  keywords: string[];          // palabras clave para matching con nombre del pedido
  talla: string;               // talla de referencia
  materiales: MaterialConsumo[];
  procesos: ProcesoTiempo[];
  tiempoTotalXPrenda: number;
}

const DEFAULT_PROCESOS: ProcesoTiempo[] = [
  { proceso: 'Corte',             minutosXPrenda: 12 },
  { proceso: 'Confección',        minutosXPrenda: 40 },
  { proceso: 'Acabados',          minutosXPrenda: 10 },
  { proceso: 'Control de Calidad',minutosXPrenda:  8 },
  { proceso: 'Empaque',           minutosXPrenda:  5 },
];
const DEFAULT_TOTAL = 75;

export const FICHAS_TECNICAS: FichaTecnica[] = [
  {
    nombre: 'Camisa Empresarial',
    keywords: ['camisa empresa', 'uniforme admin', 'uniforme empresa', 'camisa manga'],
    talla: 'M',
    materiales: [
      { material: 'Tela Oxford',  unidad: 'Metro',  consumoXPrenda: 1.4 },
      { material: 'Hilo',         unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',      unidad: 'Unidad', consumoXPrenda: 8   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 10 },
      { proceso: 'Confección',         minutosXPrenda: 35 },
      { proceso: 'Acabados',           minutosXPrenda: 10 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 65,
  },
  {
    nombre: 'Pantalón Industrial',
    keywords: ['pantalon industrial', 'pantalón industrial', 'pantalon drill', 'pantalon trabajo'],
    talla: '32',
    materiales: [
      { material: 'Dril Industrial', unidad: 'Metro',  consumoXPrenda: 1.5 },
      { material: 'Hilo',            unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Cremallera',      unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',         unidad: 'Unidad', consumoXPrenda: 1   },
    ],
    procesos: DEFAULT_PROCESOS,
    tiempoTotalXPrenda: DEFAULT_TOTAL,
  },
  {
    nombre: 'Chaqueta Reflectiva',
    keywords: ['chaqueta reflectiv', 'chaqueta seguridad', 'chaqueta impermeable', 'parka impermeable'],
    talla: 'L',
    materiales: [
      { material: 'Tela Reflectiva',  unidad: 'Metro',  consumoXPrenda: 2.0 },
      { material: 'Cinta Reflectiva', unidad: 'Metro',  consumoXPrenda: 2.2 },
      { material: 'Cremallera',       unidad: 'Unidad', consumoXPrenda: 1   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 20 },
      { proceso: 'Confección',         minutosXPrenda: 60 },
      { proceso: 'Acabados',           minutosXPrenda: 15 },
      { proceso: 'Control de Calidad', minutosXPrenda: 10 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 110,
  },
  {
    nombre: 'Overol Industrial',
    keywords: ['overol', 'overall', 'mameluco', 'uniforme industrial', 'conjunto reflectivo'],
    talla: 'L',
    materiales: [
      { material: 'Dril Industrial', unidad: 'Metro',  consumoXPrenda: 2.8 },
      { material: 'Cremallera',      unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Hilo',            unidad: 'Unidad', consumoXPrenda: 2   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 25 },
      { proceso: 'Confección',         minutosXPrenda: 90 },
      { proceso: 'Acabados',           minutosXPrenda: 20 },
      { proceso: 'Control de Calidad', minutosXPrenda: 10 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 150,
  },
  {
    nombre: 'Bata Médica',
    keywords: ['bata', 'medica', 'médica', 'laboratorio', 'uniforme salud'],
    talla: 'M',
    materiales: [
      { material: 'Tela Antifluido', unidad: 'Metro',  consumoXPrenda: 1.7 },
      { material: 'Hilo',           unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',        unidad: 'Unidad', consumoXPrenda: 6   },
    ],
    procesos: DEFAULT_PROCESOS,
    tiempoTotalXPrenda: DEFAULT_TOTAL,
  },
  {
    nombre: 'Chaleco de Seguridad',
    keywords: ['chaleco', 'vest', 'chaleco reflectivo', 'chaleco alta visibilidad', 'chaleco seguridad'],
    talla: 'M',
    materiales: [
      { material: 'Tela Reflectiva',  unidad: 'Metro', consumoXPrenda: 1.0 },
      { material: 'Cinta Reflectiva', unidad: 'Metro', consumoXPrenda: 1.5 },
      { material: 'Velcro',          unidad: 'Metro', consumoXPrenda: 0.4 },
    ],
    procesos: DEFAULT_PROCESOS,
    tiempoTotalXPrenda: DEFAULT_TOTAL,
  },
  {
    nombre: 'Camiseta Polo',
    keywords: ['polo', 'camiseta polo', 'camisa polo', 'camiseta tipo polo'],
    talla: 'M',
    materiales: [
      { material: 'Algodón Premium', unidad: 'Metro',  consumoXPrenda: 1.3 },
      { material: 'Hilo',           unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',        unidad: 'Unidad', consumoXPrenda: 3   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 10 },
      { proceso: 'Confección',         minutosXPrenda: 30 },
      { proceso: 'Acabados',           minutosXPrenda:  5 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 55,
  },
  {
    nombre: 'Gorro Industrial',
    keywords: ['gorro', 'gorra', 'cofia'],
    talla: 'Única',
    materiales: [
      { material: 'Poliéster', unidad: 'Metro',  consumoXPrenda: 0.3 },
      { material: 'Hilo',     unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Elástico', unidad: 'Metro',  consumoXPrenda: 0.2 },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 3  },
      { proceso: 'Confección',         minutosXPrenda: 10 },
      { proceso: 'Acabados',           minutosXPrenda: 2  },
      { proceso: 'Control de Calidad', minutosXPrenda: 1  },
      { proceso: 'Empaque',            minutosXPrenda: 2  },
    ],
    tiempoTotalXPrenda: 18,
  },
  {
    nombre: 'Delantal Impermeable',
    keywords: ['delantal'],
    talla: 'M',
    materiales: [
      { material: 'Lona Industrial', unidad: 'Metro',  consumoXPrenda: 1.2 },
      { material: 'Hilo',           unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Velcro',         unidad: 'Metro',  consumoXPrenda: 0.3 },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda:  8 },
      { proceso: 'Confección',         minutosXPrenda: 25 },
      { proceso: 'Acabados',           minutosXPrenda:  5 },
      { proceso: 'Control de Calidad', minutosXPrenda:  2 },
      { proceso: 'Empaque',            minutosXPrenda:  3 },
    ],
    tiempoTotalXPrenda: 43,
  },
  {
    nombre: 'Uniforme Escolar',
    keywords: ['uniforme escolar', 'escolar'],
    talla: '12',
    materiales: [
      { material: 'Tela Gabardina', unidad: 'Metro',  consumoXPrenda: 2.0 },
      { material: 'Hilo',         unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',      unidad: 'Unidad', consumoXPrenda: 6   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 20 },
      { proceso: 'Confección',         minutosXPrenda: 70 },
      { proceso: 'Acabados',           minutosXPrenda: 15 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 115,
  },
  {
    nombre: 'Jean Empresarial',
    keywords: ['jean', 'jeans', 'denim', 'pantalon jean', 'pantalón jean'],
    talla: '32',
    materiales: [
      { material: 'Denim Azul',  unidad: 'Metro',  consumoXPrenda: 1.6 },
      { material: 'Hilo',       unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Cremallera', unidad: 'Unidad', consumoXPrenda: 1   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 18 },
      { proceso: 'Confección',         minutosXPrenda: 55 },
      { proceso: 'Acabados',           minutosXPrenda: 10 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 93,
  },
  {
    nombre: 'Sudadera Deportiva',
    keywords: ['sudadera', 'buzo', 'hoodie', 'sweatshirt'],
    talla: 'M',
    materiales: [
      { material: 'Licra Deportiva', unidad: 'Metro',  consumoXPrenda: 1.8 },
      { material: 'Elástico',       unidad: 'Metro',  consumoXPrenda: 1.0 },
      { material: 'Hilo',          unidad: 'Unidad', consumoXPrenda: 1   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 15 },
      { proceso: 'Confección',         minutosXPrenda: 50 },
      { proceso: 'Acabados',           minutosXPrenda: 10 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 85,
  },
  {
    nombre: 'Camisa Antifluido',
    keywords: ['antifluido', 'camisa antifluido', 'uniforme antifluido'],
    talla: 'M',
    materiales: [
      { material: 'Tela Antifluido', unidad: 'Metro',  consumoXPrenda: 1.5 },
      { material: 'Hilo',           unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Botones',        unidad: 'Unidad', consumoXPrenda: 7   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 12 },
      { proceso: 'Confección',         minutosXPrenda: 38 },
      { proceso: 'Acabados',           minutosXPrenda:  8 },
      { proceso: 'Control de Calidad', minutosXPrenda:  5 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 68,
  },
  {
    nombre: 'Pijama Quirúrgica',
    keywords: ['pijama', 'quirurgica', 'quirúrgica', 'pijama quirurgica'],
    talla: 'M',
    materiales: [
      { material: 'Tela Antifluido', unidad: 'Metro',  consumoXPrenda: 1.9 },
      { material: 'Hilo',           unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Elástico',       unidad: 'Metro',  consumoXPrenda: 0.6 },
    ],
    procesos: DEFAULT_PROCESOS,
    tiempoTotalXPrenda: DEFAULT_TOTAL,
  },
  {
    nombre: 'Botas Industriales',
    keywords: ['bota', 'botas', 'calzado', 'zapato seguridad', 'zapatos seguridad'],
    talla: '40',
    materiales: [
      { material: 'Cuero Industrial',       unidad: 'Metro',  consumoXPrenda: 1.4 },
      { material: 'Goma Antideslizante',    unidad: 'Unidad', consumoXPrenda: 1   },
      { material: 'Cordones',              unidad: 'Unidad', consumoXPrenda: 2   },
    ],
    procesos: [
      { proceso: 'Corte',              minutosXPrenda: 35 },
      { proceso: 'Confección',         minutosXPrenda: 80 },
      { proceso: 'Acabados',           minutosXPrenda: 20 },
      { proceso: 'Control de Calidad', minutosXPrenda: 10 },
      { proceso: 'Empaque',            minutosXPrenda:  5 },
    ],
    tiempoTotalXPrenda: 150,
  },
];

// Ficha genérica cuando no hay match
export const FICHA_GENERICA: Omit<FichaTecnica, 'nombre' | 'keywords'> = {
  talla: 'M',
  materiales: [
    { material: 'Tela Oxford',    unidad: 'Metro',  consumoXPrenda: 1.5 },
    { material: 'Hilo',          unidad: 'Unidad', consumoXPrenda: 1   },
    { material: 'Botones',       unidad: 'Unidad', consumoXPrenda: 6   },
    { material: 'Etiqueta',      unidad: 'Unidad', consumoXPrenda: 1   },
  ],
  procesos: DEFAULT_PROCESOS,
  tiempoTotalXPrenda: DEFAULT_TOTAL,
};

export function buscarFicha(nombreProducto: string): FichaTecnica | null {
  const lower = nombreProducto.toLowerCase();
  for (const ficha of FICHAS_TECNICAS) {
    if (ficha.keywords.some(k => lower.includes(k.toLowerCase()))) {
      return ficha;
    }
  }
  return null;
}

export function minutosATexto(minutos: number): string {
  const h = Math.floor(minutos / 60);
  const m = minutos % 60;
  if (h === 0) return `${m} minutos`;
  if (m === 0) return `${h} hora${h > 1 ? 's' : ''}`;
  return `${h} hora${h > 1 ? 's' : ''} y ${m} minutos`;
}
