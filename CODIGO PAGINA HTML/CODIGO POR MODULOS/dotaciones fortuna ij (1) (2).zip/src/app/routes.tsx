import { createBrowserRouter, Navigate } from 'react-router';
import { Home } from './components/Home';
import { Login } from './components/Login';
import { Register } from './components/Register';
import { Nosotros } from './components/Nosotros';
import { RecuperarContrasena } from './components/RecuperarContrasena';
import { DashboardLayout } from './components/DashboardLayout';
import { Productos } from './components/modules/Productos';
import { Ventas } from './components/modules/Ventas';
import { Inventario } from './components/modules/Inventario';
import { Tickets } from './components/modules/Tickets';
import { Pedidos } from './components/modules/Pedidos';
import { PQRS } from './components/modules/PQRS';
import { GuiaPedidos } from './components/modules/GuiaPedidos';
import { Administracion } from './components/modules/Administracion';
import { Perfil } from './components/modules/Perfil';
import { CatalogoSENA } from './components/CatalogoSENA';
import { CatalogoIndustrial } from './components/CatalogoIndustrial';
import { ProtectedRoute } from './components/ProtectedRoute';
import { AccesoDenegado } from './components/AccesoDenegado';
import { NotFound } from './components/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/register',
    element: <Register />,
  },
  {
    path: '/nosotros',
    element: <Nosotros />,
  },
  {
    path: '/recuperar-contrasena',
    element: <RecuperarContrasena />,
  },
  {
    path: '/dashboard',
    element: (
      <ProtectedRoute>
        <DashboardLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <Navigate to="/dashboard/productos" replace />,
      },
      {
        path: 'admin',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general']}>
            <Administracion />
          </ProtectedRoute>
        ),
      },
      {
        path: 'catalogo-sena',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'subgerente', 'cliente']}>
            <CatalogoSENA />
          </ProtectedRoute>
        ),
      },
      {
        path: 'catalogo-industrial',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'subgerente', 'cliente']}>
            <CatalogoIndustrial />
          </ProtectedRoute>
        ),
      },
      {
        path: 'productos',
        element: <Productos />,
      },
      {
        path: 'ventas',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'subgerente', 'cliente']}>
            <Ventas />
          </ProtectedRoute>
        ),
      },
      {
        path: 'inventario',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'admin_inventario', 'subgerente']}>
            <Inventario />
          </ProtectedRoute>
        ),
      },
      {
        path: 'tickets',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'admin_inventario', 'subgerente', 'cliente']}>
            <Tickets />
          </ProtectedRoute>
        ),
      },
      {
        path: 'pedidos',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'admin_inventario', 'subgerente', 'cliente']}>
            <Pedidos />
          </ProtectedRoute>
        ),
      },
      {
        path: 'pqrs',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'admin_inventario', 'subgerente', 'cliente']}>
            <PQRS />
          </ProtectedRoute>
        ),
      },
      {
        path: 'guia',
        element: (
          <ProtectedRoute allowedRoles={['gerente_general', 'subgerente', 'cliente']}>
            <GuiaPedidos />
          </ProtectedRoute>
        ),
      },
      {
        path: 'perfil',
        element: <Perfil />,
      },
    ],
  },
  {
    path: '/acceso-denegado',
    element: <AccesoDenegado />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
]);
