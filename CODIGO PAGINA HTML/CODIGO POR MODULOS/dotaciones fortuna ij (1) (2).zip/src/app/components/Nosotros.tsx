import React from 'react';
import { useNavigate } from 'react-router';
import { DocumentTitle } from './DocumentTitle';
import logoFortunaIJ from '../../imports/image-2.png';

export const Nosotros: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <DocumentTitle title="Nosotros" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-black/90 backdrop-blur-xl border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <img
            src={logoFortunaIJ}
            alt="Dotaciones Fortuna IJ"
            className="h-12 w-auto object-contain"
            onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <nav>
            <button
              onClick={() => navigate('/')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-5 py-2 rounded-lg text-sm transition-all hover:scale-105"
            >
              Volver
            </button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative flex-1 py-20 overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-64 bg-yellow-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="relative max-w-5xl mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-6xl font-black text-white mb-3">Nosotros</h1>
            <p className="text-gray-400 text-xl">Conoce nuestra razón de ser</p>
          </div>

          {/* Cards Misión / Visión */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Misión */}
            <div className="bg-zinc-900 border border-yellow-500/20 rounded-2xl p-8 hover:border-yellow-500/50 transition-all">
              <div className="w-14 h-14 bg-yellow-500/10 rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                </svg>
              </div>
              <h2 className="text-2xl font-black text-white mb-4">Misión</h2>
              <p className="text-gray-400 leading-relaxed">
                Somos una empresa dedicada al diseño, confección y comercialización de dotaciones empresariales y uniformes de alta calidad, comprometida con satisfacer las necesidades de nuestros clientes mediante productos cómodos, duraderos e innovadores. Trabajamos con responsabilidad, cumplimiento y excelencia para fortalecer la imagen corporativa y el bienestar de los trabajadores.
              </p>
            </div>

            {/* Visión */}
            <div className="bg-zinc-900 border border-yellow-500/20 rounded-2xl p-8 hover:border-yellow-500/50 transition-all">
              <div className="w-14 h-14 bg-yellow-500/10 rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                </svg>
              </div>
              <h2 className="text-2xl font-black text-white mb-4">Visión</h2>
              <p className="text-gray-400 leading-relaxed">
                Ser una empresa líder en Colombia en la fabricación y comercialización de dotaciones empresariales, reconocida por la calidad de nuestros productos, la innovación en nuestros procesos, el cumplimiento en las entregas y la satisfacción de nuestros clientes, contribuyendo al crecimiento del sector textil y empresarial.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-zinc-800 py-12">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div className="rounded-2xl overflow-hidden h-48">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15907.852707168846!2d-74.114137!3d4.6006184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f996bf35afae5%3A0xc7ce950475538f58!2sAlkosto%20Carrera%2030!5e0!3m2!1ses-419!2sco!4v1782314845501!5m2!1ses-419!2sco"
                width="100%" height="100%"
                style={{ border: 0 }}
                allowFullScreen loading="lazy"
                referrerPolicy="strict-origin-when-cross-origin"
                title="Ubicación"
              />
            </div>
            <div className="space-y-2">
              <p className="text-yellow-400 font-bold text-base mb-3">Vestimos tu trabajo, impulsamos tu empresa</p>
              <p className="text-gray-500 text-sm">📞 312 388 8729 — 313 851 6917</p>
              <p className="text-gray-500 text-sm">📍 Cra 63 No. 22 - 22 sur</p>
              <p className="text-gray-500 text-sm">✉️ dotacionesfortunaij@gmail.com</p>
              <p className="text-gray-500 text-sm">📱 @dotacionesfortunaij</p>
            </div>
          </div>
          <p className="text-gray-700 text-sm text-center border-t border-zinc-800 pt-6">
            © 2026 Dotaciones Fortuna IJ. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
};
