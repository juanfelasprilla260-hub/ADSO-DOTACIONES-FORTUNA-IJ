import { useEffect } from 'react';

interface DocumentTitleProps {
  title: string;
}

export const DocumentTitle: React.FC<DocumentTitleProps> = ({ title }) => {
  useEffect(() => {
    document.title = `${title} | Dotaciones Fortuna IJ`;
  }, [title]);

  return null;
};
