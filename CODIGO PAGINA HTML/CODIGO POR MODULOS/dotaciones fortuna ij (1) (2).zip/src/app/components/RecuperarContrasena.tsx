import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { DocumentTitle } from './DocumentTitle';
import { Mail, KeyRound, Lock, CheckCircle, ArrowLeft, Eye, EyeOff, RefreshCw } from 'lucide-react';
import logoFortunaIJ from '../../imports/image-2.png';

type Paso = 1 | 2 | 3 | 4;

const CODIGO_KEY = 'recovery_code';
const CODIGO_EMAIL_KEY = 'recovery_email';
const CODIGO_EXPIRY_KEY = 'recovery_expiry';

function generarCodigo(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export const RecuperarContrasena: React.FC = () => {
  const navigate = useNavigate();
  const [paso, setPaso] = useState<Paso>(1);

  // Paso 1
  const [email, setEmail]           = useState('');
  const [errorEmail, setErrorEmail] = useState('');

  // Paso 2
  const [codigo, setCodigo] = useState(['', '', '', '', '', '']);
  const [errorCodigo, setErrorCodigo] = useState('');
  const [countdown, setCountdown]     = useState(120);
  const [codigoDemo, setCodigoDemo]   = useState(''); // solo para demo
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Paso 3
  const [nuevaPass, setNuevaPass]         = useState('');
  const [confirmarPass, setConfirmarPass] = useState('');
  const [showPass, setShowPass]           = useState(false);
  const [errorPass, setErrorPass]         = useState('');

  // Countdown timer
  useEffect(() => {
    if (paso !== 2) return;
    const interval = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) { clearInterval(interval); return 0; }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [paso]);

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  // Paso 1 — enviar código
  const enviarCodigo = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorEmail('');
    const users: any[] = JSON.parse(localStorage.getItem('users') || '[]');
    const emailSuperAdmin = 'GG-2026DotacionesFortuna.IJ';

    const userExists = users.some(u => u.email === email) || email === emailSuperAdmin;
    if (!userExists) {
      setErrorEmail('No encontramos una cuenta asociada a ese correo.');
      return;
    }

    const code = generarCodigo();
    const expiry = Date.now() + 2 * 60 * 1000; // 2 min
    localStorage.setItem(CODIGO_KEY, code);
    localStorage.setItem(CODIGO_EMAIL_KEY, email);
    localStorage.setItem(CODIGO_EXPIRY_KEY, expiry.toString());

    setCodigoDemo(code); // demo: mostrar el código
    setCountdown(120);
    setPaso(2);
    setTimeout(() => inputRefs.current[0]?.focus(), 100);
  };

  // Paso 2 — manejar OTP input
  const handleOtpChange = (idx: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const nuevo = [...codigo];
    nuevo[idx] = val.slice(-1);
    setCodigo(nuevo);
    if (val && idx < 5) inputRefs.current[idx + 1]?.focus();
  };

  const handleOtpKeyDown = (idx: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !codigo[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const nuevo = [...codigo];
    pasted.split('').forEach((c, i) => { nuevo[i] = c; });
    setCodigo(nuevo);
    inputRefs.current[Math.min(pasted.length, 5)]?.focus();
  };

  const verificarCodigo = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorCodigo('');
    const ingresado = codigo.join('');
    if (ingresado.length < 6) { setErrorCodigo('Ingresa el código completo de 6 dígitos.'); return; }

    const storedCode   = localStorage.getItem(CODIGO_KEY) || '';
    const storedExpiry = parseInt(localStorage.getItem(CODIGO_EXPIRY_KEY) || '0');

    if (Date.now() > storedExpiry) { setErrorCodigo('El código ha expirado. Solicita uno nuevo.'); return; }
    if (ingresado !== storedCode)  { setErrorCodigo('Código incorrecto. Verifica e intenta de nuevo.'); return; }

    setPaso(3);
  };

  const reenviarCodigo = () => {
    const code = generarCodigo();
    const expiry = Date.now() + 2 * 60 * 1000;
    localStorage.setItem(CODIGO_KEY, code);
    localStorage.setItem(CODIGO_EXPIRY_KEY, expiry.toString());
    setCodigoDemo(code);
    setCountdown(120);
    setCodigo(['', '', '', '', '', '']);
    setErrorCodigo('');
    setTimeout(() => inputRefs.current[0]?.focus(), 100);
  };

  // Paso 3 — nueva contraseña
  const actualizarContrasena = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorPass('');
    if (nuevaPass.length < 6)         { setErrorPass('La contraseña debe tener al menos 6 caracteres.'); return; }
    if (nuevaPass !== confirmarPass)   { setErrorPass('Las contraseñas no coinciden.'); return; }

    const emailRec = localStorage.getItem(CODIGO_EMAIL_KEY) || '';
    const users: any[] = JSON.parse(localStorage.getItem('users') || '[]');
    const updated = users.map(u => u.email === emailRec ? { ...u, password: nuevaPass } : u);
    localStorage.setItem('users', JSON.stringify(updated));
    // Limpiar datos de recuperación
    localStorage.removeItem(CODIGO_KEY);
    localStorage.removeItem(CODIGO_EMAIL_KEY);
    localStorage.removeItem(CODIGO_EXPIRY_KEY);

    setPaso(4);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      <DocumentTitle title="Recuperar Contraseña" />

      {/* Glow blobs */}
      <div className="absolute top-[-10%] right-[-5%] w-80 h-80 bg-yellow-500/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-80 h-80 bg-yellow-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        <div className="bg-zinc-900/90 backdrop-blur-xl border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          {/* Logo */}
          <div className="flex justify-center mb-5">
            <img src={logoFortunaIJ} alt="Dotaciones Fortuna IJ" className="h-16 w-auto object-contain"
              onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          </div>

          {/* Stepper */}
          {paso < 4 && (
            <div className="flex items-center justify-center gap-2 mb-7">
              {[1, 2, 3].map(s => (
                <React.Fragment key={s}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border-2 transition-all ${
                    paso === s ? 'border-yellow-500 bg-yellow-500/20 text-yellow-400' :
                    paso > s  ? 'border-green-500 bg-green-500/20 text-green-400' :
                    'border-zinc-700 bg-zinc-800 text-zinc-600'
                  }`}>
                    {paso > s ? '✓' : s}
                  </div>
                  {s < 3 && <div className={`h-0.5 w-10 ${paso > s ? 'bg-green-500/60' : 'bg-zinc-700'}`} />}
                </React.Fragment>
              ))}
            </div>
          )}

          {/* ── PASO 1: Ingresar correo ── */}
          {paso === 1 && (
            <div>
              <div className="text-center mb-6">
                <div className="w-14 h-14 bg-yellow-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-7 h-7 text-yellow-500" />
                </div>
                <h2 className="text-2xl font-black text-white">Recuperar Contraseña</h2>
                <p className="text-gray-500 text-sm mt-1">Te enviaremos un código de verificación</p>
              </div>

              <form onSubmit={enviarCodigo} className="space-y-4">
                <div>
                  <h4 className="text-white font-bold text-sm mb-2">Correo electrónico</h4>
                  <input
                    type="text"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="tu@email.com"
                    required
                    className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                  />
                </div>
                {errorEmail && (
                  <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl text-sm">{errorEmail}</div>
                )}
                <button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30">
                  Enviar Código
                </button>
              </form>
            </div>
          )}

          {/* ── PASO 2: Código de verificación ── */}
          {paso === 2 && (
            <div>
              <div className="text-center mb-6">
                <div className="w-14 h-14 bg-yellow-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <KeyRound className="w-7 h-7 text-yellow-500" />
                </div>
                <h2 className="text-2xl font-black text-white">Código de Verificación</h2>
                <p className="text-gray-500 text-sm mt-1">
                  Código enviado a <span className="text-yellow-400 font-semibold">{email}</span>
                </p>
              </div>

              {/* Demo banner */}
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl px-4 py-3 mb-5 text-center">
                <p className="text-blue-400 text-xs font-semibold mb-0.5">Modo Demo — código generado:</p>
                <p className="text-white font-black text-2xl tracking-widest font-mono">{codigoDemo}</p>
                <p className="text-gray-600 text-xs mt-1">En producción este código se enviaría al correo registrado</p>
              </div>

              <form onSubmit={verificarCodigo} className="space-y-5">
                {/* OTP inputs */}
                <div>
                  <p className="text-white font-bold text-sm mb-3 text-center">Ingresa el código de 6 dígitos</p>
                  <div className="flex gap-2 justify-center" onPaste={handleOtpPaste}>
                    {codigo.map((d, i) => (
                      <input
                        key={i}
                        ref={el => { inputRefs.current[i] = el; }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={d}
                        onChange={e => handleOtpChange(i, e.target.value)}
                        onKeyDown={e => handleOtpKeyDown(i, e)}
                        className={`w-11 h-14 text-center text-xl font-black bg-zinc-800 border-2 rounded-xl text-white focus:outline-none transition-all ${
                          d ? 'border-yellow-500 bg-yellow-500/5' : 'border-zinc-700 focus:border-yellow-500/60'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Countdown */}
                <div className="text-center">
                  {countdown > 0 ? (
                    <p className="text-gray-500 text-sm">
                      Expira en <span className="text-yellow-400 font-bold">{formatTime(countdown)}</span>
                    </p>
                  ) : (
                    <p className="text-red-400 text-sm">El código ha expirado</p>
                  )}
                </div>

                {errorCodigo && (
                  <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl text-sm text-center">{errorCodigo}</div>
                )}

                <button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30">
                  Verificar Código
                </button>
              </form>

              <button
                onClick={reenviarCodigo}
                className="w-full mt-3 flex items-center justify-center gap-2 text-gray-500 hover:text-yellow-400 text-sm transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reenviar código
              </button>
            </div>
          )}

          {/* ── PASO 3: Nueva contraseña ── */}
          {paso === 3 && (
            <div>
              <div className="text-center mb-6">
                <div className="w-14 h-14 bg-yellow-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-7 h-7 text-yellow-500" />
                </div>
                <h2 className="text-2xl font-black text-white">Nueva Contraseña</h2>
                <p className="text-gray-500 text-sm mt-1">Elige una contraseña segura</p>
              </div>

              <form onSubmit={actualizarContrasena} className="space-y-4">
                <div>
                  <h4 className="text-white font-bold text-sm mb-2">Nueva contraseña</h4>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'}
                      value={nuevaPass}
                      onChange={e => setNuevaPass(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      minLength={6}
                      required
                      className="w-full px-4 py-3 pr-12 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                    />
                    <button type="button" onClick={() => setShowPass(v => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-bold text-sm mb-2">Confirmar contraseña</h4>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'}
                      value={confirmarPass}
                      onChange={e => setConfirmarPass(e.target.value)}
                      placeholder="Repite la contraseña"
                      required
                      className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                    />
                  </div>
                </div>

                {/* Strength indicator */}
                {nuevaPass && (
                  <div>
                    <div className="flex gap-1 mb-1">
                      {[1,2,3,4].map(l => (
                        <div key={l} className={`flex-1 h-1 rounded-full transition-all ${
                          nuevaPass.length >= l * 3
                            ? l <= 1 ? 'bg-red-500' : l <= 2 ? 'bg-orange-500' : l <= 3 ? 'bg-yellow-500' : 'bg-green-500'
                            : 'bg-zinc-700'
                        }`} />
                      ))}
                    </div>
                    <p className="text-gray-600 text-xs">
                      {nuevaPass.length < 6 ? 'Muy corta' : nuevaPass.length < 9 ? 'Débil' : nuevaPass.length < 12 ? 'Media' : 'Fuerte'}
                    </p>
                  </div>
                )}

                {errorPass && (
                  <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl text-sm">{errorPass}</div>
                )}

                <button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30">
                  Restablecer Contraseña
                </button>
              </form>
            </div>
          )}

          {/* ── PASO 4: Éxito ── */}
          {paso === 4 && (
            <div className="text-center py-4">
              <div className="w-20 h-20 bg-green-500/15 rounded-full flex items-center justify-center mx-auto mb-5">
                <CheckCircle className="w-10 h-10 text-green-400" />
              </div>
              <h2 className="text-2xl font-black text-white mb-2">¡Contraseña restablecida!</h2>
              <p className="text-gray-400 mb-8">
                Tu contraseña fue actualizada exitosamente.<br />Ya puedes iniciar sesión.
              </p>
              <button
                onClick={() => navigate('/login')}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30"
              >
                Iniciar Sesión
              </button>
            </div>
          )}

          {/* Volver */}
          {paso < 4 && (
            <button
              onClick={() => paso === 1 ? navigate('/login') : setPaso(p => (p - 1) as Paso)}
              className="w-full mt-4 flex items-center justify-center gap-2 text-gray-500 hover:text-gray-300 text-sm transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              {paso === 1 ? 'Volver al login' : 'Paso anterior'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
