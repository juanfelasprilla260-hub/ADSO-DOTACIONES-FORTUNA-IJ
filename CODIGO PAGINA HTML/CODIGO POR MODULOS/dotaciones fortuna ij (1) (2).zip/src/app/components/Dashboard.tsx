import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { LogOut, Package, ShoppingCart, Warehouse, Receipt, Menu, X } from 'lucide-react';
import { Productos } from './modules/Productos';
import { Ventas } from './modules/Ventas';
import { Inventario } from './modules/Inventario';
import { Tickets } from './modules/Tickets';

type Module = 'productos' | 'ventas' | 'inventario' | 'tickets';

export const Dashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeModule, setActiveModule] = useState<Module>('productos');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const getRoleName = (role: string) => {
    switch (role) {
      case 'admin_general':
        return 'Administrador General';
      case 'admin_inventario':
        return 'Administrador de Inventarios';
      case 'cliente':
        return 'Cliente';
      default:
        return role;
    }
  };

  const canAccess = (module: Module) => {
    if (user?.role === 'admin_general') return true;
    if (user?.role === 'admin_inventario' && ['productos', 'inventario'].includes(module)) return true;
    if (user?.role === 'cliente' && ['productos', 'ventas', 'tickets'].includes(module)) return true;
    return false;
  };

  const menuItems = [
    { id: 'productos' as Module, icon: Package, label: 'Productos' },
    { id: 'ventas' as Module, icon: ShoppingCart, label: 'Ventas' },
    { id: 'inventario' as Module, icon: Warehouse, label: 'Inventario' },
    { id: 'tickets' as Module, icon: Receipt, label: 'Tickets' },
  ];

  return (
    <div className="h-screen flex bg-black overflow-hidden">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-0'} bg-zinc-900 border-r border-yellow-500 transition-all duration-300 overflow-hidden flex flex-col`}>
        <div className="p-6 border-b border-zinc-800">
          <h1 className="text-2xl text-yellow-500">Dotaciones</h1>
          <p className="text-sm text-gray-400 mt-1">{user?.nombre}</p>
          <p className="text-xs text-yellow-500/70">{getRoleName(user?.role || '')}</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const hasAccess = canAccess(item.id);

            return (
              <button
                key={item.id}
                onClick={() => hasAccess && setActiveModule(item.id)}
                disabled={!hasAccess}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeModule === item.id
                    ? 'bg-yellow-500 text-black'
                    : hasAccess
                    ? 'text-white hover:bg-zinc-800'
                    : 'text-gray-600 cursor-not-allowed'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-zinc-800">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Cerrar Sesión</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-zinc-900 border-b border-yellow-500 px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-yellow-500 hover:text-yellow-400 transition-colors"
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          <h2 className="text-xl text-white">
            {menuItems.find(item => item.id === activeModule)?.label}
          </h2>
          <div className="w-6" />
        </header>
   
        {/* Content Area */}
        <main className="flex-1 overflow-auto bg-zinc-950 p-6">
          {activeModule === 'productos' && <Productos />}
          {activeModule === 'ventas' && <Ventas />}
          {activeModule === 'inventario' && <Inventario />}
          {activeModule === 'tickets' && <Tickets />}
        </main>
      </div>
    </div>
  );
};
