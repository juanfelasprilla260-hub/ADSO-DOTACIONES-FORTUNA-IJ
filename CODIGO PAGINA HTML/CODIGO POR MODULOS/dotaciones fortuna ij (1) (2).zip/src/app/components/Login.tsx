import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from './AuthContext';
import { DocumentTitle } from './DocumentTitle';
import { Eye, EyeOff, Shield, User } from 'lucide-react';
import logoFortunaIJ from '../../imports/image-2.png';

export const Login: React.FC = () => {
  const [usuario, setUsuario] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) navigate('/dashboard/productos');
  }, [isAuthenticated, navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (login(usuario.trim(), password)) {
      navigate('/dashboard/productos');
    } else {
      setError('Usuario o contraseña incorrectos. Si tu cuenta está inactiva, contacta al administrador.');
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      <DocumentTitle title="Iniciar Sesión" />

      {/* Glow blobs — luz-1 y luz-2 */}
      <div className="absolute top-[-10%] right-[-5%] w-80 h-80 bg-yellow-500/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-80 h-80 bg-yellow-500/15 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        {/* Card */}
        <div className="bg-zinc-900/90 backdrop-blur-xl border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <img
              src={logoFortunaIJ}
              alt="Dotaciones Fortuna IJ"
              className="h-20 w-auto object-contain"
              onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>

          <h1 className="text-3xl font-black text-white text-center mb-8">Bienvenido</h1>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email / Usuario */}
            <div>
              <h4 className="text-white font-bold text-sm mb-2">Email</h4>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  value={usuario}
                  onChange={e => setUsuario(e.target.value)}
                  placeholder="tu@email.com"
                  autoComplete="username"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                />
              </div>
            </div>

            {/* Contraseña */}
            <div>
              <h4 className="text-white font-bold text-sm mb-2">Contraseña</h4>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  required
                  className="w-full px-4 py-3 pr-12 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            {/* Botón */}
            <div className="pt-1">
              <button
                type="submit"
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30"
              >
                Iniciar Sesión
              </button>
            </div>
          </form>

          {/* Links */}
          <div className="mt-6 space-y-3 text-center">
            <div>
              <button
                onClick={() => navigate('/register')}
                className="text-gray-400 hover:text-yellow-400 transition-colors text-sm"
              >
                ¿No tienes cuenta? <span className="font-semibold text-yellow-500">Regístrate</span>
              </button>
            </div>
            <div>
              <button
                onClick={() => navigate('/recuperar-contrasena')}
                className="text-gray-500 hover:text-yellow-400 transition-colors text-sm"
              >
                Olvidé mi Contraseña
              </button>
            </div>
          </div>

          {/* Nota admin discreta */}
          <div className="mt-5 flex items-center gap-2 bg-zinc-800/50 border border-zinc-700/50 rounded-xl px-3 py-2.5">
            <Shield className="w-4 h-4 text-yellow-500/60 flex-shrink-0" />
            <p className="text-gray-600 text-xs">
              El acceso administrativo utiliza las credenciales proporcionadas por la empresa.
            </p>
          </div>
        </div>

        {/* Volver al inicio */}
        <div className="text-center mt-5">
          <button onClick={() => navigate('/')} className="text-gray-600 hover:text-gray-400 text-sm transition-colors">
            ← Volver al inicio
          </button>
        </div>
      </div>
    </div>
  );
};
