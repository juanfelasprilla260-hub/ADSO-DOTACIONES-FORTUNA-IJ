import React from 'react';
import { ImageWithFallback } from './ImageWithFallback';
import senaUniformes from '../../imports/image.png';
import { GraduationCap, ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router';

export const CatalogoSENA: React.FC = () => {
  const navigate = useNavigate();

  const lineasFormacion = [
    { nombre: 'Administrativa', color: 'bg-blue-500' },
    { nombre: 'Industrial', color: 'bg-gray-700' },
    { nombre: 'Salud', color: 'bg-green-500' },
    { nombre: 'Gastronomía', color: 'bg-yellow-600' },
    { nombre: 'Sistemas', color: 'bg-purple-500' },
    { nombre: 'Agropecuario', color: 'bg-amber-600' },
    { nombre: 'Belleza', color: 'bg-pink-500' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-gradient-to-br from-green-500 to-green-600 p-4 rounded-full shadow-lg shadow-green-500/30">
            <GraduationCap className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-5xl text-white font-bold mb-4 bg-gradient-to-r from-white to-green-500 bg-clip-text text-transparent">
          Dotaciones y Uniformes del SENA
        </h1>
        <p className="text-gray-400 text-xl max-w-3xl mx-auto">
          Uniformes oficiales para diferentes líneas de formación del Servicio Nacional de Aprendizaje
        </p>
      </div>

      {/* Imagen Principal */}
      <div className="bg-zinc-900/80 backdrop-blur border border-green-500/30 rounded-2xl overflow-hidden hover:border-green-500 transition-all shadow-2xl shadow-green-500/10">
        <ImageWithFallback
          src={senaUniformes}
          alt="Dotaciones y Uniformes del SENA"
          className="w-full h-auto"
        />
      </div>

      {/* Líneas de Formación */}
      <div>
        <h2 className="text-3xl text-white font-bold mb-6 flex items-center gap-3">
          <span className="bg-green-500/10 p-2 rounded-lg">📚</span>
          Líneas de Formación Disponibles
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {lineasFormacion.map((linea, index) => (
            <div
              key={index}
              className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-4 text-center hover:border-green-500 transition-all hover:scale-105"
            >
              <div className={`${linea.color} w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center`}>
                <span className="text-2xl text-white font-bold">{index + 1}</span>
              </div>
              <p className="text-white text-sm font-semibold">{linea.nombre}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Características */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-green-500 transition-all">
          <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">✓</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Calidad Certificada</h3>
          <p className="text-gray-400">Uniformes confeccionados con materiales de alta calidad según estándares SENA</p>
        </div>

        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-green-500 transition-all">
          <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">🎯</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Diseño Oficial</h3>
          <p className="text-gray-400">Cumple con los lineamientos y especificaciones técnicas del SENA</p>
        </div>

        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-green-500 transition-all">
          <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">📦</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Entrega Rápida</h3>
          <p className="text-gray-400">Stock disponible para todas las líneas de formación</p>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/30 rounded-2xl p-8 text-center">
        <h3 className="text-3xl text-white font-bold mb-4">¿Listo para adquirir tu uniforme?</h3>
        <p className="text-gray-400 text-lg mb-6">
          Explora nuestro catálogo completo de uniformes SENA
        </p>
        <button
          onClick={() => navigate('/dashboard/productos')}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-4 rounded-xl transition-all shadow-lg shadow-green-500/30 hover:shadow-green-500/50 hover:scale-105 font-semibold text-lg"
        >
          <ShoppingCart className="w-5 h-5" />
          Ver Catálogo Completo
        </button>
      </div>
    </div>
  );
};
