import React from 'react';
import { ImageWithFallback } from './ImageWithFallback';
import dotacionesIndustriales from '../../imports/image-3.png';
import uniformesVariados from '../../imports/image-4.png';
import equipoSeguridad from '../../imports/image-5.png';
import { HardHat, ShoppingCart, Shield, Package } from 'lucide-react';
import { useNavigate } from 'react-router';

export const CatalogoIndustrial: React.FC = () => {
  const navigate = useNavigate();

  const categorias = [
    {
      nombre: 'Ropa Industrial',
      imagen: dotacionesIndustriales,
      productos: [
        'Chalecos Reflectivos',
        'Overoles Industriales',
        'Parkas Impermeables',
        'Chaquetas de Seguridad',
        'Gorras Industriales'
      ]
    },
    {
      nombre: 'Vestuario y Calzado',
      imagen: uniformesVariados,
      productos: [
        'Buzos y Sudaderas',
        'Uniformes de Chef',
        'Pantalones de Trabajo',
        'Botas de Seguridad',
        'Zapatos Industriales'
      ]
    },
    {
      nombre: 'Elementos de Protección Personal (EPP)',
      imagen: equipoSeguridad,
      productos: [
        'Cascos de Seguridad',
        'Guantes de Protección',
        'Botas Industriales',
        'Tapabocas y Mascarillas',
        'Protección Auditiva',
        'Overoles de Protección'
      ]
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-4 rounded-full shadow-lg shadow-orange-500/30">
            <HardHat className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-5xl text-white font-bold mb-4 bg-gradient-to-r from-white to-orange-500 bg-clip-text text-transparent">
          Catálogo Industrial
        </h1>
        <p className="text-gray-400 text-xl max-w-3xl mx-auto">
          Equipamiento profesional para todas las industrias
        </p>
      </div>

      {/* Categorías con Imágenes */}
      <div className="space-y-12">
        {categorias.map((cat, index) => (
          <div key={index} className="space-y-6">
            <h2 className="text-3xl text-white font-bold flex items-center gap-3">
              <Package className="w-8 h-8 text-orange-500" />
              {cat.nombre}
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Imagen */}
              <div className="bg-zinc-900/80 backdrop-blur border border-orange-500/30 rounded-2xl overflow-hidden hover:border-orange-500 transition-all shadow-lg">
                <ImageWithFallback
                  src={cat.imagen}
                  alt={cat.nombre}
                  className="w-full h-auto"
                />
              </div>

              {/* Lista de Productos */}
              <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl p-8 flex flex-col justify-center">
                <h3 className="text-2xl text-orange-500 font-bold mb-6">Productos Disponibles</h3>
                <ul className="space-y-4">
                  {cat.productos.map((producto, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-white text-lg">
                      <div className="bg-orange-500/10 w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Shield className="w-5 h-5 text-orange-500" />
                      </div>
                      <span>{producto}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Características */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-orange-500 transition-all">
          <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">✓</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Resistencia Garantizada</h3>
          <p className="text-gray-400">Materiales de alta durabilidad para condiciones extremas</p>
        </div>

        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-orange-500 transition-all">
          <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">🛡️</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Seguridad Certificada</h3>
          <p className="text-gray-400">Cumple con normativas internacionales de seguridad industrial</p>
        </div>

        <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-orange-500 transition-all">
          <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <span className="text-2xl">💼</span>
          </div>
          <h3 className="text-xl text-white font-semibold mb-2">Variedad Completa</h3>
          <p className="text-gray-400">Amplia gama de tallas y colores disponibles</p>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border border-orange-500/30 rounded-2xl p-8 text-center">
        <h3 className="text-3xl text-white font-bold mb-4">¿Necesitas equipar tu equipo?</h3>
        <p className="text-gray-400 text-lg mb-6">
          Consulta nuestro catálogo completo de productos industriales
        </p>
        <button
          onClick={() => navigate('/dashboard/productos')}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-4 rounded-xl transition-all shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50 hover:scale-105 font-semibold text-lg"
        >
          <ShoppingCart className="w-5 h-5" />
          Ver Todos los Productos
        </button>
      </div>
    </div>
  );
};
