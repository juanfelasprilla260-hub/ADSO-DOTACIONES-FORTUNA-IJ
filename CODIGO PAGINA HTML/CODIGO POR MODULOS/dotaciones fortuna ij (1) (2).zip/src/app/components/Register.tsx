import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from './AuthContext';
import { DocumentTitle } from './DocumentTitle';
import { Eye, EyeOff, ShieldCheck } from 'lucide-react';
import logoFortunaIJ from '../../imports/image-2.png';

export const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    tipoId:    'cedula',
    numeroId:  '',
    nombres:   '',
    apellidos: '',
    email:     '',
    telefono:  '',
    password:  '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState('');
  const { register, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) navigate('/dashboard/productos');
  }, [isAuthenticated, navigate]);

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setFormData(f => ({ ...f, [key]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.nombres.trim() || !formData.apellidos.trim()) {
      setError('Completa tu nombre y apellidos.');
      return;
    }
    if (formData.password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }

    const nombreCompleto = `${formData.nombres.trim()} ${formData.apellidos.trim()}`;

    if (register(formData.email, formData.password, nombreCompleto, 'cliente', undefined, {
      tipoId:   formData.tipoId,
      numeroId: formData.numeroId,
      telefono: formData.telefono,
    })) {
      setSuccess('¡Registro exitoso! Redirigiendo al inicio de sesión...');
      setTimeout(() => navigate('/login'), 1500);
    } else {
      setError('Este correo ya está registrado. Intenta con otro.');
    }
  };

  const campos = [
    { key: 'numeroId',  label: 'N° Identificación', type: 'number', placeholder: '1234567890'    },
    { key: 'nombres',   label: 'Nombres',            type: 'text',   placeholder: 'Juan'           },
    { key: 'apellidos', label: 'Apellidos',           type: 'text',   placeholder: 'Pérez García'   },
    { key: 'email',     label: 'Correo Electrónico',  type: 'email',  placeholder: 'tu@email.com'   },
    { key: 'telefono',  label: 'Teléfono',            type: 'number', placeholder: '3001234567'     },
  ] as const;

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      <DocumentTitle title="Registro" />

      {/* Glow blobs */}
      <div className="absolute top-[-10%] right-[-5%] w-80 h-80 bg-yellow-500/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-80 h-80 bg-yellow-500/15 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        <div className="bg-zinc-900/90 backdrop-blur-xl border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <img
              src={logoFortunaIJ}
              alt="Dotaciones Fortuna IJ"
              className="h-20 w-auto object-contain"
              onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>

          <h1 className="text-3xl font-black text-white text-center mb-2">Registro</h1>

          <div className="flex justify-center mb-6">
            <span className="flex items-center gap-1.5 bg-green-500/10 border border-green-500/30 text-green-400 text-xs font-semibold px-3 py-1.5 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" />
              Acceso Cliente
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Tipo de identificación */}
            <div>
              <h4 className="text-white font-bold text-sm mb-2">Tipo de identificación</h4>
              <select
                value={formData.tipoId}
                onChange={set('tipoId')}
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-yellow-500 transition-all cursor-pointer"
              >
                <option value="cedula">Cédula</option>
                <option value="nit">NIT</option>
                <option value="pasaporte">Pasaporte</option>
              </select>
            </div>

            {/* Campos de texto */}
            {campos.map(({ key, label, type, placeholder }) => (
              <div key={key}>
                <h4 className="text-white font-bold text-sm mb-2">{label}</h4>
                <input
                  type={type}
                  value={(formData as any)[key]}
                  onChange={set(key)}
                  placeholder={placeholder}
                  required={key === 'nombres' || key === 'apellidos' || key === 'email'}
                  className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                />
              </div>
            ))}

            {/* Contraseña */}
            <div>
              <h4 className="text-white font-bold text-sm mb-2">Contraseña</h4>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={set('password')}
                  placeholder="Mínimo 6 caracteres"
                  minLength={6}
                  required
                  className="w-full px-4 py-3 pr-12 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Rol (solo cliente) */}
            <div>
              <h4 className="text-white font-bold text-sm mb-2">Rol</h4>
              <select
                disabled
                className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700/50 rounded-xl text-gray-400 cursor-not-allowed"
              >
                <option>Cliente</option>
              </select>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl text-sm">
                {error}
              </div>
            )}
            {success && (
              <div className="bg-green-500/10 border border-green-500/30 text-green-400 px-4 py-3 rounded-xl text-sm">
                {success}
              </div>
            )}

            <div className="pt-1">
              <button
                type="submit"
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-3 rounded-xl text-lg transition-all hover:scale-[1.02] shadow-lg shadow-yellow-500/30"
              >
                Registrarse
              </button>
            </div>
          </form>

          <div className="mt-5 text-center">
            <button
              onClick={() => navigate('/login')}
              className="text-gray-400 hover:text-yellow-400 transition-colors text-sm"
            >
              ¿Ya tienes cuenta? <span className="font-semibold text-yellow-500">Inicia Sesión</span>
            </button>
          </div>

          <div className="mt-4 bg-zinc-800/50 border border-zinc-700/50 rounded-xl p-3 text-center">
            <p className="text-gray-600 text-xs">
              ¿Eres empleado? El acceso administrativo es gestionado directamente por el Gerente General.
            </p>
          </div>
        </div>

        <div className="text-center mt-5">
          <button onClick={() => navigate('/')} className="text-gray-600 hover:text-gray-400 text-sm transition-colors">
            ← Volver al inicio
          </button>
        </div>
      </div>
    </div>
  );
};
