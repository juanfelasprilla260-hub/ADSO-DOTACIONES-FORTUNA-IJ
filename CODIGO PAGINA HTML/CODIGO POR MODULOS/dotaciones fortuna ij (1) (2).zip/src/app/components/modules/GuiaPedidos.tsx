import React from 'react';
import { ShoppingBag, Search, ShoppingCart, CreditCard, Package, Truck, CheckCircle, HelpCircle } from 'lucide-react';

export const GuiaPedidos: React.FC = () => {
  const pasos = [
    {
      numero: 1,
      titulo: 'Explorar Productos',
      descripcion: 'Navega por nuestro catálogo de productos en la sección "Productos". Usa el buscador para encontrar lo que necesitas.',
      icono: Search,
      color: 'from-blue-500 to-blue-600'
    },
    {
      numero: 2,
      titulo: 'Agregar al Carrito',
      descripcion: 'Ve a la sección "Ventas" y haz clic en los productos que deseas. Ajusta las cantidades según tus necesidades.',
      icono: ShoppingCart,
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      numero: 3,
      titulo: 'Revisar tu Pedido',
      descripcion: 'Verifica los productos en tu carrito. Puedes modificar cantidades o eliminar artículos antes de finalizar.',
      icono: Package,
      color: 'from-purple-500 to-purple-600'
    },
    {
      numero: 4,
      titulo: 'Finalizar Compra',
      descripcion: 'Haz clic en "Finalizar Compra". Tu pedido se registrará y estará disponible en la sección "Pedidos".',
      icono: CreditCard,
      color: 'from-green-500 to-green-600'
    },
    {
      numero: 5,
      titulo: 'Seguimiento',
      descripcion: 'Consulta el estado de tu pedido en tiempo real. Recibirás actualizaciones sobre procesamiento y envío.',
      icono: Truck,
      color: 'from-orange-500 to-orange-600'
    },
    {
      numero: 6,
      titulo: 'Generar Ticket',
      descripcion: 'Una vez completada la compra, descarga tu ticket de pago desde la sección "Tickets" para tus registros.',
      icono: CheckCircle,
      color: 'from-teal-500 to-teal-600'
    }
  ];

  const faqs = [
    {
      pregunta: '¿Cómo puedo modificar un pedido?',
      respuesta: 'Los pedidos solo pueden modificarse mientras estén en estado "Pendiente". Contacta al administrador para cambios.'
    },
    {
      pregunta: '¿Cuánto tiempo tarda el envío?',
      respuesta: 'Los tiempos de envío varían según el producto y ubicación. Consulta el estado en la sección de Pedidos.'
    },
    {
      pregunta: '¿Puedo cancelar un pedido?',
      respuesta: 'Sí, puedes solicitar la cancelación mientras el pedido esté en estado "Pendiente" o "Procesando".'
    },
    {
      pregunta: '¿Dónde descargo mi ticket?',
      respuesta: 'Ve a la sección "Tickets", selecciona tu compra y haz clic en "Descargar Ticket".'
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-gradient-to-br from-yellow-500 to-yellow-600 p-4 rounded-full shadow-lg shadow-yellow-500/30">
            <ShoppingBag className="w-12 h-12 text-black" />
          </div>
        </div>
        <h1 className="text-5xl text-white font-bold mb-4 bg-gradient-to-r from-white to-yellow-500 bg-clip-text text-transparent">
          Guía de Pedidos
        </h1>
        <p className="text-gray-400 text-xl max-w-2xl mx-auto">
          Aprende cómo realizar un pedido paso a paso en nuestra plataforma
        </p>
      </div>

      {/* Proceso de Pedido */}
      <div className="space-y-6">
        <h2 className="text-3xl text-white font-bold mb-6">Proceso de Compra</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pasos.map((paso) => {
            const Icono = paso.icono;
            return (
              <div
                key={paso.numero}
                className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-yellow-500 transition-all hover:scale-105 hover:shadow-lg hover:shadow-yellow-500/20"
              >
                <div className="flex items-start gap-4">
                  <div className={`bg-gradient-to-br ${paso.color} p-4 rounded-xl shadow-lg flex-shrink-0`}>
                    <Icono className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="bg-yellow-500/20 text-yellow-400 px-3 py-1 rounded-full text-sm font-bold">
                        Paso {paso.numero}
                      </span>
                    </div>
                    <h3 className="text-xl text-white font-semibold mb-2">{paso.titulo}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">{paso.descripcion}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Consejos Útiles */}
      <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/10 border border-yellow-500/30 rounded-2xl p-8 backdrop-blur">
        <h3 className="text-2xl text-white font-bold mb-4 flex items-center gap-2">
          <span className="bg-yellow-500 p-2 rounded-lg">💡</span>
          Consejos Útiles
        </h3>
        <ul className="space-y-3 text-gray-300">
          <li className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <span>Revisa siempre el inventario disponible antes de hacer pedidos grandes</span>
          </li>
          <li className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <span>Guarda tus tickets de pago para futuras referencias y contabilidad</span>
          </li>
          <li className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <span>Utiliza el módulo PQRS si tienes dudas o sugerencias sobre el proceso</span>
          </li>
          <li className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <span>Los administradores pueden generar reportes detallados de todos los pedidos</span>
          </li>
        </ul>
      </div>

      {/* Preguntas Frecuentes */}
      <div className="space-y-4">
        <h2 className="text-3xl text-white font-bold mb-6 flex items-center gap-3">
          <HelpCircle className="w-8 h-8 text-yellow-500" />
          Preguntas Frecuentes
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-6 hover:border-yellow-500 transition-all"
            >
              <h4 className="text-lg text-yellow-500 font-semibold mb-3">{faq.pregunta}</h4>
              <p className="text-gray-400 leading-relaxed">{faq.respuesta}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Módulos del Sistema */}
      <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-8">
        <h3 className="text-2xl text-white font-bold mb-6">Módulos del Sistema</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <div className="bg-yellow-500/10 p-2 rounded-lg">
              <Package className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-white font-semibold">Productos</h4>
              <p className="text-gray-400 text-sm">Catálogo completo de dotaciones disponibles</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="bg-yellow-500/10 p-2 rounded-lg">
              <ShoppingCart className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-white font-semibold">Ventas</h4>
              <p className="text-gray-400 text-sm">Realiza compras y gestiona tu carrito</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="bg-yellow-500/10 p-2 rounded-lg">
              <ShoppingBag className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-white font-semibold">Pedidos</h4>
              <p className="text-gray-400 text-sm">Seguimiento y gestión de tus órdenes</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="bg-yellow-500/10 p-2 rounded-lg">
              <CheckCircle className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-white font-semibold">Tickets</h4>
              <p className="text-gray-400 text-sm">Descarga comprobantes de pago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
