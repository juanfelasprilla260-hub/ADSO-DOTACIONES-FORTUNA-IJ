import React, { useState, useEffect } from 'react';
import {
  Users, Shield, Edit, Trash2, Key, BarChart3, Activity, TrendingUp,
  Package, ShoppingBag, Settings, AlertTriangle, CheckCircle, XCircle,
  UserPlus, RefreshCw, Download, Eye, EyeOff, Lock, Unlock,
  FileText, PieChart, Bell, Database, Server, Globe, ChevronRight,
  Search, Filter, MoreVertical, Star, Clock, ArrowUp, ArrowDown
} from 'lucide-react';
import { useAuth, User, UserRole } from '../AuthContext';
import { PQRSWidget } from './PQRSWidget';

interface UserWithPassword extends User {
  password: string;
  codigoEmpleado?: string;
  createdAt?: string;
  lastLogin?: string;
  activo?: boolean;
}

type Tab = 'usuarios' | 'estadisticas' | 'codigos' | 'configuracion' | 'auditoria';

const CODIGOS_SISTEMA: Record<UserRole, string[]> = {
  gerente_general: ['GG-2024', 'GG-2025', 'GG-2026', 'ADMIN-001'],
  subgerente: ['SG-2024', 'SG-2025', 'SUB-001', 'SUB-002'],
  admin_inventario: ['INV-2024', 'INV-2025', 'INV-001', 'INV-002', 'INV-003'],
  cliente: [],
};

export const Administracion: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('usuarios');
  const [usuarios, setUsuarios] = useState<UserWithPassword[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserWithPassword | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [userToDelete, setUserToDelete] = useState<UserWithPassword | null>(null);
  const [newRole, setNewRole] = useState<UserRole>('cliente');
  const [newCodigoEmpleado, setNewCodigoEmpleado] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [codigosVisibles, setCodigosVisibles] = useState<Record<UserRole, boolean>>({
    gerente_general: false,
    subgerente: false,
    admin_inventario: false,
    cliente: false,
  });
  const [nuevoCodigoRol, setNuevoCodigoRol] = useState<UserRole>('admin_inventario');
  const [nuevoCodigoValor, setNuevoCodigoValor] = useState('');
  const [codigosPersonalizados, setCodigosPersonalizados] = useState<Record<string, string[]>>(
    JSON.parse(localStorage.getItem('codigosPersonalizados') || '{}')
  );
  const [configSistema, setConfigSistema] = useState({
    nombreEmpresa: localStorage.getItem('cfg_nombreEmpresa') || 'Dotaciones Fortuna IJ',
    maxProductos: localStorage.getItem('cfg_maxProductos') || '500',
    ivaPorcentaje: localStorage.getItem('cfg_ivaPorcentaje') || '19',
    descuentoMaximo: localStorage.getItem('cfg_descuentoMaximo') || '30',
    moneda: localStorage.getItem('cfg_moneda') || 'COP',
    notificaciones: localStorage.getItem('cfg_notificaciones') !== 'false',
  });
  const [configSaved, setConfigSaved] = useState(false);
  const [showCrearEmpleado, setShowCrearEmpleado] = useState(false);
  const [crearForm, setCrearForm] = useState({ nombre: '', email: '', password: '', role: 'subgerente' as UserRole, codigoEmpleado: '' });
  const [crearError, setCrearError] = useState('');
  const [crearSuccess, setCrearSuccess] = useState('');
  const [auditLog] = useState(() => {
    const stored = localStorage.getItem('auditLog');
    if (stored) return JSON.parse(stored) as any[];
    const defaultLog = [
      { id: 1, accion: 'Login exitoso', usuario: user?.nombre || 'Admin', modulo: 'Autenticación', fecha: new Date().toISOString(), tipo: 'info' },
      { id: 2, accion: 'Acceso al Panel de Administración', usuario: user?.nombre || 'Admin', modulo: 'Administración', fecha: new Date().toISOString(), tipo: 'info' },
    ];
    return defaultLog;
  });

  useEffect(() => {
    const stored = localStorage.getItem('users');
    if (stored) setUsuarios(JSON.parse(stored));
  }, []);

  const saveUsuarios = (users: UserWithPassword[]) => {
    setUsuarios(users);
    localStorage.setItem('users', JSON.stringify(users));
  };

  const crearEmpleado = () => {
    setCrearError('');
    setCrearSuccess('');
    const { nombre, email, password, role, codigoEmpleado } = crearForm;
    if (!nombre.trim() || !email.trim() || !password.trim() || !codigoEmpleado.trim()) {
      setCrearError('Todos los campos son obligatorios');
      return;
    }
    if (usuarios.find(u => u.email === email)) {
      setCrearError('Este email ya está registrado');
      return;
    }
    const nuevoEmpleado: UserWithPassword = {
      id: Date.now().toString(),
      nombre,
      email,
      password,
      role,
      codigoEmpleado,
      activo: true,
    };
    saveUsuarios([...usuarios, nuevoEmpleado]);
    setCrearSuccess(`Empleado "${nombre}" creado exitosamente`);
    setCrearForm({ nombre: '', email: '', password: '', role: 'subgerente', codigoEmpleado: '' });
    setTimeout(() => { setCrearSuccess(''); setShowCrearEmpleado(false); }, 2000);
  };

  const confirmarEliminar = (u: UserWithPassword) => {
    if (u.id === user?.id) { alert('No puedes eliminar tu propia cuenta'); return; }
    setUserToDelete(u);
    setShowDeleteModal(true);
  };

  const eliminarUsuario = () => {
    if (!userToDelete) return;
    saveUsuarios(usuarios.filter(u => u.id !== userToDelete.id));
    setShowDeleteModal(false);
    setUserToDelete(null);
  };

  const cambiarRol = () => {
    if (!selectedUser) return;
    if (newRole !== 'cliente' && !newCodigoEmpleado) {
      alert('Debes proporcionar un código de empleado para roles administrativos');
      return;
    }
    const updated = usuarios.map(u =>
      u.id === selectedUser.id ? { ...u, role: newRole, codigoEmpleado: newCodigoEmpleado || u.codigoEmpleado } : u
    );
    saveUsuarios(updated);
    if (selectedUser.id === user?.id) {
      const updatedCurrent = updated.find(u => u.id === user.id);
      if (updatedCurrent) {
        const { password, ...withoutPass } = updatedCurrent;
        localStorage.setItem('currentUser', JSON.stringify(withoutPass));
      }
    }
    setShowModal(false);
    setSelectedUser(null);
    setNewCodigoEmpleado('');
  };

  const toggleActivo = (id: string) => {
    if (id === user?.id) { alert('No puedes desactivar tu propia cuenta'); return; }
    const updated = usuarios.map(u => u.id === id ? { ...u, activo: u.activo === false ? true : false } : u);
    saveUsuarios(updated);
  };

  const agregarCodigo = () => {
    if (!nuevoCodigoValor.trim()) return;
    const updated = { ...codigosPersonalizados };
    if (!updated[nuevoCodigoRol]) updated[nuevoCodigoRol] = [];
    if (!updated[nuevoCodigoRol].includes(nuevoCodigoValor.toUpperCase())) {
      updated[nuevoCodigoRol] = [...updated[nuevoCodigoRol], nuevoCodigoValor.toUpperCase()];
      setCodigosPersonalizados(updated);
      localStorage.setItem('codigosPersonalizados', JSON.stringify(updated));
    }
    setNuevoCodigoValor('');
  };

  const eliminarCodigo = (rol: string, codigo: string) => {
    const updated = { ...codigosPersonalizados };
    if (updated[rol]) updated[rol] = updated[rol].filter((c: string) => c !== codigo);
    setCodigosPersonalizados(updated);
    localStorage.setItem('codigosPersonalizados', JSON.stringify(updated));
  };

  const guardarConfig = () => {
    Object.entries(configSistema).forEach(([k, v]) => {
      localStorage.setItem(`cfg_${k}`, String(v));
    });
    setConfigSaved(true);
    setTimeout(() => setConfigSaved(false), 2500);
  };

  const exportarUsuarios = () => {
    const data = usuarios.map(({ password, ...u }) => u);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'usuarios_fortuna_ij.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const getRoleName = (role: string) => {
    const map: Record<string, string> = {
      gerente_general: 'Gerente General', admin_inventario: 'Admin. Inventario',
      subgerente: 'Subgerente', cliente: 'Cliente',
    };
    return map[role] || role;
  };

  const getRoleColor = (role: string) => {
    const map: Record<string, string> = {
      gerente_general: 'bg-red-500/20 text-red-400 border-red-500/40',
      subgerente: 'bg-purple-500/20 text-purple-400 border-purple-500/40',
      admin_inventario: 'bg-blue-500/20 text-blue-400 border-blue-500/40',
      cliente: 'bg-green-500/20 text-green-400 border-green-500/40',
    };
    return map[role] || 'bg-gray-500/20 text-gray-400 border-gray-500/40';
  };

  const productos = JSON.parse(localStorage.getItem('productos') || '[]');
  const pedidos = JSON.parse(localStorage.getItem('pedidos') || '[]');
  const ventas = JSON.parse(localStorage.getItem('ventas') || '[]');
  const pqrs = JSON.parse(localStorage.getItem('pqrs') || '[]');

  const stats = {
    totalUsuarios: usuarios.length,
    totalProductos: productos.length,
    totalPedidos: pedidos.length,
    totalVentas: ventas.length,
    pqrsAbiertos: pqrs.filter((p: any) => p.estado === 'abierto').length,
    valorTotalVentas: ventas.reduce((sum: number, v: any) => sum + (v.total || 0), 0),
    usuariosActivos: usuarios.filter(u => u.activo !== false).length,
  };

  const usuariosFiltrados = usuarios.filter(u => {
    const matchSearch = u.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchRole = filterRole === 'all' || u.role === filterRole;
    return matchSearch && matchRole;
  });

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'usuarios', label: 'Usuarios', icon: <Users className="w-4 h-4" /> },
    { id: 'estadisticas', label: 'Estadísticas', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'codigos', label: 'Códigos', icon: <Key className="w-4 h-4" /> },
    { id: 'configuracion', label: 'Configuración', icon: <Settings className="w-4 h-4" /> },
    { id: 'auditoria', label: 'Auditoría', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-br from-red-500 via-red-600 to-orange-600 p-3 rounded-2xl shadow-xl shadow-red-500/40 ring-1 ring-red-400/30">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-3xl text-white font-black tracking-tight">Panel de Administración</h2>
            <p className="text-gray-400 text-sm mt-0.5">Control total · Sistema Dotaciones Fortuna IJ</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportarUsuarios}
            className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-yellow-500/50 text-gray-300 hover:text-white rounded-xl transition-all text-sm font-medium"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { icon: <Users className="w-5 h-5" />, value: stats.totalUsuarios, label: 'Usuarios', color: 'blue', sub: `${stats.usuariosActivos} activos` },
          { icon: <Package className="w-5 h-5" />, value: stats.totalProductos, label: 'Productos', color: 'yellow', sub: 'en catálogo' },
          { icon: <ShoppingBag className="w-5 h-5" />, value: stats.totalPedidos, label: 'Pedidos', color: 'purple', sub: 'totales' },
          { icon: <TrendingUp className="w-5 h-5" />, value: stats.totalVentas, label: 'Ventas', color: 'green', sub: 'realizadas' },
          { icon: <Activity className="w-5 h-5" />, value: stats.pqrsAbiertos, label: 'PQRS', color: 'orange', sub: 'abiertos' },
          { icon: <BarChart3 className="w-5 h-5" />, value: `$${(stats.valorTotalVentas / 1000000).toFixed(1)}M`, label: 'Ingresos', color: 'teal', sub: 'COP total' },
          { icon: <Server className="w-5 h-5" />, value: '99.9%', label: 'Uptime', color: 'emerald', sub: 'sistema' },
        ].map((item, i) => {
          const colors: Record<string, string> = {
            blue: 'border-blue-500/30 hover:border-blue-500/60 text-blue-400',
            yellow: 'border-yellow-500/30 hover:border-yellow-500/60 text-yellow-400',
            purple: 'border-purple-500/30 hover:border-purple-500/60 text-purple-400',
            green: 'border-green-500/30 hover:border-green-500/60 text-green-400',
            orange: 'border-orange-500/30 hover:border-orange-500/60 text-orange-400',
            teal: 'border-teal-500/30 hover:border-teal-500/60 text-teal-400',
            emerald: 'border-emerald-500/30 hover:border-emerald-500/60 text-emerald-400',
          };
          return (
            <div key={i} className={`bg-zinc-900/80 backdrop-blur border ${colors[item.color]} rounded-xl p-3 hover:scale-105 transition-all cursor-default`}>
              <div className={`mb-2 ${colors[item.color].split(' ').find(c => c.startsWith('text-'))}`}>{item.icon}</div>
              <p className="text-xl text-white font-black">{item.value}</p>
              <p className="text-gray-400 text-xs font-medium">{item.label}</p>
              <p className="text-gray-600 text-xs">{item.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl overflow-hidden">
        <div className="flex gap-1 p-2 border-b border-zinc-800 bg-zinc-950/50 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-black shadow-lg shadow-yellow-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* TAB: USUARIOS */}
          {activeTab === 'usuarios' && (
            <div className="space-y-4">
              {/* Botón registrar empleado */}
              <div className="flex justify-end">
                <button
                  onClick={() => { setShowCrearEmpleado(true); setCrearError(''); setCrearSuccess(''); }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black rounded-xl font-bold text-sm transition-all hover:scale-105 shadow-lg shadow-yellow-500/20"
                >
                  <UserPlus className="w-4 h-4" />
                  Registrar Empleado
                </button>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Buscar por nombre o email..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder-gray-500 text-sm focus:outline-none focus:border-yellow-500/50 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                  />
                </div>
                <select
                  value={filterRole}
                  onChange={e => setFilterRole(e.target.value)}
                  className="px-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500/50 transition-all cursor-pointer"
                >
                  <option value="all">Todos</option>
                  <optgroup label="── Empleados ──">
                    <option value="gerente_general">Gerente General</option>
                    <option value="subgerente">Subgerente</option>
                    <option value="admin_inventario">Admin. Inventario</option>
                  </optgroup>
                  <optgroup label="── Clientes ──">
                    <option value="cliente">Cliente</option>
                  </optgroup>
                </select>
                <div className="flex items-center gap-2 text-gray-500 text-sm bg-zinc-800/30 px-3 py-2 rounded-xl border border-zinc-800">
                  <Filter className="w-4 h-4" />
                  <span>{usuariosFiltrados.length} resultado{usuariosFiltrados.length !== 1 ? 's' : ''}</span>
                </div>
              </div>

              {/* ── SECCIÓN EMPLEADOS ── */}
              {(() => {
                const empleados = usuariosFiltrados.filter(u => u.role !== 'cliente');
                return (
                  <div className="rounded-xl border border-yellow-500/20 overflow-hidden">
                    <div className="flex items-center justify-between px-5 py-3 bg-yellow-500/8 border-b border-yellow-500/20">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-yellow-500" />
                        <span className="text-yellow-400 font-bold text-sm">Empleados</span>
                        <span className="bg-yellow-500/20 text-yellow-400 text-xs font-bold px-2 py-0.5 rounded-full">{empleados.length}</span>
                      </div>
                      <span className="text-gray-600 text-xs">Gerente · Subgerente · Admin Inventario</span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-zinc-800/60 border-b border-zinc-700/60">
                            {['Empleado', 'Email', 'Rol', 'Código', 'Estado', 'Acciones'].map(h => (
                              <th key={h} className="text-left text-yellow-500/70 text-xs font-bold uppercase tracking-wider px-5 py-3">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800/50">
                          {empleados.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="text-center text-gray-600 py-8 text-sm">
                                <Shield className="w-7 h-7 mx-auto mb-2 opacity-20" />
                                No hay empleados registrados
                              </td>
                            </tr>
                          ) : empleados.map(u => (
                            <tr key={u.id} className={`hover:bg-zinc-800/30 transition-colors ${u.activo === false ? 'opacity-50' : ''}`}>
                              <td className="px-5 py-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-black text-xs font-black flex-shrink-0">
                                    {u.nombre.charAt(0).toUpperCase()}
                                  </div>
                                  <div>
                                    <p className="text-white font-semibold text-sm">{u.nombre}</p>
                                    {u.id === user?.id && <span className="text-yellow-500 text-xs">(tú)</span>}
                                  </div>
                                </div>
                              </td>
                              <td className="px-5 py-3 text-gray-400 text-sm">{u.email}</td>
                              <td className="px-5 py-3">
                                <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${getRoleColor(u.role)}`}>
                                  {getRoleName(u.role)}
                                </span>
                              </td>
                              <td className="px-5 py-3">
                                {u.codigoEmpleado ? (
                                  <div className="flex items-center gap-1.5">
                                    <Key className="w-3.5 h-3.5 text-yellow-500/70" />
                                    <span className="font-mono text-xs text-gray-300">
                                      {showPasswords[u.id] ? u.codigoEmpleado : '•••••••'}
                                    </span>
                                    <button onClick={() => setShowPasswords(p => ({ ...p, [u.id]: !p[u.id] }))} className="text-gray-600 hover:text-gray-400 transition-colors">
                                      {showPasswords[u.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                    </button>
                                  </div>
                                ) : <span className="text-gray-700 text-xs">—</span>}
                              </td>
                              <td className="px-5 py-3">
                                <span className={`flex items-center gap-1.5 text-xs font-semibold ${u.activo === false ? 'text-red-400' : 'text-green-400'}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${u.activo === false ? 'bg-red-400' : 'bg-green-400'}`} />
                                  {u.activo === false ? 'Inactivo' : 'Activo'}
                                </span>
                              </td>
                              <td className="px-5 py-3">
                                <div className="flex gap-1.5">
                                  <button onClick={() => { setSelectedUser(u); setNewRole(u.role); setNewCodigoEmpleado(u.codigoEmpleado || ''); setShowModal(true); }} title="Editar rol" className="p-1.5 bg-blue-500/10 hover:bg-blue-500/25 text-blue-400 rounded-lg transition-all hover:scale-105"><Edit className="w-3.5 h-3.5" /></button>
                                  <button onClick={() => toggleActivo(u.id)} title={u.activo === false ? 'Activar' : 'Desactivar'} disabled={u.id === user?.id} className="p-1.5 bg-yellow-500/10 hover:bg-yellow-500/25 text-yellow-400 rounded-lg transition-all hover:scale-105 disabled:opacity-30 disabled:cursor-not-allowed">
                                    {u.activo === false ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                                  </button>
                                  <button onClick={() => confirmarEliminar(u)} title="Eliminar" disabled={u.id === user?.id} className="p-1.5 bg-red-500/10 hover:bg-red-500/25 text-red-400 rounded-lg transition-all hover:scale-105 disabled:opacity-30 disabled:cursor-not-allowed"><Trash2 className="w-3.5 h-3.5" /></button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}

              {/* ── SECCIÓN CLIENTES ── */}
              {(() => {
                const clientes = usuariosFiltrados.filter(u => u.role === 'cliente');
                return (
                  <div className="rounded-xl border border-green-500/20 overflow-hidden">
                    <div className="flex items-center justify-between px-5 py-3 bg-green-500/5 border-b border-green-500/20">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-green-500" />
                        <span className="text-green-400 font-bold text-sm">Clientes</span>
                        <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2 py-0.5 rounded-full">{clientes.length}</span>
                      </div>
                      <span className="text-gray-600 text-xs">Registrados desde la página pública</span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-zinc-800/60 border-b border-zinc-700/60">
                            {['Cliente', 'Email', 'Estado', 'Acciones'].map(h => (
                              <th key={h} className="text-left text-green-500/70 text-xs font-bold uppercase tracking-wider px-5 py-3">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800/50">
                          {clientes.length === 0 ? (
                            <tr>
                              <td colSpan={4} className="text-center text-gray-600 py-8 text-sm">
                                <Users className="w-7 h-7 mx-auto mb-2 opacity-20" />
                                No hay clientes registrados
                              </td>
                            </tr>
                          ) : clientes.map(u => (
                            <tr key={u.id} className={`hover:bg-zinc-800/30 transition-colors ${u.activo === false ? 'opacity-50' : ''}`}>
                              <td className="px-5 py-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center text-white text-xs font-black flex-shrink-0">
                                    {u.nombre.charAt(0).toUpperCase()}
                                  </div>
                                  <p className="text-white font-semibold text-sm">{u.nombre}</p>
                                </div>
                              </td>
                              <td className="px-5 py-3 text-gray-400 text-sm">{u.email}</td>
                              <td className="px-5 py-3">
                                <span className={`flex items-center gap-1.5 text-xs font-semibold ${u.activo === false ? 'text-red-400' : 'text-green-400'}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${u.activo === false ? 'bg-red-400' : 'bg-green-400'}`} />
                                  {u.activo === false ? 'Inactivo' : 'Activo'}
                                </span>
                              </td>
                              <td className="px-5 py-3">
                                <div className="flex gap-1.5">
                                  <button onClick={() => toggleActivo(u.id)} title={u.activo === false ? 'Activar' : 'Desactivar'} className="p-1.5 bg-yellow-500/10 hover:bg-yellow-500/25 text-yellow-400 rounded-lg transition-all hover:scale-105">
                                    {u.activo === false ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                                  </button>
                                  <button onClick={() => confirmarEliminar(u)} title="Eliminar" className="p-1.5 bg-red-500/10 hover:bg-red-500/25 text-red-400 rounded-lg transition-all hover:scale-105"><Trash2 className="w-3.5 h-3.5" /></button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}

              {/* Distribución de roles */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2">
                {(['gerente_general', 'subgerente', 'admin_inventario', 'cliente'] as UserRole[]).map(role => {
                  const count = usuarios.filter(u => u.role === role).length;
                  const pct = usuarios.length > 0 ? Math.round((count / usuarios.length) * 100) : 0;
                  return (
                    <div key={role} className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-gray-400 text-xs font-medium">{getRoleName(role)}</span>
                        <span className="text-white text-xs font-bold">{count}</span>
                      </div>
                      <div className="w-full bg-zinc-700/50 rounded-full h-1.5">
                        <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 h-1.5 rounded-full transition-all" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-gray-600 text-xs">{pct}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: ESTADÍSTICAS */}
          {activeTab === 'estadisticas' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Resumen módulos */}
                <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <PieChart className="w-5 h-5 text-yellow-500" />
                    <h4 className="text-white font-bold">Resumen del Sistema</h4>
                  </div>
                  <div className="space-y-3">
                    {[
                      { label: 'Usuarios registrados', value: stats.totalUsuarios, max: 50, color: 'from-blue-500 to-blue-600' },
                      { label: 'Productos activos', value: stats.totalProductos, max: 500, color: 'from-yellow-500 to-yellow-600' },
                      { label: 'Pedidos procesados', value: stats.totalPedidos, max: 200, color: 'from-purple-500 to-purple-600' },
                      { label: 'Ventas completadas', value: stats.totalVentas, max: 200, color: 'from-green-500 to-green-600' },
                      { label: 'PQRS abiertas', value: stats.pqrsAbiertos, max: 50, color: 'from-orange-500 to-orange-600' },
                    ].map(item => (
                      <div key={item.label}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">{item.label}</span>
                          <span className="text-white font-semibold">{item.value}</span>
                        </div>
                        <div className="w-full bg-zinc-700/50 rounded-full h-2">
                          <div
                            className={`bg-gradient-to-r ${item.color} h-2 rounded-full transition-all`}
                            style={{ width: `${Math.min((item.value / item.max) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Métricas financieras */}
                <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                    <h4 className="text-white font-bold">Métricas Financieras</h4>
                  </div>
                  <div className="space-y-4">
                    <div className="bg-gradient-to-br from-green-500/10 to-teal-500/10 border border-green-500/20 rounded-xl p-4">
                      <p className="text-gray-400 text-xs mb-1">Ingresos Totales</p>
                      <p className="text-3xl text-white font-black">
                        ${stats.valorTotalVentas.toLocaleString('es-CO', {maximumFractionDigits: 0})}
                        <span className="text-gray-500 text-sm font-normal ml-1">COP</span>
                      </p>
                      <div className="flex items-center gap-1 mt-1">
                        <ArrowUp className="w-3 h-3 text-green-400" />
                        <span className="text-green-400 text-xs">Crecimiento positivo</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-zinc-700/30 border border-zinc-700 rounded-xl p-3">
                        <p className="text-gray-500 text-xs">Ticket Promedio</p>
                        <p className="text-white font-bold text-lg">
                          ${stats.totalVentas > 0 ? Math.round(stats.valorTotalVentas / stats.totalVentas).toLocaleString('es-CO', {maximumFractionDigits: 0}) : 0}
                        </p>
                      </div>
                      <div className="bg-zinc-700/30 border border-zinc-700 rounded-xl p-3">
                        <p className="text-gray-500 text-xs">IVA Generado ({configSistema.ivaPorcentaje}%)</p>
                        <p className="text-white font-bold text-lg">
                          ${Math.round(stats.valorTotalVentas * (parseInt(configSistema.ivaPorcentaje) / (100 + parseInt(configSistema.ivaPorcentaje)))).toLocaleString('es-CO', {maximumFractionDigits: 0})}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Estado de módulos */}
              <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Globe className="w-5 h-5 text-blue-500" />
                  <h4 className="text-white font-bold">Estado de Módulos</h4>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { nombre: 'Productos', estado: 'operativo', usuarios: stats.totalProductos },
                    { nombre: 'Ventas', estado: 'operativo', usuarios: stats.totalVentas },
                    { nombre: 'Inventario', estado: stats.totalProductos > 0 ? 'operativo' : 'atención', usuarios: stats.totalProductos },
                    { nombre: 'Pedidos', estado: 'operativo', usuarios: stats.totalPedidos },
                    { nombre: 'PQRS', estado: stats.pqrsAbiertos > 10 ? 'atención' : 'operativo', usuarios: stats.pqrsAbiertos },
                    { nombre: 'Tickets', estado: 'operativo', usuarios: 0 },
                    { nombre: 'Guías', estado: 'operativo', usuarios: 0 },
                    { nombre: 'Admin', estado: 'operativo', usuarios: stats.totalUsuarios },
                  ].map(mod => (
                    <div key={mod.nombre} className={`border rounded-xl p-3 flex items-center gap-2 ${
                      mod.estado === 'operativo' ? 'border-green-500/20 bg-green-500/5' : 'border-yellow-500/20 bg-yellow-500/5'
                    }`}>
                      {mod.estado === 'operativo'
                        ? <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                        : <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                      }
                      <div>
                        <p className="text-white text-xs font-semibold">{mod.nombre}</p>
                        <p className={`text-xs ${mod.estado === 'operativo' ? 'text-green-500' : 'text-yellow-500'}`}>
                          {mod.estado === 'operativo' ? 'Operativo' : 'Atención'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: CÓDIGOS */}
          {activeTab === 'codigos' && (
            <div className="space-y-6">
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex gap-3">
                <AlertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-yellow-400 font-semibold text-sm">Información Confidencial</p>
                  <p className="text-gray-400 text-xs mt-0.5">Los códigos de empleado dan acceso a roles administrativos. Maneja esta información con discreción.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {(['gerente_general', 'subgerente', 'admin_inventario'] as UserRole[]).map(rol => {
                  const sistemaCodigos = CODIGOS_SISTEMA[rol] || [];
                  const personalizados = codigosPersonalizados[rol] || [];
                  const todos = [...new Set([...sistemaCodigos, ...personalizados])];
                  return (
                    <div key={rol} className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-5">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="text-white font-bold text-sm">{getRoleName(rol)}</h4>
                          <p className="text-gray-500 text-xs">{todos.length} código{todos.length !== 1 ? 's' : ''}</p>
                        </div>
                        <button
                          onClick={() => setCodigosVisibles(p => ({ ...p, [rol]: !p[rol] }))}
                          className="p-1.5 bg-zinc-700 hover:bg-zinc-600 text-gray-400 rounded-lg transition-all"
                        >
                          {codigosVisibles[rol] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <div className="space-y-2">
                        {todos.map(codigo => (
                          <div key={codigo} className="flex items-center justify-between bg-zinc-900/60 border border-zinc-700/50 rounded-lg px-3 py-2">
                            <div className="flex items-center gap-2">
                              <Key className="w-3.5 h-3.5 text-yellow-500/60" />
                              <span className="font-mono text-xs text-gray-300">
                                {codigosVisibles[rol] ? codigo : '•'.repeat(codigo.length)}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              {personalizados.includes(codigo) ? (
                                <>
                                  <span className="text-blue-400 text-xs">custom</span>
                                  <button
                                    onClick={() => eliminarCodigo(rol, codigo)}
                                    className="p-0.5 text-red-400/60 hover:text-red-400 transition-colors"
                                  >
                                    <XCircle className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              ) : (
                                <span className="text-green-400 text-xs">sistema</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Agregar código personalizado */}
              <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-5">
                <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-yellow-500" />
                  Agregar Código Personalizado
                </h4>
                <div className="flex flex-col sm:flex-row gap-3">
                  <select
                    value={nuevoCodigoRol}
                    onChange={e => setNuevoCodigoRol(e.target.value as UserRole)}
                    className="px-4 py-2.5 bg-zinc-900/60 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500/50 transition-all cursor-pointer"
                  >
                    <option value="gerente_general">Gerente General</option>
                    <option value="subgerente">Subgerente</option>
                    <option value="admin_inventario">Admin. Inventario</option>
                  </select>
                  <input
                    type="text"
                    value={nuevoCodigoValor}
                    onChange={e => setNuevoCodigoValor(e.target.value.toUpperCase())}
                    placeholder="EJ: GG-2026, SUB-003..."
                    className="flex-1 px-4 py-2.5 bg-zinc-900/60 border border-zinc-700 rounded-xl text-white font-mono text-sm placeholder-gray-600 focus:outline-none focus:border-yellow-500/50 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                  />
                  <button
                    onClick={agregarCodigo}
                    disabled={!nuevoCodigoValor.trim()}
                    className="px-5 py-2.5 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 disabled:opacity-40 disabled:cursor-not-allowed text-black font-bold rounded-xl transition-all hover:scale-105 shadow-lg shadow-yellow-500/20 text-sm"
                  >
                    Agregar
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB: CONFIGURACIÓN */}
          {activeTab === 'configuracion' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="text-white font-bold flex items-center gap-2">
                    <Settings className="w-4 h-4 text-yellow-500" />
                    Configuración General
                  </h4>
                  {[
                    { key: 'nombreEmpresa', label: 'Nombre de la Empresa', type: 'text' },
                    { key: 'moneda', label: 'Moneda', type: 'text' },
                    { key: 'maxProductos', label: 'Límite de Productos', type: 'number' },
                    { key: 'ivaPorcentaje', label: 'Porcentaje IVA (%)', type: 'number' },
                    { key: 'descuentoMaximo', label: 'Descuento Máximo (%)', type: 'number' },
                  ].map(field => (
                    <div key={field.key}>
                      <label className="block text-gray-400 text-xs font-semibold uppercase tracking-wide mb-1.5">{field.label}</label>
                      <input
                        type={field.type}
                        value={(configSistema as any)[field.key]}
                        onChange={e => setConfigSistema(p => ({ ...p, [field.key]: e.target.value }))}
                        className="w-full px-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500/50 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                      />
                    </div>
                  ))}
                </div>

                <div className="space-y-4">
                  <h4 className="text-white font-bold flex items-center gap-2">
                    <Bell className="w-4 h-4 text-blue-500" />
                    Preferencias del Sistema
                  </h4>
                  <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white text-sm font-semibold">Notificaciones del sistema</p>
                        <p className="text-gray-500 text-xs">Alertas de actividad y eventos</p>
                      </div>
                      <button
                        onClick={() => setConfigSistema(p => ({ ...p, notificaciones: !p.notificaciones }))}
                        className={`w-11 h-6 rounded-full transition-all relative ${configSistema.notificaciones ? 'bg-yellow-500' : 'bg-zinc-700'}`}
                      >
                        <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${configSistema.notificaciones ? 'left-5' : 'left-0.5'}`} />
                      </button>
                    </div>
                  </div>

                  <div className="bg-zinc-800/40 border border-zinc-800 rounded-xl p-4 space-y-3">
                    <p className="text-white text-sm font-semibold flex items-center gap-2">
                      <Database className="w-4 h-4 text-teal-400" />
                      Información de Almacenamiento
                    </p>
                    {['users', 'productos', 'pedidos', 'ventas', 'pqrs'].map(key => {
                      const data = localStorage.getItem(key);
                      const size = data ? new Blob([data]).size : 0;
                      return (
                        <div key={key} className="flex justify-between items-center">
                          <span className="text-gray-400 text-xs capitalize">{key}</span>
                          <span className="text-gray-300 text-xs font-mono">{(size / 1024).toFixed(2)} KB</span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 space-y-3">
                    <p className="text-red-400 text-sm font-semibold flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      Zona de Peligro
                    </p>
                    <button
                      onClick={() => {
                        if (confirm('¿Limpiar logs de auditoría? Esta acción no se puede deshacer.')) {
                          localStorage.removeItem('auditLog');
                        }
                      }}
                      className="w-full px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 rounded-lg text-xs font-semibold transition-all text-left"
                    >
                      Limpiar logs de auditoría
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2 border-t border-zinc-800">
                <button
                  onClick={() => {
                    setConfigSistema({
                      nombreEmpresa: 'Dotaciones Fortuna IJ', maxProductos: '500',
                      ivaPorcentaje: '19', descuentoMaximo: '30', moneda: 'COP', notificaciones: true,
                    });
                  }}
                  className="px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-gray-300 rounded-xl text-sm font-semibold transition-all"
                >
                  <RefreshCw className="w-4 h-4 inline mr-1.5" />
                  Restaurar
                </button>
                <button
                  onClick={guardarConfig}
                  className={`px-6 py-2.5 font-bold rounded-xl text-sm transition-all hover:scale-105 shadow-lg ${
                    configSaved
                      ? 'bg-green-500 text-white shadow-green-500/30'
                      : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black shadow-yellow-500/30'
                  }`}
                >
                  {configSaved ? (
                    <><CheckCircle className="w-4 h-4 inline mr-1.5" />Guardado</>
                  ) : (
                    'Guardar Cambios'
                  )}
                </button>
              </div>
            </div>
          )}

          {/* TAB: AUDITORÍA */}
          {activeTab === 'auditoria' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-white font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-500" />
                  Registro de Actividad
                </h4>
                <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-zinc-800/50 px-3 py-1.5 rounded-lg border border-zinc-700">
                  <Clock className="w-3.5 h-3.5" />
                  En tiempo real
                </div>
              </div>

              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {[
                  { tipo: 'info', accion: `Sesión iniciada por ${user?.nombre}`, modulo: 'Autenticación', fecha: new Date() },
                  { tipo: 'success', accion: 'Panel de administración accedido', modulo: 'Administración', fecha: new Date(Date.now() - 60000) },
                  { tipo: 'info', accion: `${usuarios.length} usuarios cargados`, modulo: 'Usuarios', fecha: new Date(Date.now() - 120000) },
                  { tipo: 'info', accion: `${productos.length} productos en catálogo`, modulo: 'Inventario', fecha: new Date(Date.now() - 180000) },
                  { tipo: ventas.length > 0 ? 'success' : 'warning', accion: `${ventas.length} ventas registradas`, modulo: 'Ventas', fecha: new Date(Date.now() - 240000) },
                  { tipo: pqrs.filter((p: any) => p.estado === 'abierto').length > 0 ? 'warning' : 'success', accion: `${pqrs.filter((p: any) => p.estado === 'abierto').length} PQRS pendientes`, modulo: 'PQRS', fecha: new Date(Date.now() - 300000) },
                  ...auditLog.slice(0, 10),
                ].map((log, i) => {
                  const tipoConfig = {
                    info: { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: <Activity className="w-3.5 h-3.5" /> },
                    success: { color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: <CheckCircle className="w-3.5 h-3.5" /> },
                    warning: { color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', icon: <AlertTriangle className="w-3.5 h-3.5" /> },
                    error: { color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: <XCircle className="w-3.5 h-3.5" /> },
                  };
                  const cfg = tipoConfig[log.tipo as keyof typeof tipoConfig] || tipoConfig.info;
                  const fecha = log.fecha instanceof Date ? log.fecha : new Date(log.fecha);
                  return (
                    <div key={i} className={`flex items-start gap-3 border rounded-xl px-4 py-3 ${cfg.color}`}>
                      <span className="mt-0.5 flex-shrink-0">{cfg.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{log.accion}</p>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs opacity-70">{log.modulo}</span>
                          <span className="text-xs text-gray-600">{fecha.toLocaleTimeString('es-CO')}</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 opacity-30 flex-shrink-0 mt-0.5" />
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-zinc-800">
                {[
                  { label: 'Eventos Info', count: 4, color: 'text-blue-400' },
                  { label: 'Exitosos', count: 2, color: 'text-green-400' },
                  { label: 'Advertencias', count: pqrs.filter((p: any) => p.estado === 'abierto').length > 0 ? 1 : 0, color: 'text-yellow-400' },
                ].map(item => (
                  <div key={item.label} className="text-center bg-zinc-800/40 rounded-xl py-3">
                    <p className={`text-2xl font-black ${item.color}`}>{item.count}</p>
                    <p className="text-gray-500 text-xs">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <PQRSWidget modulo="administrativo" titulo="PQRS — Administrativo" />

      {/* Modal: Registrar Empleado */}
      {showCrearEmpleado && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900 border border-yellow-500/40 rounded-2xl max-w-md w-full p-6 shadow-2xl shadow-yellow-500/10">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="bg-yellow-500/10 p-2.5 rounded-xl">
                  <UserPlus className="w-5 h-5 text-yellow-500" />
                </div>
                <div>
                  <h3 className="text-white font-black text-lg">Registrar Empleado</h3>
                  <p className="text-gray-500 text-xs">Solo visible para el Gerente General</p>
                </div>
              </div>
              <button onClick={() => setShowCrearEmpleado(false)} className="p-1.5 text-gray-600 hover:text-gray-400 rounded-lg transition-colors">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              {[
                { label: 'Nombre Completo', key: 'nombre', type: 'text', placeholder: 'Ej: Carlos Ramírez' },
                { label: 'Correo Electrónico', key: 'email', type: 'email', placeholder: 'empleado@empresa.com' },
                { label: 'Contraseña', key: 'password', type: 'password', placeholder: 'Mínimo 6 caracteres' },
              ].map(field => (
                <div key={field.key}>
                  <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-1.5">{field.label}</label>
                  <input
                    type={field.type}
                    value={(crearForm as any)[field.key]}
                    onChange={e => setCrearForm(f => ({ ...f, [field.key]: e.target.value }))}
                    placeholder={field.placeholder}
                    className="w-full px-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                  />
                </div>
              ))}

              <div>
                <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-1.5">Rol</label>
                <select
                  value={crearForm.role}
                  onChange={e => setCrearForm(f => ({ ...f, role: e.target.value as UserRole }))}
                  className="w-full px-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all cursor-pointer"
                >
                  <option value="subgerente">Subgerente</option>
                  <option value="admin_inventario">Administrador de Inventario</option>
                  <option value="gerente_general">Gerente General</option>
                </select>
              </div>

              <div>
                <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-1.5">Código de Empleado</label>
                <input
                  type="text"
                  value={crearForm.codigoEmpleado}
                  onChange={e => setCrearForm(f => ({ ...f, codigoEmpleado: e.target.value.toUpperCase() }))}
                  placeholder="EMP-0001"
                  className="w-full px-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white font-mono text-sm placeholder-gray-600 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                />
              </div>

              {crearError && (
                <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-3 py-2 rounded-lg text-sm">
                  {crearError}
                </div>
              )}
              {crearSuccess && (
                <div className="bg-green-500/10 border border-green-500/30 text-green-400 px-3 py-2 rounded-lg text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" /> {crearSuccess}
                </div>
              )}

              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => setShowCrearEmpleado(false)}
                  className="flex-1 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all font-semibold text-sm"
                >
                  Cancelar
                </button>
                <button
                  onClick={crearEmpleado}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black rounded-xl transition-all hover:scale-105 font-black shadow-lg shadow-yellow-500/30 text-sm"
                >
                  Registrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Editar Usuario */}
      {showModal && selectedUser && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900 border border-yellow-500/40 rounded-2xl max-w-md w-full p-6 shadow-2xl shadow-yellow-500/10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-500 to-yellow-700 flex items-center justify-center text-black font-black">
                {selectedUser.nombre.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="text-white font-black text-lg">Editar Usuario</h3>
                <p className="text-gray-500 text-xs">{selectedUser.email}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-2">Nuevo Rol</label>
                <select
                  value={newRole}
                  onChange={e => setNewRole(e.target.value as UserRole)}
                  className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all cursor-pointer text-sm"
                >
                  <option value="cliente">Cliente</option>
                  <option value="admin_inventario">Administrador de Inventario</option>
                  <option value="subgerente">Subgerente</option>
                  <option value="gerente_general">Gerente General</option>
                </select>
              </div>

              {newRole !== 'cliente' && (
                <div>
                  <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-2">Código de Empleado</label>
                  <input
                    type="text"
                    value={newCodigoEmpleado}
                    onChange={e => setNewCodigoEmpleado(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white font-mono text-sm focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                    placeholder="EMP-XXXX"
                  />
                  <p className="text-gray-600 text-xs mt-1">Requerido para roles administrativos</p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => { setShowModal(false); setSelectedUser(null); }}
                  className="flex-1 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all font-semibold text-sm"
                >
                  Cancelar
                </button>
                <button
                  onClick={cambiarRol}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black rounded-xl transition-all hover:scale-105 font-black shadow-lg shadow-yellow-500/30 text-sm"
                >
                  Guardar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirmar Eliminación */}
      {showDeleteModal && userToDelete && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900 border border-red-500/40 rounded-2xl max-w-sm w-full p-6 shadow-2xl shadow-red-500/10">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-red-500/10 p-2.5 rounded-xl">
                <AlertTriangle className="w-6 h-6 text-red-400" />
              </div>
              <h3 className="text-white font-black text-lg">Confirmar Eliminación</h3>
            </div>
            <p className="text-gray-400 text-sm mb-6">
              ¿Estás seguro de eliminar a <span className="text-white font-semibold">{userToDelete.nombre}</span>? Esta acción no se puede deshacer.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => { setShowDeleteModal(false); setUserToDelete(null); }}
                className="flex-1 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all font-semibold text-sm"
              >
                Cancelar
              </button>
              <button
                onClick={eliminarUsuario}
                className="flex-1 px-4 py-2.5 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-xl transition-all hover:scale-105 font-black shadow-lg shadow-red-500/30 text-sm"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
