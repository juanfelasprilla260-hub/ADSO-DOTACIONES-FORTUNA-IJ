import React from 'react';
import { X } from 'lucide-react';

export interface PedidoParaTicket {
  id: string;
  ticketId?: string;
  clienteNombre: string;
  clienteEmail: string;
  productos: Array<{ nombre: string; cantidad: number; precio: number }>;
  total: number;
  estado: string;
  fecha: string;
}

interface Props {
  pedido: PedidoParaTicket;
  onClose: () => void;
}

const BADGE_ESTADO: Record<string, { bg: string; color: string }> = {
  pendiente:   { bg: '#78350f',  color: '#fbbf24' },
  fabricando:  { bg: '#1e3a5f',  color: '#60a5fa' },
  procesando:  { bg: '#1e3a5f',  color: '#60a5fa' },
  enviado:     { bg: '#2d1b69',  color: '#a78bfa' },
  entregado:   { bg: '#14532d',  color: '#4ade80' },
  cancelado:   { bg: '#450a0a',  color: '#f87171' },
};

export const TicketModal: React.FC<Props> = ({ pedido, onClose }) => {
  const fecha = new Date(pedido.fecha);
  const fechaStr = fecha.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const horaStr  = fecha.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const ticketNum = pedido.ticketId || pedido.id;
  const badge = BADGE_ESTADO[pedido.estado] || BADGE_ESTADO.pendiente;

  const handlePrint = () => {
    const printContent = document.getElementById('ticket-print-area');
    if (!printContent) return;
    const w = window.open('', '_blank', 'width=600,height=800');
    if (!w) return;
    w.document.write(`
      <html><head>
        <title>Ticket #${ticketNum}</title>
        <style>
          body{font-family:Inter,sans-serif;background:#0f1117;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:40px 16px;margin:0}
          .tc{background:#13151c;border:1px solid #1e2030;border-radius:16px;width:100%;max-width:520px;padding:32px;color:#e2e8f0}
          .th{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}
          .ten{font-size:16px;font-weight:800;color:#f5a623;margin-bottom:6px}
          .tei{font-size:11.5px;color:#64748b;line-height:1.7}
          .tdr{text-align:right;flex-shrink:0}
          .tdv{font-size:10px;font-weight:700;letter-spacing:2px;color:#64748b;text-transform:uppercase;margin-bottom:2px}
          .tdn{font-size:34px;font-weight:800;color:#f5a623;line-height:1}
          .tld{border:none;border-top:1px dashed #1e2030;margin:22px 0}
          .tm{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}
          .tmr{text-align:right}
          .ttc{font-size:10px;font-weight:700;letter-spacing:1.5px;color:#f5a523;text-transform:uppercase;margin-bottom:6px;opacity:.7}
          .tcn{font-size:15px;font-weight:700;color:#f1f5f9;margin-bottom:3px}
          .tce{font-size:12px;color:#64748b}
          .tfe{font-size:14px;font-weight:600;color:#f1f5f9;margin-bottom:2px}
          .tho{font-size:12px;color:#94a3b8;margin-bottom:8px}
          .tbadge{display:inline-block;background:${badge.bg};color:${badge.color};font-size:11px;font-weight:600;padding:3px 12px;border-radius:20px}
          .ttb{font-size:16px;font-weight:800;color:#f5a623;margin-bottom:6px}
          table{width:100%;border-collapse:collapse;margin-top:12px;font-size:13px}
          thead tr{background:#1e2030}
          th{padding:9px 10px;font-size:10.5px;font-weight:700;letter-spacing:.8px;color:#f5a623;text-transform:uppercase;text-align:left;opacity:.7}
          th:not(:first-child){text-align:right}
          td{padding:10px;color:#cbd5e1;border-bottom:1px solid #1a1d2a}
          td:not(:first-child){text-align:right;color:#94a3b8}
          tr.fp{background:#16182a}
          .ttot{display:flex;justify-content:space-between;align-items:center;background:#1a1d2a;border:1px solid #f5a623;border-radius:10px;padding:14px 18px;margin-top:18px}
          .ttl{font-size:11px;font-weight:700;letter-spacing:1.5px;color:#94a3b8;text-transform:uppercase}
          .ttv{font-size:26px;font-weight:800;color:#f5a623}
          .tfin{text-align:center;font-size:11px;color:#4a5568;line-height:1.8}
          @media print{body{background:#fff!important;color:#000!important}.tc{background:#fff!important;color:#000!important;border:none}button{display:none!important}}
        </style>
      </head><body>${printContent.innerHTML}</body></html>
    `);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 300);
  };

  return (
    <div
      className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="relative w-full max-w-lg my-4">
        {/* Botón cerrar */}
        <button
          onClick={onClose}
          className="absolute -top-3 -right-3 z-10 w-8 h-8 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* ── TICKET CARD (fiel al ticket.html + ticket.css) ── */}
        <div
          id="ticket-print-area"
          style={{
            backgroundColor: '#13151c',
            border: '1px solid #1e2030',
            borderRadius: '16px',
            width: '100%',
            padding: '32px',
            color: '#e2e8f0',
            fontFamily: 'Inter, sans-serif',
          }}
        >
          {/* ── Encabezado ── */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
            <div>
              <p style={{ fontSize: '16px', fontWeight: 800, color: '#f5a623', marginBottom: '6px' }}>
                Dotaciones Fortuna IJ
              </p>
              <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>NIT: 900.123.456-7</p>
              <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>Cra 63 No. 22 - 22 sur, Bogotá</p>
              <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>Tel: 312 388 8729</p>
            </div>
            <div style={{ textAlign: 'right', flexShrink: 0 }}>
              <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '2px', color: '#64748b', textTransform: 'uppercase', marginBottom: '2px' }}>
                TICKET DE VENTA
              </p>
              <p style={{ fontSize: '34px', fontWeight: 800, color: '#f5a623', lineHeight: 1 }}>
                # {ticketNum.toString().slice(-4).padStart(1, '')}
              </p>
            </div>
          </div>

          {/* Línea divisora */}
          <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

          {/* ── Cliente + Fecha ── */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
            <div>
              <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '1.5px', color: '#f5a623', textTransform: 'uppercase', marginBottom: '6px', opacity: 0.7 }}>
                CLIENTE
              </p>
              <p style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '3px' }}>
                {pedido.clienteNombre}
              </p>
              <p style={{ fontSize: '12px', color: '#64748b' }}>{pedido.clienteEmail}</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '1.5px', color: '#f5a623', textTransform: 'uppercase', marginBottom: '6px', opacity: 0.7 }}>
                FECHA
              </p>
              <p style={{ fontSize: '14px', fontWeight: 600, color: '#f1f5f9', marginBottom: '2px' }}>{fechaStr}</p>
              <p style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>{horaStr}</p>
              <span style={{
                display: 'inline-block',
                backgroundColor: badge.bg,
                color: badge.color,
                fontSize: '11px',
                fontWeight: 600,
                padding: '3px 12px',
                borderRadius: '20px',
              }}>
                {pedido.estado.charAt(0).toUpperCase() + pedido.estado.slice(1)}
              </span>
            </div>
          </div>

          {/* Línea divisora */}
          <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

          {/* ── Tabla productos ── */}
          <p style={{ fontSize: '16px', fontWeight: 800, color: '#f5a623', marginBottom: '6px' }}>PRODUCTOS</p>
          <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px', fontSize: '13px' }}>
            <thead>
              <tr style={{ backgroundColor: '#1e2030' }}>
                {['Descripción', 'Cant.', 'P. Unit.', 'Subtotal'].map((h, i) => (
                  <th key={h} style={{
                    padding: '9px 10px',
                    fontSize: '10.5px',
                    fontWeight: 700,
                    letterSpacing: '0.8px',
                    color: '#f5a623',
                    textTransform: 'uppercase',
                    textAlign: i === 0 ? 'left' : 'right',
                    opacity: 0.7,
                  }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pedido.productos.map((prod, i) => (
                <tr key={i} style={{ backgroundColor: i % 2 === 1 ? '#16182a' : 'transparent' }}>
                  <td style={{ padding: '10px', color: '#cbd5e1', borderBottom: '1px solid #1a1d2a' }}>
                    {prod.nombre}
                  </td>
                  <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right' }}>
                    {prod.cantidad}
                  </td>
                  <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                    ${prod.precio.toLocaleString('es-CO')}
                  </td>
                  <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                    ${(prod.cantidad * prod.precio).toLocaleString('es-CO')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* ── Total ── */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#1a1d2a',
            border: '1px solid #f5a623',
            borderRadius: '10px',
            padding: '14px 18px',
            marginTop: '18px',
          }}>
            <span style={{ fontSize: '11px', fontWeight: 700, letterSpacing: '1.5px', color: '#94a3b8', textTransform: 'uppercase' }}>
              TOTAL A PAGAR
            </span>
            <span style={{ fontSize: '26px', fontWeight: 800, color: '#f5a623', fontVariantNumeric: 'tabular-nums' }}>
              ${pedido.total.toLocaleString('es-CO', { maximumFractionDigits: 0 })}
            </span>
          </div>

          {/* Línea divisora */}
          <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

          {/* ── Pie ── */}
          <div style={{ textAlign: 'center', fontSize: '11px', color: '#4a5568', lineHeight: 1.8 }}>
            <p>Gracias por su pedido · Dotaciones Fortuna IJ © 2026</p>
            <p>Este documento es un comprobante interno</p>
          </div>

          {/* ── Botón imprimir ── */}
          <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'center' }}>
            <button
              onClick={handlePrint}
              style={{
                backgroundColor: '#f5a623',
                color: '#0f1117',
                border: 'none',
                borderRadius: '10px',
                padding: '12px 28px',
                fontSize: '14px',
                fontWeight: 700,
                cursor: 'pointer',
                fontFamily: 'Inter, sans-serif',
              }}
              onMouseEnter={e => { (e.target as HTMLElement).style.backgroundColor = '#d4881a'; }}
              onMouseLeave={e => { (e.target as HTMLElement).style.backgroundColor = '#f5a623'; }}
            >
              ⬇ Imprimir / Guardar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
