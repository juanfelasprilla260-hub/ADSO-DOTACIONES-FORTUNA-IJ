import React, { useState, useEffect } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, Search, Tag, Package, CheckCircle, X, Download, Receipt, DollarSign } from 'lucide-react';
import { ImageWithFallback } from '../ImageWithFallback';
import { PQRSWidget } from './PQRSWidget';
import { useAuth } from '../AuthContext';

interface Producto {
  id: string;
  nombre: string;
  precio: number;
  imagen: string;
  imagenUrl?: string;
  categoria: string;
  descripcion: string;
}

interface ItemCarrito {
  producto: Producto;
  cantidad: number;
}

const CARRITO_KEY = 'carrito';

const leerCarrito = (): ItemCarrito[] => {
  try { return JSON.parse(localStorage.getItem(CARRITO_KEY) || '[]'); }
  catch { return []; }
};

const guardarCarrito = (items: ItemCarrito[]) => {
  localStorage.setItem(CARRITO_KEY, JSON.stringify(items));
};

export const Ventas: React.FC = () => {
  const { user } = useAuth();
  const [productos, setProductos] = useState<Producto[]>([]);
  const [carrito, setCarrito] = useState<ItemCarrito[]>(leerCarrito);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>('todas');
  const [ticketModal, setTicketModal] = useState<{ ticketId: string; pedidoId: string } | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('productos');
    if (stored) setProductos(JSON.parse(stored));
  }, []);

  // Sincroniza cuando el usuario viene de Productos con items ya en localStorage
  useEffect(() => {
    const sincronizar = () => setCarrito(leerCarrito());
    window.addEventListener('storage', sincronizar);
    // También leer al montar por si ya hay items guardados
    setCarrito(leerCarrito());
    return () => window.removeEventListener('storage', sincronizar);
  }, []);

  const setCarritoYGuardar = (items: ItemCarrito[]) => {
    setCarrito(items);
    guardarCarrito(items);
  };

  const agregarAlCarrito = (producto: Producto) => {
    const actual = leerCarrito();
    const existe = actual.find(item => item.producto.id === producto.id);
    const actualizado = existe
      ? actual.map(item => item.producto.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item)
      : [...actual, { producto, cantidad: 1 }];
    setCarritoYGuardar(actualizado);
  };

  const modificarCantidad = (id: string, delta: number) => {
    const actualizado = carrito.map(item =>
      item.producto.id === id ? { ...item, cantidad: Math.max(1, item.cantidad + delta) } : item
    );
    setCarritoYGuardar(actualizado);
  };

  const eliminarDelCarrito = (id: string) => {
    setCarritoYGuardar(carrito.filter(item => item.producto.id !== id));
  };

  const vaciarCarrito = () => {
    if (confirm('¿Estás seguro de vaciar el carrito?')) {
      setCarritoYGuardar([]);
    }
  };

  const subtotal = carrito.reduce((sum, item) => sum + (item.producto.precio * item.cantidad), 0);
  const descuento = subtotal * 0.05; // 5% descuento
  const impuesto = (subtotal - descuento) * 0.19; // IVA 19%
  const total = subtotal - descuento + impuesto;
  const totalItems = carrito.reduce((sum, item) => sum + item.cantidad, 0);

  const finalizarCompra = () => {
    if (carrito.length === 0) return;

    const ts = Date.now().toString();
    const ticketId = `TKT-${ts.slice(-6)}`;
    const pedidoId = `PED-${ts.slice(-6)}`;

    // 1. Guardar venta (ticket)
    const venta = {
      id: ticketId,
      pedidoId,
      fecha: new Date().toISOString(),
      items: carrito,
      clienteNombre: user?.nombre || 'Cliente',
      clienteEmail: user?.email || '',
      subtotal,
      descuento,
      impuesto,
      total,
    };
    const ventas = JSON.parse(localStorage.getItem('ventas') || '[]');
    ventas.push(venta);
    localStorage.setItem('ventas', JSON.stringify(ventas));

    // 2. Crear pedido vinculado con estado 'pendiente'
    const pedido = {
      id: pedidoId,
      ticketId,
      clienteNombre: user?.nombre || 'Cliente',
      clienteEmail: user?.email || '',
      productos: carrito.map(i => ({
        nombre: i.producto.nombre,
        cantidad: i.cantidad,
        precio: i.producto.precio,
      })),
      total,
      estado: 'pendiente',
      fecha: new Date().toISOString(),
      historial: [
        { estado: 'pendiente', fecha: new Date().toISOString(), nota: 'Pedido recibido' },
      ],
    };
    const pedidos = JSON.parse(localStorage.getItem('pedidos') || '[]');
    pedidos.push(pedido);
    localStorage.setItem('pedidos', JSON.stringify(pedidos));

    // 3. Vaciar carrito y mostrar modal de confirmación
    setCarritoYGuardar([]);
    setTicketModal({ ticketId, pedidoId });
  };

  const descargarTicket = (ticketId: string) => {
    const ventas = JSON.parse(localStorage.getItem('ventas') || '[]');
    const v = ventas.find((v: any) => v.id === ticketId);
    if (!v) return;
    const texto = [
      '═══════════════════════════════════',
      '      DOTACIONES FORTUNA IJ',
      '═══════════════════════════════════',
      '',
      `Ticket:  ${v.id}`,
      `Pedido:  ${v.pedidoId}`,
      `Fecha:   ${new Date(v.fecha).toLocaleString('es-CO')}`,
      `Cliente: ${v.clienteNombre}`,
      '',
      '───────────────────────────────────',
      ' PRODUCTOS',
      '───────────────────────────────────',
      ...v.items.map((i: any) =>
        `  ${i.producto.nombre}\n  ${i.cantidad} x $${i.producto.precio.toLocaleString('es-CO')} = $${(i.cantidad * i.producto.precio).toLocaleString('es-CO')}`
      ),
      '',
      '───────────────────────────────────',
      `  Subtotal:  $${v.subtotal?.toLocaleString('es-CO') || ''}`,
      `  Descuento: -$${v.descuento?.toLocaleString('es-CO') || ''}`,
      `  IVA 19%:   $${Math.round(v.impuesto || 0).toLocaleString('es-CO')}`,
      '───────────────────────────────────',
      `  TOTAL:     $${Math.round(v.total).toLocaleString('es-CO')} COP`,
      '═══════════════════════════════════',
      '',
      '  Estado pedido: PENDIENTE',
      '  Consulta tu pedido en la sección',
      '  "Mis Pedidos" del dashboard.',
      '',
      '  ¡Gracias por tu compra!',
    ].join('\n');
    const blob = new Blob([texto], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${ticketId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const categorias = ['todas', ...Array.from(new Set(productos.map(p => p.categoria)))];

  const filteredProductos = productos.filter(p => {
    const matchSearch = p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        p.categoria.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategoria = categoriaFiltro === 'todas' || p.categoria === categoriaFiltro;
    return matchSearch && matchCategoria;
  });

  return (
    <>
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full animate-fade-in">
      {/* Products List */}
      <div className="lg:col-span-2 space-y-6">
        {/* Header y Búsqueda */}
        <div className="bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 border border-yellow-500/30 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-yellow-500 p-3 rounded-xl shadow-lg shadow-yellow-500/30">
              <Package className="w-8 h-8 text-black" />
            </div>
            <h3 className="text-3xl text-white font-bold bg-gradient-to-r from-white to-yellow-500 bg-clip-text text-transparent">
              Productos Disponibles
            </h3>
          </div>

          <div className="relative mb-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar productos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-zinc-900/80 backdrop-blur border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {categorias.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoriaFiltro(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  categoriaFiltro === cat
                    ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/30'
                    : 'bg-zinc-800 text-gray-400 hover:bg-zinc-700'
                }`}
              >
                {cat === 'todas' ? 'Todas' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredProductos.map((producto) => (
            <div
              key={producto.id}
              className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl overflow-hidden hover:border-yellow-500 transition-all cursor-pointer hover:scale-105 hover:shadow-xl hover:shadow-yellow-500/20 group"
              onClick={() => agregarAlCarrito(producto)}
            >
              <div className="bg-gradient-to-br from-zinc-800 to-zinc-900 h-32 flex items-center justify-center overflow-hidden">
                {producto.imagenUrl ? (
                  <ImageWithFallback
                    src={producto.imagenUrl}
                    alt={producto.nombre}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                  />
                ) : (
                  <span className="text-5xl group-hover:scale-125 transition-transform">{producto.imagen}</span>
                )}
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="text-white font-semibold text-lg leading-tight mb-1">{producto.nombre}</h4>
                    <div className="flex items-center gap-2 mb-2">
                      <Tag className="w-4 h-4 text-yellow-500" />
                      <span className="text-yellow-500 text-xs font-medium">{producto.categoria}</span>
                    </div>
                  </div>
                  <div className="bg-yellow-500/10 px-3 py-1 rounded-lg">
                    <Plus className="w-5 h-5 text-yellow-500" />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-yellow-500 text-2xl font-bold">${producto.precio.toLocaleString('es-CO')}</span>
                  <span className="text-xs text-gray-400">Click para agregar</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cart */}
      <div className="bg-gradient-to-br from-zinc-900 via-zinc-900/95 to-black backdrop-blur border-2 border-yellow-500/50 rounded-2xl p-6 h-fit sticky top-6 shadow-2xl shadow-yellow-500/30">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-yellow-500 to-yellow-600 p-3 rounded-xl shadow-lg shadow-yellow-500/30">
              <ShoppingCart className="w-6 h-6 text-black" />
            </div>
            <div>
              <h3 className="text-2xl text-white font-bold">Carrito</h3>
              {carrito.length > 0 && (
                <p className="text-yellow-500 text-sm font-medium">{totalItems} {totalItems === 1 ? 'item' : 'items'}</p>
              )}
            </div>
          </div>
          {carrito.length > 0 && (
            <button
              onClick={vaciarCarrito}
              className="text-red-400 hover:text-red-300 text-sm font-medium transition-colors"
            >
              Vaciar
            </button>
          )}
        </div>

        {carrito.length === 0 ? (
          <div className="text-center py-12">
            <div className="bg-zinc-800/50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingCart className="w-10 h-10 text-gray-600" />
            </div>
            <p className="text-gray-400 text-lg">El carrito está vacío</p>
            <p className="text-gray-500 text-sm mt-2">Agrega productos para comenzar</p>
          </div>
        ) : (
          <>
            <div className="space-y-3 mb-6 max-h-96 overflow-y-auto pr-2">
              {carrito.map((item) => (
                <div key={item.producto.id} className="bg-zinc-800/50 border border-zinc-700 rounded-xl p-4 hover:border-yellow-500/50 transition-all">
                  <div className="flex gap-3 mb-3">
                    <div className="bg-gradient-to-br from-zinc-700 to-zinc-800 w-16 h-16 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                      {item.producto.imagenUrl ? (
                        <ImageWithFallback
                          src={item.producto.imagenUrl}
                          alt={item.producto.nombre}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-3xl">{item.producto.imagen}</span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white font-semibold text-sm leading-tight mb-1 truncate">{item.producto.nombre}</h4>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-gray-400 text-xs">Precio unitario:</span>
                        <span className="text-yellow-500 text-sm font-bold">${item.producto.precio.toLocaleString('es-CO')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-xs">Subtotal:</span>
                        <span className="text-white text-sm font-bold">${(item.producto.precio * item.cantidad).toLocaleString('es-CO')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 bg-zinc-900 rounded-lg p-1">
                      <button
                        onClick={() => modificarCantidad(item.producto.id, -1)}
                        className="bg-zinc-700 hover:bg-zinc-600 text-yellow-500 w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="text-white font-bold w-10 text-center">{item.cantidad}</span>
                      <button
                        onClick={() => modificarCantidad(item.producto.id, 1)}
                        className="bg-zinc-700 hover:bg-zinc-600 text-yellow-500 w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <button
                      onClick={() => eliminarDelCarrito(item.producto.id)}
                      className="bg-red-500/10 hover:bg-red-500/20 text-red-500 w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Resumen de Compra */}
            <div className="border-t-2 border-zinc-700 pt-4 space-y-3">
              <div className="bg-zinc-800/30 rounded-lg p-3 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Subtotal:</span>
                  <span className="text-white font-semibold">${subtotal.toLocaleString('es-CO', {maximumFractionDigits: 0})}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-green-400 text-sm flex items-center gap-1">
                    <Tag className="w-3 h-3" />
                    Descuento (5%):
                  </span>
                  <span className="text-green-400 font-semibold">-${descuento.toLocaleString('es-CO', {maximumFractionDigits: 0})}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">IVA (19%):</span>
                  <span className="text-white font-semibold">${impuesto.toLocaleString('es-CO', {maximumFractionDigits: 0})}</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 border border-yellow-500/50 rounded-xl p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-6 h-6 text-yellow-500" />
                    <span className="text-white text-xl font-bold">Total:</span>
                  </div>
                  <span className="text-yellow-500 text-3xl font-bold">${total.toLocaleString('es-CO', {maximumFractionDigits: 0})}</span>
                </div>
              </div>

              <button
                onClick={finalizarCompra}
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black py-4 rounded-xl transition-all font-bold text-lg shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 hover:scale-105 flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-6 h-6" />
                Finalizar Compra
              </button>
            </div>
          </>
        )}
      </div>
      <div className="lg:col-span-3">
        <PQRSWidget modulo="ventas" titulo="PQRS — Ventas" />
      </div>
    </div>

    {/* ── MODAL TICKET DE CONFIRMACIÓN ── */}
    {ticketModal && (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
        <div className="bg-zinc-900 border border-yellow-500/50 rounded-2xl max-w-md w-full shadow-2xl shadow-yellow-500/20 overflow-hidden">
          {/* Cabecera éxito */}
          <div className="bg-gradient-to-br from-green-500/20 to-teal-500/10 border-b border-green-500/20 p-6 text-center">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-9 h-9 text-green-400" />
            </div>
            <h3 className="text-white text-2xl font-black">¡Compra realizada!</h3>
            <p className="text-gray-400 text-sm mt-1">Tu pedido ha sido registrado exitosamente</p>
          </div>

          {/* Cuerpo ticket */}
          <div className="p-6 space-y-4">
            {/* IDs */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-zinc-800/60 rounded-xl p-3 text-center">
                <div className="flex items-center justify-center gap-1.5 mb-1">
                  <Receipt className="w-3.5 h-3.5 text-yellow-500" />
                  <span className="text-gray-500 text-xs font-semibold uppercase tracking-wide">Ticket</span>
                </div>
                <p className="text-yellow-400 font-black text-lg font-mono">{ticketModal.ticketId}</p>
              </div>
              <div className="bg-zinc-800/60 rounded-xl p-3 text-center">
                <div className="flex items-center justify-center gap-1.5 mb-1">
                  <Package className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-gray-500 text-xs font-semibold uppercase tracking-wide">Pedido</span>
                </div>
                <p className="text-blue-400 font-black text-lg font-mono">{ticketModal.pedidoId}</p>
              </div>
            </div>

            {/* Estado del pedido */}
            <div className="bg-zinc-800/40 border border-zinc-700 rounded-xl p-4">
              <p className="text-gray-400 text-xs font-semibold uppercase tracking-wide mb-3">Estado del pedido</p>
              <div className="flex items-center gap-2">
                {['pendiente', 'procesando', 'enviado', 'entregado'].map((e, i) => (
                  <React.Fragment key={e}>
                    <div className={`flex flex-col items-center gap-1 ${i === 0 ? 'text-yellow-400' : 'text-gray-600'}`}>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-black ${i === 0 ? 'border-yellow-400 bg-yellow-400/10' : 'border-zinc-700'}`}>
                        {i === 0 ? '●' : '○'}
                      </div>
                      <span className="text-xs font-semibold capitalize leading-tight text-center w-14">{e}</span>
                    </div>
                    {i < 3 && <div className={`flex-1 h-0.5 ${i === 0 ? 'bg-zinc-700' : 'bg-zinc-800'} mb-4`} />}
                  </React.Fragment>
                ))}
              </div>
            </div>

            <p className="text-gray-500 text-xs text-center">
              Consulta el avance en <span className="text-yellow-400 font-semibold">Mis Pedidos</span> del menú lateral
            </p>

            {/* Botones */}
            <div className="flex gap-3 pt-1">
              <button
                onClick={() => descargarTicket(ticketModal.ticketId)}
                className="flex-1 flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-yellow-500/40 text-gray-300 hover:text-white py-2.5 rounded-xl transition-all font-semibold text-sm"
              >
                <Download className="w-4 h-4" />
                Descargar
              </button>
              <button
                onClick={() => setTicketModal(null)}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black py-2.5 rounded-xl transition-all font-bold text-sm hover:scale-105 shadow-lg shadow-yellow-500/20"
              >
                <CheckCircle className="w-4 h-4" />
                Entendido
              </button>
            </div>
          </div>
        </div>
      </div>
    )}
    </>
  );
};
