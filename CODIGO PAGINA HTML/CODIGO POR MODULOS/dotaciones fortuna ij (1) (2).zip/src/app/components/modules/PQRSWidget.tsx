import React, { useState, useEffect } from 'react';
import {
  MessageSquare, Plus, CheckCircle, Clock, AlertCircle,
  XCircle, Send, ChevronDown, ChevronUp, User
} from 'lucide-react';
import { useAuth } from '../AuthContext';

export type PQRSModulo = 'administrativo' | 'ventas' | 'inventario' | 'productos' | 'pedidos' | 'tickets' | 'general';

export interface PQRSItem {
  id: string;
  tipo: 'peticion' | 'queja' | 'reclamo' | 'sugerencia';
  modulo: PQRSModulo;
  asunto: string;
  descripcion: string;
  usuario: string;
  email: string;
  estado: 'abierto' | 'en_revision' | 'resuelto' | 'cerrado';
  fecha: string;
  respuesta?: string;
  respondidoPor?: string;
  fechaRespuesta?: string;
}

interface Props {
  modulo: PQRSModulo;
  titulo?: string;
}

const TIPO_COLOR: Record<string, string> = {
  peticion: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  queja: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  reclamo: 'bg-red-500/15 text-red-400 border-red-500/30',
  sugerencia: 'bg-green-500/15 text-green-400 border-green-500/30',
};

export type EstadoKey = 'abierto' | 'en_revision' | 'resuelto' | 'cerrado';

export const ESTADO_CONFIG: Record<EstadoKey, { color: string; Icon: React.FC<{ className?: string }>; label: string }> = {
  abierto:     { color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', Icon: Clock,        label: 'Abierto' },
  en_revision: { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',       Icon: AlertCircle,  label: 'En Revisión' },
  resuelto:    { color: 'text-green-400 bg-green-500/10 border-green-500/20',     Icon: CheckCircle,  label: 'Resuelto' },
  cerrado:     { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20',        Icon: XCircle,      label: 'Cerrado' },
};

export const loadPQRS = (): PQRSItem[] => JSON.parse(localStorage.getItem('pqrs') || '[]');
export const savePQRSAll = (items: PQRSItem[]) => localStorage.setItem('pqrs', JSON.stringify(items));

export const PQRSWidget: React.FC<Props> = ({ modulo, titulo }) => {
  const { user } = useAuth();
  const [items, setItems] = useState<PQRSItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({ tipo: 'peticion' as PQRSItem['tipo'], asunto: '', descripcion: '' });

  const canManage = ['gerente_general', 'subgerente', 'admin_inventario'].includes(user?.role || '');

  useEffect(() => {
    const all = loadPQRS();
    setItems(all.filter(p => p.modulo === modulo));
  }, [modulo]);

  const refresh = () => {
    const all = loadPQRS();
    setItems(all.filter(p => p.modulo === modulo));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const all = loadPQRS();
    const nueva: PQRSItem = {
      id: Date.now().toString(),
      tipo: formData.tipo,
      modulo,
      asunto: formData.asunto,
      descripcion: formData.descripcion,
      usuario: user?.nombre || 'Anónimo',
      email: user?.email || '',
      estado: 'abierto',
      fecha: new Date().toISOString(),
    };
    savePQRSAll([...all, nueva]);
    setFormData({ tipo: 'peticion', asunto: '', descripcion: '' });
    setShowForm(false);
    refresh();
  };

  const cambiarEstado = (id: string, estado: PQRSItem['estado']) => {
    const all = loadPQRS();
    savePQRSAll(all.map(p => p.id === id ? { ...p, estado } : p));
    refresh();
  };

  const responder = (id: string) => {
    const texto = respuestas[id]?.trim();
    if (!texto) return;
    const all = loadPQRS();
    savePQRSAll(all.map(p => p.id === id ? {
      ...p,
      respuesta: texto,
      respondidoPor: user?.nombre,
      fechaRespuesta: new Date().toISOString(),
      estado: 'resuelto',
    } : p));
    setRespuestas(r => ({ ...r, [id]: '' }));
    refresh();
  };

  const abiertos = items.filter(p => p.estado === 'abierto' || p.estado === 'en_revision').length;

  return (
    <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-900/50">
        <div className="flex items-center gap-3">
          <div className="bg-purple-500/10 p-2 rounded-lg">
            <MessageSquare className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-white font-bold text-sm">
              {titulo || `PQRS — ${modulo.charAt(0).toUpperCase() + modulo.slice(1)}`}
            </h3>
            <p className="text-gray-500 text-xs">{items.length} solicitud{items.length !== 1 ? 'es' : ''}{abiertos > 0 ? ` · ${abiertos} pendiente${abiertos !== 1 ? 's' : ''}` : ''}</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(v => !v)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-400 rounded-lg text-xs font-semibold transition-all hover:scale-105"
        >
          <Plus className="w-3.5 h-3.5" />
          Nueva
        </button>
      </div>

      {/* Formulario nueva PQRS */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-4 border-b border-zinc-800 bg-purple-500/5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1">Tipo</label>
              <select
                value={formData.tipo}
                onChange={e => setFormData(f => ({ ...f, tipo: e.target.value as PQRSItem['tipo'] }))}
                className="w-full px-3 py-2 bg-zinc-800/60 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-purple-500/50 transition-all cursor-pointer"
              >
                <option value="peticion">Petición</option>
                <option value="queja">Queja</option>
                <option value="reclamo">Reclamo</option>
                <option value="sugerencia">Sugerencia</option>
              </select>
            </div>
            <div>
              <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1">Asunto</label>
              <input
                type="text"
                value={formData.asunto}
                onChange={e => setFormData(f => ({ ...f, asunto: e.target.value }))}
                placeholder="Título breve"
                required
                className="w-full px-3 py-2 bg-zinc-800/60 border border-zinc-700 rounded-lg text-white text-sm placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all"
              />
            </div>
          </div>
          <div>
            <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1">Descripción</label>
            <textarea
              value={formData.descripcion}
              onChange={e => setFormData(f => ({ ...f, descripcion: e.target.value }))}
              placeholder="Describe detalladamente tu solicitud..."
              rows={3}
              required
              className="w-full px-3 py-2 bg-zinc-800/60 border border-zinc-700 rounded-lg text-white text-sm placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all resize-none"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-gray-300 rounded-lg text-xs font-semibold transition-all">
              Cancelar
            </button>
            <button type="submit" className="flex items-center gap-1.5 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold transition-all hover:scale-105 shadow-lg shadow-purple-500/20">
              <Send className="w-3.5 h-3.5" />
              Enviar PQRS
            </button>
          </div>
        </form>
      )}

      {/* Lista */}
      <div className="divide-y divide-zinc-800/50 max-h-96 overflow-y-auto">
        {items.length === 0 ? (
          <div className="text-center py-10 text-gray-600">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-sm">No hay PQRS para este módulo</p>
          </div>
        ) : items.map(item => {
          const estado = ESTADO_CONFIG[item.estado];
          const expanded = expandedId === item.id;
          return (
            <div key={item.id} className="p-4 hover:bg-zinc-800/20 transition-colors">
              {/* Fila principal */}
              <div
                className="flex items-start gap-3 cursor-pointer"
                onClick={() => setExpandedId(expanded ? null : item.id)}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className={`px-2 py-0.5 rounded-md text-xs font-bold border ${TIPO_COLOR[item.tipo]}`}>
                      {item.tipo.charAt(0).toUpperCase() + item.tipo.slice(1)}
                    </span>
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold border ${estado.color}`}>
                      <estado.Icon className="w-3.5 h-3.5" />
                      {estado.label}
                    </span>
                  </div>
                  <p className="text-white text-sm font-semibold leading-tight truncate">{item.asunto}</p>
                  <div className="flex items-center gap-1.5 mt-1 text-gray-600 text-xs">
                    <User className="w-3 h-3" />
                    <span>{item.usuario}</span>
                    <span>·</span>
                    <span>{new Date(item.fecha).toLocaleDateString('es-CO')}</span>
                  </div>
                </div>
                {expanded
                  ? <ChevronUp className="w-4 h-4 text-gray-500 flex-shrink-0 mt-1" />
                  : <ChevronDown className="w-4 h-4 text-gray-500 flex-shrink-0 mt-1" />
                }
              </div>

              {/* Detalle expandido */}
              {expanded && (
                <div className="mt-3 space-y-3">
                  <p className="text-gray-400 text-sm bg-zinc-800/40 rounded-xl p-3">{item.descripcion}</p>

                  {item.respuesta && (
                    <div className="bg-green-500/8 border border-green-500/20 rounded-xl p-3">
                      <p className="text-green-400 text-xs font-bold mb-1">
                        Respuesta{item.respondidoPor ? ` · ${item.respondidoPor}` : ''}
                        {item.fechaRespuesta ? ` · ${new Date(item.fechaRespuesta).toLocaleDateString('es-CO')}` : ''}
                      </p>
                      <p className="text-gray-300 text-sm">{item.respuesta}</p>
                    </div>
                  )}

                  {/* Acciones para gestores */}
                  {canManage && item.estado !== 'cerrado' && (
                    <div className="space-y-2 pt-1">
                      {/* Cambio de estado */}
                      <div className="flex gap-1.5 flex-wrap">
                        {(['abierto', 'en_revision', 'resuelto', 'cerrado'] as PQRSItem['estado'][]).map(e => (
                          <button
                            key={e}
                            onClick={() => cambiarEstado(item.id, e)}
                            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                              item.estado === e
                                ? ESTADO_CONFIG[e].color + ' scale-105'
                                : 'bg-zinc-800 border-zinc-700 text-gray-400 hover:bg-zinc-700'
                            }`}
                          >
                            {React.createElement(ESTADO_CONFIG[e].Icon, { className: 'w-3.5 h-3.5' })}
                            {ESTADO_CONFIG[e].label}
                          </button>
                        ))}
                      </div>

                      {/* Área de respuesta */}
                      {!item.respuesta && (
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={respuestas[item.id] || ''}
                            onChange={e => setRespuestas(r => ({ ...r, [item.id]: e.target.value }))}
                            placeholder="Escribe una respuesta..."
                            className="flex-1 px-3 py-2 bg-zinc-800/60 border border-zinc-700 rounded-lg text-white text-xs placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all"
                            onKeyDown={e => { if (e.key === 'Enter') responder(item.id); }}
                          />
                          <button
                            onClick={() => responder(item.id)}
                            disabled={!respuestas[item.id]?.trim()}
                            className="flex items-center gap-1 px-3 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg text-xs font-bold transition-all hover:scale-105"
                          >
                            <Send className="w-3.5 h-3.5" />
                            Responder
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
