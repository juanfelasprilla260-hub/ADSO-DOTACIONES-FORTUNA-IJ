import React, { useState, useEffect } from 'react';
import { Receipt, Calendar } from 'lucide-react';
import { PQRSWidget } from './PQRSWidget';

interface Venta {
  id: string;
  pedidoId?: string;
  fecha: string;
  clienteNombre?: string;
  items: Array<{ producto: { nombre: string; precio: number }; cantidad: number }>;
  subtotal?: number;
  descuento?: number;
  impuesto?: number;
  total: number;
}

// badge colors matching ticket.css
const BADGE_BG: Record<string, { bg: string; color: string; label: string }> = {
  pendiente:   { bg: '#78350f',  color: '#fbbf24', label: 'Pendiente'  },
  fabricando:  { bg: '#1e3a5f',  color: '#60a5fa', label: 'Fabricando' },
  procesando:  { bg: '#1e3a5f',  color: '#60a5fa', label: 'Procesando' },
  enviado:     { bg: '#2d1b69',  color: '#a78bfa', label: 'Enviado'    },
  entregado:   { bg: '#14532d',  color: '#4ade80', label: 'Entregado'  },
  cancelado:   { bg: '#450a0a',  color: '#f87171', label: 'Cancelado'  },
};

export const Tickets: React.FC = () => {
  const [ventas, setVentas]                   = useState<Venta[]>([]);
  const [selectedVenta, setSelectedVenta]     = useState<Venta | null>(null);
  const [pedidoEstados, setPedidoEstados]     = useState<Record<string, string>>({});

  useEffect(() => {
    const stored = localStorage.getItem('ventas');
    if (stored) setVentas(JSON.parse(stored));
    const pedidos = JSON.parse(localStorage.getItem('pedidos') || '[]');
    const mapa: Record<string, string> = {};
    pedidos.forEach((p: any) => { mapa[p.id] = p.estado; });
    setPedidoEstados(mapa);
  }, []);

  const formatFecha = (f: string) =>
    new Date(f).toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const formatHora = (f: string) =>
    new Date(f).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const handlePrint = (venta: Venta) => {
    const el = document.getElementById(`ticket-detail-${venta.id}`);
    if (!el) return;
    const w = window.open('', '_blank', 'width=620,height=860');
    if (!w) return;
    w.document.write(`<html><head><title>Ticket ${venta.id}</title>
      <style>body{font-family:Inter,sans-serif;background:#0f1117;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:40px 16px;margin:0}
      @media print{body{background:#fff}button{display:none!important}}</style>
      </head><body>${el.outerHTML}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 300);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div style={{ backgroundColor: '#1e2030', borderRadius: '12px', width: '50px', height: '50px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', border: '1px solid #2a2d3e' }}>
          🧾
        </div>
        <div>
          <h2 style={{ fontSize: '28px', fontWeight: 700, color: '#f1f5f9', lineHeight: 1.1 }}>Historial de Tickets</h2>
          <p style={{ fontSize: '13px', color: '#64748b', marginTop: '2px' }}>Comprobantes de venta</p>
        </div>
      </div>

      {ventas.length === 0 ? (
        <div style={{ backgroundColor: '#13151c', border: '1px solid #1e2030', borderRadius: '14px', padding: '48px', textAlign: 'center' }}>
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>🧾</div>
          <p style={{ color: '#64748b', fontSize: '14px' }}>No hay tickets generados</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* ── Lista de tickets ── */}
          <div className="space-y-3">
            {ventas.map(venta => {
              const estadoPedido = venta.pedidoId ? pedidoEstados[venta.pedidoId] : undefined;
              const badge = estadoPedido ? (BADGE_BG[estadoPedido] || BADGE_BG.pendiente) : null;
              const isSelected = selectedVenta?.id === venta.id;
              return (
                <div
                  key={venta.id}
                  onClick={() => setSelectedVenta(venta)}
                  style={{
                    backgroundColor: '#13151c',
                    border: `1px solid ${isSelected ? '#f5a623' : '#1e2030'}`,
                    borderRadius: '14px',
                    padding: '16px 20px',
                    cursor: 'pointer',
                    transition: 'border-color 0.15s',
                    boxShadow: isSelected ? '0 0 0 1px rgba(245,166,35,0.2)' : 'none',
                  }}
                  onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.borderColor = 'rgba(245,166,35,0.4)'; }}
                  onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.borderColor = '#1e2030'; }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                    <div>
                      <p style={{ fontWeight: 700, color: '#f1f5f9', fontSize: '14px', marginBottom: '2px' }}>{venta.id}</p>
                      <p style={{ fontSize: '11px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        📅 {formatFecha(venta.fecha)} — {formatHora(venta.fecha)}
                      </p>
                    </div>
                    <p style={{ fontSize: '20px', fontWeight: 700, color: '#f5a623', fontVariantNumeric: 'tabular-nums' }}>
                      ${venta.total.toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '11px', color: '#64748b' }}>{venta.items.length} producto(s)</span>
                    {badge && (
                      <span style={{ display: 'inline-block', backgroundColor: badge.bg, color: badge.color, fontSize: '11px', fontWeight: 600, padding: '2px 10px', borderRadius: '20px' }}>
                        {badge.label}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* ── Detalle del ticket (fiel a ticket.html + ticket.css) ── */}
          {selectedVenta && (() => {
            const estadoPedido = selectedVenta.pedidoId ? pedidoEstados[selectedVenta.pedidoId] : undefined;
            const badge = estadoPedido ? (BADGE_BG[estadoPedido] || BADGE_BG.pendiente) : null;
            return (
              <div className="h-fit sticky top-6">
                <div
                  id={`ticket-detail-${selectedVenta.id}`}
                  style={{
                    backgroundColor: '#13151c',
                    border: '1px solid #1e2030',
                    borderRadius: '16px',
                    padding: '32px',
                    color: '#e2e8f0',
                    fontFamily: 'Inter, sans-serif',
                  }}
                >
                  {/* Encabezado */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
                    <div>
                      <p style={{ fontSize: '16px', fontWeight: 800, color: '#f5a623', marginBottom: '6px' }}>Dotaciones Fortuna IJ</p>
                      <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>NIT: 900.123.456-7</p>
                      <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>Cra 63 No. 22 - 22 sur, Bogotá</p>
                      <p style={{ fontSize: '11.5px', color: '#64748b', lineHeight: 1.7, margin: 0 }}>Tel: 312 388 8729</p>
                    </div>
                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                      <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '2px', color: '#64748b', textTransform: 'uppercase', marginBottom: '2px' }}>TICKET DE VENTA</p>
                      <p style={{ fontSize: '34px', fontWeight: 800, color: '#f5a623', lineHeight: 1 }}>
                        # {selectedVenta.id.toString().slice(-4)}
                      </p>
                    </div>
                  </div>

                  {/* Línea divisora */}
                  <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

                  {/* Cliente + Fecha */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
                    <div>
                      <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '1.5px', color: '#f5a623', textTransform: 'uppercase', marginBottom: '6px', opacity: 0.7 }}>CLIENTE</p>
                      <p style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '3px' }}>
                        {selectedVenta.clienteNombre || 'Cliente'}
                      </p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <p style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '1.5px', color: '#f5a623', textTransform: 'uppercase', marginBottom: '6px', opacity: 0.7 }}>FECHA</p>
                      <p style={{ fontSize: '14px', fontWeight: 600, color: '#f1f5f9', marginBottom: '2px' }}>{formatFecha(selectedVenta.fecha)}</p>
                      <p style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>{formatHora(selectedVenta.fecha)}</p>
                      {badge && (
                        <span style={{ display: 'inline-block', backgroundColor: badge.bg, color: badge.color, fontSize: '11px', fontWeight: 600, padding: '3px 12px', borderRadius: '20px' }}>
                          {badge.label}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Línea divisora */}
                  <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

                  {/* Tabla productos */}
                  <p style={{ fontSize: '16px', fontWeight: 800, color: '#f5a623', marginBottom: '6px' }}>PRODUCTOS</p>
                  <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px', fontSize: '13px' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#1e2030' }}>
                        {['Descripción', 'Cant.', 'P. Unit.', 'Subtotal'].map((h, i) => (
                          <th key={h} style={{ padding: '9px 10px', fontSize: '10.5px', fontWeight: 700, letterSpacing: '0.8px', color: '#f5a623', textTransform: 'uppercase', textAlign: i === 0 ? 'left' : 'right', opacity: 0.7 }}>
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {selectedVenta.items.map((item, i) => (
                        <tr key={i} style={{ backgroundColor: i % 2 === 1 ? '#16182a' : 'transparent' }}>
                          <td style={{ padding: '10px', color: '#cbd5e1', borderBottom: '1px solid #1a1d2a' }}>{item.producto.nombre}</td>
                          <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right' }}>{item.cantidad}</td>
                          <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                            ${item.producto.precio.toLocaleString('es-CO')}
                          </td>
                          <td style={{ padding: '10px', color: '#94a3b8', borderBottom: '1px solid #1a1d2a', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                            ${(item.cantidad * item.producto.precio).toLocaleString('es-CO')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Desglose subtotal/IVA si existe */}
                  {selectedVenta.subtotal != null && (
                    <div style={{ marginTop: '12px', fontSize: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#64748b' }}>
                        <span>Subtotal</span>
                        <span>${Math.round(selectedVenta.subtotal).toLocaleString('es-CO')}</span>
                      </div>
                      {(selectedVenta.descuento || 0) > 0 && (
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#4ade80' }}>
                          <span>Descuento (5%)</span>
                          <span>-${Math.round(selectedVenta.descuento || 0).toLocaleString('es-CO')}</span>
                        </div>
                      )}
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#64748b' }}>
                        <span>IVA (19%)</span>
                        <span>${Math.round(selectedVenta.impuesto || 0).toLocaleString('es-CO')}</span>
                      </div>
                    </div>
                  )}

                  {/* Total */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#1a1d2a', border: '1px solid #f5a623', borderRadius: '10px', padding: '14px 18px', marginTop: '18px' }}>
                    <span style={{ fontSize: '11px', fontWeight: 700, letterSpacing: '1.5px', color: '#94a3b8', textTransform: 'uppercase' }}>TOTAL A PAGAR</span>
                    <span style={{ fontSize: '26px', fontWeight: 800, color: '#f5a623', fontVariantNumeric: 'tabular-nums' }}>
                      ${Math.round(selectedVenta.total).toLocaleString('es-CO')} COP
                    </span>
                  </div>

                  {/* Línea divisora */}
                  <div style={{ borderTop: '1px dashed #1e2030', margin: '22px 0' }} />

                  {/* Pie */}
                  <div style={{ textAlign: 'center', fontSize: '11px', color: '#4a5568', lineHeight: 1.8 }}>
                    <p>Gracias por su compra · Dotaciones Fortuna IJ © 2026</p>
                    <p>Este documento es un comprobante interno</p>
                  </div>

                  {/* Botón imprimir */}
                  <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'center' }}>
                    <button
                      onClick={() => handlePrint(selectedVenta)}
                      style={{ backgroundColor: '#f5a623', color: '#0f1117', border: 'none', borderRadius: '10px', padding: '12px 28px', fontSize: '14px', fontWeight: 700, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}
                      onMouseEnter={e => { (e.target as HTMLElement).style.backgroundColor = '#d4881a'; }}
                      onMouseLeave={e => { (e.target as HTMLElement).style.backgroundColor = '#f5a623'; }}
                    >
                      ⬇ Imprimir / Guardar PDF
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      <PQRSWidget modulo="tickets" titulo="PQRS — Tickets de Pago" />
    </div>
  );
};
