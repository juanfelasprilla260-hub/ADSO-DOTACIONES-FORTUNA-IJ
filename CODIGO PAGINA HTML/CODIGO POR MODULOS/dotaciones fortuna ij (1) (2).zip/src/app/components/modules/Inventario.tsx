import React, { useState, useEffect, useMemo } from 'react';
import {
  Package, TrendingUp, TrendingDown, AlertTriangle, Search, Filter,
  Plus, Minus, Edit3, RefreshCw, Download, BarChart3, CheckCircle,
  XCircle, ArrowUp, ArrowDown, Boxes, ClipboardList, History,
  ChevronUp, ChevronDown, Save, X
} from 'lucide-react';
import { PQRSWidget } from './PQRSWidget';

interface ItemInventario {
  productoId: string;
  nombre: string;
  stock: number;
  stockMinimo: number;
  stockMaximo: number;
  categoria: string;
  imagen: string;
  ultimaActualizacion: string;
  proveedor?: string;
  ubicacion?: string;
  unidad?: string;   // Metros, Unidades, Bolsas, etc.
}

interface Movimiento {
  id: string;
  productoId: string;
  nombreProducto: string;
  tipo: 'entrada' | 'salida' | 'ajuste';
  cantidad: number;
  stockAnterior: number;
  stockNuevo: number;
  fecha: string;
  motivo: string;
}

type Vista = 'tabla' | 'tarjetas' | 'movimientos';
type OrdenCol = 'nombre' | 'stock' | 'categoria' | 'estado';

const COLORES_CATEGORIA: Record<string, string> = {
  // Nuevas categorías de materias primas e insumos
  'Materia Prima': 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30',
  'Insumo':        'text-blue-400 bg-blue-500/10 border-blue-500/30',
  // Categorías anteriores (retrocompatibilidad)
  'Uniformes SENA': 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  'EPP':            'text-orange-400 bg-orange-500/10 border-orange-500/30',
  'Industrial':     'text-purple-400 bg-purple-500/10 border-purple-500/30',
  'Seguridad':      'text-red-400 bg-red-500/10 border-red-500/30',
  'Calzado':        'text-teal-400 bg-teal-500/10 border-teal-500/30',
  'Herramientas':   'text-green-400 bg-green-500/10 border-green-500/30',
};

function SortIcon({ col, ordenCol, ordenDir }: { col: OrdenCol; ordenCol: OrdenCol; ordenDir: 'asc' | 'desc' }) {
  return (
    <span className="ml-1 inline-flex flex-col">
      <ChevronUp className={`w-3 h-3 -mb-1 ${ordenCol === col && ordenDir === 'asc' ? 'text-yellow-500' : 'text-gray-600'}`} />
      <ChevronDown className={`w-3 h-3 ${ordenCol === col && ordenDir === 'desc' ? 'text-yellow-500' : 'text-gray-600'}`} />
    </span>
  );
}

export const Inventario: React.FC = () => {
  const [inventario, setInventario] = useState<ItemInventario[]>([]);
  const [movimientos, setMovimientos] = useState<Movimiento[]>([]);
  const [vista, setVista] = useState<Vista>('tabla');
  const [busqueda, setBusqueda] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState('all');
  const [filtroEstado, setFiltroEstado] = useState('all');
  const [ordenCol, setOrdenCol] = useState<OrdenCol>('nombre');
  const [ordenDir, setOrdenDir] = useState<'asc' | 'desc'>('asc');
  const [editandoId, setEditandoId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<ItemInventario>>({});
  const [modalAjuste, setModalAjuste] = useState<ItemInventario | null>(null);
  const [ajusteCantidad, setAjusteCantidad] = useState('');
  const [ajusteTipo, setAjusteTipo] = useState<'entrada' | 'salida' | 'ajuste'>('entrada');
  const [ajusteMotivo, setAjusteMotivo] = useState('');
  const [paginaActual, setPaginaActual] = useState(1);
  const ITEMS_POR_PAGINA = 10;

  // Materias primas e insumos iniciales (de Materiales_y_Tiempos_UnificadosV2)
  const INVENTARIO_MATERIAS_PRIMAS: ItemInventario[] = [
    // ── MATERIAS PRIMAS ──
    { productoId: 'mp-01', nombre: 'Tela Oxford',          categoria: 'Materia Prima', stock: 100, stockMinimo: 20, stockMaximo: 300, imagen: '🧵', ultimaActualizacion: new Date().toISOString(), proveedor: 'Textiles SAS',              ubicacion: 'A-1A', unidad: 'Metros'   },
    { productoId: 'mp-02', nombre: 'Dril Industrial',       categoria: 'Materia Prima', stock:  80, stockMinimo: 15, stockMaximo: 250, imagen: '🧶', ultimaActualizacion: new Date().toISOString(), proveedor: 'Fabrica Telas',             ubicacion: 'A-1B', unidad: 'Metros'   },
    { productoId: 'mp-03', nombre: 'Tela Reflectiva',       categoria: 'Materia Prima', stock:  60, stockMinimo: 10, stockMaximo: 200, imagen: '🦺', ultimaActualizacion: new Date().toISOString(), proveedor: 'Seguridad Industrial SAS',   ubicacion: 'A-2A', unidad: 'Metros'   },
    { productoId: 'mp-04', nombre: 'Tela Antifluido',       categoria: 'Materia Prima', stock:  75, stockMinimo: 15, stockMaximo: 200, imagen: '🩺', ultimaActualizacion: new Date().toISOString(), proveedor: 'Antifluidos Colombia',       ubicacion: 'A-2B', unidad: 'Metros'   },
    { productoId: 'mp-05', nombre: 'Algodón Premium',       categoria: 'Materia Prima', stock:  90, stockMinimo: 20, stockMaximo: 300, imagen: '☁️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Algodones Nacionales',       ubicacion: 'A-3A', unidad: 'Metros'   },
    { productoId: 'mp-06', nombre: 'Poliéster',             categoria: 'Materia Prima', stock: 110, stockMinimo: 20, stockMaximo: 350, imagen: '🧪', ultimaActualizacion: new Date().toISOString(), proveedor: 'Textiles Modernos',          ubicacion: 'A-3B', unidad: 'Metros'   },
    { productoId: 'mp-07', nombre: 'Cuero Industrial',      categoria: 'Materia Prima', stock:  40, stockMinimo:  8, stockMaximo: 150, imagen: '🥾', ultimaActualizacion: new Date().toISOString(), proveedor: 'CueroFino SAS',              ubicacion: 'A-4A', unidad: 'Metros'   },
    { productoId: 'mp-08', nombre: 'Denim Azul',            categoria: 'Materia Prima', stock:  95, stockMinimo: 20, stockMaximo: 300, imagen: '👖', ultimaActualizacion: new Date().toISOString(), proveedor: 'Denim Factory',              ubicacion: 'A-4B', unidad: 'Metros'   },
    { productoId: 'mp-09', nombre: 'Licra Deportiva',       categoria: 'Materia Prima', stock:  70, stockMinimo: 15, stockMaximo: 200, imagen: '🏃', ultimaActualizacion: new Date().toISOString(), proveedor: 'Sport Textiles',             ubicacion: 'A-5A', unidad: 'Metros'   },
    { productoId: 'mp-10', nombre: 'Goma Antideslizante',   categoria: 'Materia Prima', stock:  55, stockMinimo: 10, stockMaximo: 200, imagen: '⚫', ultimaActualizacion: new Date().toISOString(), proveedor: 'Seguridad Total',            ubicacion: 'A-5B', unidad: 'Unidades' },
    { productoId: 'mp-11', nombre: 'Tela Microfibra',       categoria: 'Materia Prima', stock:  85, stockMinimo: 15, stockMaximo: 250, imagen: '✨', ultimaActualizacion: new Date().toISOString(), proveedor: 'Microtex SAS',               ubicacion: 'A-6A', unidad: 'Metros'   },
    { productoId: 'mp-12', nombre: 'Lona Industrial',       categoria: 'Materia Prima', stock:  50, stockMinimo: 10, stockMaximo: 150, imagen: '🧱', ultimaActualizacion: new Date().toISOString(), proveedor: 'Lonas Bogotá',               ubicacion: 'A-6B', unidad: 'Metros'   },
    { productoId: 'mp-13', nombre: 'Tela Gabardina',        categoria: 'Materia Prima', stock:  65, stockMinimo: 12, stockMaximo: 200, imagen: '🎩', ultimaActualizacion: new Date().toISOString(), proveedor: 'Gabardinas Elite',           ubicacion: 'A-7A', unidad: 'Metros'   },
    { productoId: 'mp-14', nombre: 'Espuma Protectora',     categoria: 'Materia Prima', stock:  30, stockMinimo:  5, stockMaximo: 100, imagen: '🛡️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Protección SAS',             ubicacion: 'A-7B', unidad: 'Rollos'   },
    { productoId: 'mp-15', nombre: 'Tela Polar',            categoria: 'Materia Prima', stock:  45, stockMinimo: 10, stockMaximo: 150, imagen: '❄️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Polar Textiles',             ubicacion: 'A-8A', unidad: 'Metros'   },
    // ── INSUMOS ──
    { productoId: 'in-01', nombre: 'Hilo Negro',            categoria: 'Insumo',        stock: 200, stockMinimo: 40, stockMaximo: 600, imagen: '🧵', ultimaActualizacion: new Date().toISOString(), proveedor: 'Textiles SAS',               ubicacion: 'B-1A', unidad: 'Unidades' },
    { productoId: 'in-02', nombre: 'Botones',               categoria: 'Insumo',        stock: 100, stockMinimo: 20, stockMaximo: 500, imagen: '🔘', ultimaActualizacion: new Date().toISOString(), proveedor: 'Insumos Colombia',           ubicacion: 'B-1B', unidad: 'Bolsas'   },
    { productoId: 'in-03', nombre: 'Cremalleras',           categoria: 'Insumo',        stock: 150, stockMinimo: 30, stockMaximo: 400, imagen: '🤐', ultimaActualizacion: new Date().toISOString(), proveedor: 'Cierres Nacionales',         ubicacion: 'B-2A', unidad: 'Unidades' },
    { productoId: 'in-04', nombre: 'Velcro Industrial',     categoria: 'Insumo',        stock:  80, stockMinimo: 15, stockMaximo: 300, imagen: '📎', ultimaActualizacion: new Date().toISOString(), proveedor: 'Dotainsumos SAS',            ubicacion: 'B-2B', unidad: 'Metros'   },
    { productoId: 'in-05', nombre: 'Elástico',              categoria: 'Insumo',        stock: 120, stockMinimo: 25, stockMaximo: 400, imagen: '〰️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Elásticos Bogotá',           ubicacion: 'B-3A', unidad: 'Metros'   },
    { productoId: 'in-06', nombre: 'Etiquetas Bordadas',    categoria: 'Insumo',        stock: 300, stockMinimo: 60, stockMaximo: 800, imagen: '🏷️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Bordados Elite',             ubicacion: 'B-3B', unidad: 'Unidades' },
    { productoId: 'in-07', nombre: 'Broches Metálicos',     categoria: 'Insumo',        stock:  60, stockMinimo: 12, stockMaximo: 200, imagen: '🔗', ultimaActualizacion: new Date().toISOString(), proveedor: 'Seguridad Textil',           ubicacion: 'B-4A', unidad: 'Cajas'    },
    { productoId: 'in-08', nombre: 'Cinta Reflectiva',      categoria: 'Insumo',        stock:  90, stockMinimo: 20, stockMaximo: 300, imagen: '🔆', ultimaActualizacion: new Date().toISOString(), proveedor: 'Reflectivos SAS',            ubicacion: 'B-4B', unidad: 'Metros'   },
    { productoId: 'in-09', nombre: 'Agujas Industriales',   categoria: 'Insumo',        stock:  45, stockMinimo: 10, stockMaximo: 150, imagen: '🪡', ultimaActualizacion: new Date().toISOString(), proveedor: 'Máquinas y Costuras',        ubicacion: 'B-5A', unidad: 'Cajas'    },
    { productoId: 'in-10', nombre: 'Pegante Textil',        categoria: 'Insumo',        stock:  70, stockMinimo: 15, stockMaximo: 200, imagen: '🧴', ultimaActualizacion: new Date().toISOString(), proveedor: 'Pegatex Colombia',           ubicacion: 'B-5B', unidad: 'Unidades' },
    { productoId: 'in-11', nombre: 'Hilo Blanco',           categoria: 'Insumo',        stock: 180, stockMinimo: 35, stockMaximo: 500, imagen: '🧵', ultimaActualizacion: new Date().toISOString(), proveedor: 'Textiles SAS',               ubicacion: 'B-6A', unidad: 'Unidades' },
    { productoId: 'in-12', nombre: 'Cinta Métrica',         categoria: 'Insumo',        stock:  25, stockMinimo:  5, stockMaximo:  80, imagen: '📏', ultimaActualizacion: new Date().toISOString(), proveedor: 'Insumos Bogotá',             ubicacion: 'B-6B', unidad: 'Unidades' },
    { productoId: 'in-13', nombre: 'Papel de Molde',        categoria: 'Insumo',        stock:  40, stockMinimo:  8, stockMaximo: 120, imagen: '📄', ultimaActualizacion: new Date().toISOString(), proveedor: 'Diseños Industriales',       ubicacion: 'B-7A', unidad: 'Rollos'   },
    { productoId: 'in-14', nombre: 'Tiza Textil',           categoria: 'Insumo',        stock:  50, stockMinimo: 10, stockMaximo: 150, imagen: '✏️', ultimaActualizacion: new Date().toISOString(), proveedor: 'Costura Fácil',              ubicacion: 'B-7B', unidad: 'Cajas'    },
    { productoId: 'in-15', nombre: 'Empaque Plástico',      categoria: 'Insumo',        stock: 110, stockMinimo: 25, stockMaximo: 400, imagen: '📦', ultimaActualizacion: new Date().toISOString(), proveedor: 'Empaques Colombia',          ubicacion: 'B-8A', unidad: 'Paquetes' },
    { productoId: 'in-16', nombre: 'Cordones',              categoria: 'Insumo',        stock:  80, stockMinimo: 20, stockMaximo: 300, imagen: '👟', ultimaActualizacion: new Date().toISOString(), proveedor: 'Accesorios Calzado SAS',     ubicacion: 'B-8B', unidad: 'Unidades' },
  ];

  useEffect(() => {
    const storedMovimientos = localStorage.getItem('movimientosInventario');
    if (storedMovimientos) setMovimientos(JSON.parse(storedMovimientos));

    const storedInventario = localStorage.getItem('inventario_mp');
    if (storedInventario) {
      const parsed: ItemInventario[] = JSON.parse(storedInventario);
      const deduped = parsed.filter((item, idx, arr) => arr.findIndex(x => x.productoId === item.productoId) === idx);
      setInventario(deduped);
    } else {
      setInventario(INVENTARIO_MATERIAS_PRIMAS);
      localStorage.setItem('inventario_mp', JSON.stringify(INVENTARIO_MATERIAS_PRIMAS));
    }
  }, []);

  const crearItemInicial = (p: any): ItemInventario => ({
    productoId: p.id,
    nombre: p.nombre,
    stock: Math.floor(Math.random() * 80) + 20,
    stockMinimo: 10,
    stockMaximo: 200,
    categoria: p.categoria || 'General',
    imagen: p.imagen || '📦',
    ultimaActualizacion: new Date().toISOString(),
    proveedor: 'Proveedor General',
    ubicacion: `A-${Math.floor(Math.random() * 9) + 1}${String.fromCharCode(65 + Math.floor(Math.random() * 6))}`,
  });

  const guardarInventario = (inv: ItemInventario[]) => {
    setInventario(inv);
    localStorage.setItem('inventario_mp', JSON.stringify(inv));
  };

  const guardarMovimiento = (mov: Movimiento) => {
    const nuevos = [mov, ...movimientos].slice(0, 200);
    setMovimientos(nuevos);
    localStorage.setItem('movimientosInventario', JSON.stringify(nuevos));
  };

  const aplicarAjuste = () => {
    if (!modalAjuste || !ajusteCantidad || !ajusteMotivo.trim()) return;
    const cantidad = parseInt(ajusteCantidad);
    if (isNaN(cantidad) || cantidad <= 0) return;

    const stockAnterior = modalAjuste.stock;
    let stockNuevo: number;
    if (ajusteTipo === 'entrada') stockNuevo = stockAnterior + cantidad;
    else if (ajusteTipo === 'salida') stockNuevo = Math.max(0, stockAnterior - cantidad);
    else stockNuevo = cantidad;

    const invActualizado = inventario.map(item =>
      item.productoId === modalAjuste.productoId
        ? { ...item, stock: stockNuevo, ultimaActualizacion: new Date().toISOString() }
        : item
    );
    guardarInventario(invActualizado);
    guardarMovimiento({
      id: Date.now().toString(),
      productoId: modalAjuste.productoId,
      nombreProducto: modalAjuste.nombre,
      tipo: ajusteTipo,
      cantidad,
      stockAnterior,
      stockNuevo,
      fecha: new Date().toISOString(),
      motivo: ajusteMotivo,
    });
    setModalAjuste(null);
    setAjusteCantidad('');
    setAjusteMotivo('');
    setAjusteTipo('entrada');
  };

  const iniciarEdicion = (item: ItemInventario) => {
    setEditandoId(item.productoId);
    setEditForm({ stockMinimo: item.stockMinimo, stockMaximo: item.stockMaximo, proveedor: item.proveedor, ubicacion: item.ubicacion });
  };

  const guardarEdicion = (productoId: string) => {
    const inv = inventario.map(i =>
      i.productoId === productoId ? { ...i, ...editForm, ultimaActualizacion: new Date().toISOString() } : i
    );
    guardarInventario(inv);
    setEditandoId(null);
    setEditForm({});
  };

  const restablecerInventario = () => {
    if (confirm('¿Restablecer el inventario a los datos iniciales de materias primas e insumos?')) {
      guardarInventario(INVENTARIO_MATERIAS_PRIMAS);
    }
  };

  const exportarCSV = () => {
    const header = 'Producto,Categoria,Stock,Stock Mínimo,Stock Máximo,Estado,Ubicación,Proveedor\n';
    const rows = inventario.map(i =>
      `"${i.nombre}","${i.categoria}",${i.stock},${i.stockMinimo},${i.stockMaximo},"${getEstado(i)}","${i.ubicacion || ''}","${i.proveedor || ''}"`
    ).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'inventario_fortuna_ij.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const getEstado = (item: ItemInventario) => {
    if (item.stock === 0) return 'Sin Stock';
    if (item.stock <= item.stockMinimo) return 'Bajo Stock';
    if (item.stock >= item.stockMaximo) return 'Sobrestock';
    return 'Normal';
  };

  const getEstadoColor = (item: ItemInventario) => {
    const e = getEstado(item);
    if (e === 'Sin Stock') return 'text-red-400 bg-red-500/15 border-red-500/30';
    if (e === 'Bajo Stock') return 'text-orange-400 bg-orange-500/15 border-orange-500/30';
    if (e === 'Sobrestock') return 'text-blue-400 bg-blue-500/15 border-blue-500/30';
    return 'text-green-400 bg-green-500/15 border-green-500/30';
  };

  const getBarraColor = (item: ItemInventario) => {
    const pct = item.stock / item.stockMaximo;
    if (item.stock === 0) return 'bg-red-500';
    if (item.stock <= item.stockMinimo) return 'bg-orange-500';
    if (pct > 0.8) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const categorias = useMemo(() => ['all', ...Array.from(new Set(inventario.map(i => i.categoria)))], [inventario]);

  const filtrado = useMemo(() => {
    const seen = new Set<string>();
    return inventario
      .filter(i => {
        // Drop items without a valid productoId and dedup the rest
        if (!i.productoId) return false;
        if (seen.has(i.productoId)) return false;
        seen.add(i.productoId);
        const matchBusqueda = i.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
          (i.proveedor || '').toLowerCase().includes(busqueda.toLowerCase()) ||
          (i.ubicacion || '').toLowerCase().includes(busqueda.toLowerCase());
        const matchCat = filtroCategoria === 'all' || i.categoria === filtroCategoria;
        const matchEstado = filtroEstado === 'all' ||
          (filtroEstado === 'normal' && getEstado(i) === 'Normal') ||
          (filtroEstado === 'bajo' && getEstado(i) === 'Bajo Stock') ||
          (filtroEstado === 'sin' && getEstado(i) === 'Sin Stock') ||
          (filtroEstado === 'sobre' && getEstado(i) === 'Sobrestock');
        return matchBusqueda && matchCat && matchEstado;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (ordenCol === 'nombre') cmp = a.nombre.localeCompare(b.nombre);
        else if (ordenCol === 'stock') cmp = a.stock - b.stock;
        else if (ordenCol === 'categoria') cmp = a.categoria.localeCompare(b.categoria);
        else if (ordenCol === 'estado') cmp = getEstado(a).localeCompare(getEstado(b));
        return ordenDir === 'asc' ? cmp : -cmp;
      });
  }, [inventario, busqueda, filtroCategoria, filtroEstado, ordenCol, ordenDir]);

  const totalPaginas = Math.ceil(filtrado.length / ITEMS_POR_PAGINA);
  const itemsPagina = filtrado.slice((paginaActual - 1) * ITEMS_POR_PAGINA, paginaActual * ITEMS_POR_PAGINA);

  const toggleOrden = (col: OrdenCol) => {
    if (ordenCol === col) setOrdenDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setOrdenCol(col); setOrdenDir('asc'); }
    setPaginaActual(1);
  };

  const stats = useMemo(() => ({
    total: inventario.length,
    stockTotal: inventario.reduce((s, i) => s + i.stock, 0),
    bajoStock: inventario.filter(i => getEstado(i) === 'Bajo Stock').length,
    sinStock: inventario.filter(i => getEstado(i) === 'Sin Stock').length,
    sobrestock: inventario.filter(i => getEstado(i) === 'Sobrestock').length,
    normal: inventario.filter(i => getEstado(i) === 'Normal').length,
    valorEstimado: inventario.reduce((s, i) => {
      const productos = JSON.parse(localStorage.getItem('productos') || '[]');
      const prod = productos.find((p: any) => p.id === i.productoId);
      return s + i.stock * (prod?.precio || 0);
    }, 0),
  }), [inventario]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-br from-yellow-500 via-yellow-600 to-orange-500 p-3 rounded-2xl shadow-xl shadow-yellow-500/40 ring-1 ring-yellow-400/30">
            <Boxes className="w-8 h-8 text-black" />
          </div>
          <div>
            <h2 className="text-3xl text-white font-black tracking-tight">Inventario</h2>
            <p className="text-gray-400 text-sm mt-0.5">Materias primas e insumos · {inventario.length} ítems</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={restablecerInventario} className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-yellow-500/40 text-gray-300 hover:text-white rounded-xl transition-all text-sm font-medium">
            <RefreshCw className="w-4 h-4" /> Restablecer
          </button>
          <button onClick={exportarCSV} className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-yellow-500/40 text-gray-300 hover:text-white rounded-xl transition-all text-sm font-medium">
            <Download className="w-4 h-4" /> Exportar
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {([
          { label: 'Productos', value: stats.total, iconName: 'package', color: 'yellow', border: 'border-yellow-500/30 hover:border-yellow-500/60' },
          { label: 'Unidades', value: stats.stockTotal.toLocaleString(), iconName: 'boxes', color: 'blue', border: 'border-blue-500/30 hover:border-blue-500/60' },
          { label: 'Normal', value: stats.normal, iconName: 'check', color: 'green', border: 'border-green-500/30 hover:border-green-500/60' },
          { label: 'Bajo Stock', value: stats.bajoStock, iconName: 'alert', color: 'orange', border: 'border-l-[3px] border-l-orange-500 border-orange-500/30 hover:border-orange-500/60' },
          { label: 'Sin Stock', value: stats.sinStock, iconName: 'x', color: 'red', border: 'border-l-[3px] border-l-red-500 border-red-500/30 hover:border-red-500/60' },
          { label: 'Valor Est.', value: `$${(stats.valorEstimado / 1000000).toFixed(1)}M COP`, iconName: 'bar', color: 'teal', border: 'border-teal-500/30 hover:border-teal-500/60' },
        ] as const).map((item) => {
          const textMap: Record<string, string> = { yellow: 'text-yellow-400', blue: 'text-blue-400', green: 'text-green-400', orange: 'text-orange-400', red: 'text-red-400', teal: 'text-teal-400' };
          const iconEl = item.iconName === 'package' ? <Package className="w-5 h-5" /> : item.iconName === 'boxes' ? <Boxes className="w-5 h-5" /> : item.iconName === 'check' ? <CheckCircle className="w-5 h-5" /> : item.iconName === 'alert' ? <AlertTriangle className="w-5 h-5" /> : item.iconName === 'x' ? <XCircle className="w-5 h-5" /> : <BarChart3 className="w-5 h-5" />;
          return (
            <div key={item.label} className={`bg-zinc-900/80 backdrop-blur border ${item.border} rounded-xl p-3 hover:scale-105 transition-all cursor-default`}>
              <div className={`mb-2 ${textMap[item.color]}`}>{iconEl}</div>
              <p className="text-xl text-white font-black">{item.value}</p>
              <p className="text-gray-400 text-xs font-medium">{item.label}</p>
            </div>
          );
        })}
      </div>

      {/* Alerta bajo/sin stock */}
      {(stats.bajoStock > 0 || stats.sinStock > 0) && (
        <div className="bg-orange-500/8 border border-orange-500/30 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            <span className="text-orange-400 font-semibold text-sm">
              {stats.sinStock > 0 ? `${stats.sinStock} sin stock · ` : ''}
              {stats.bajoStock > 0 ? `${stats.bajoStock} bajo stock` : ''}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {inventario.filter(i => ['Sin Stock', 'Bajo Stock'].includes(getEstado(i))).map(item => (
              <button
                key={item.productoId}
                onClick={() => { setModalAjuste(item); setAjusteTipo('entrada'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all hover:scale-105 ${getEstadoColor(item)}`}
              >
                {item.nombre} ({item.stock})
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Controles */}
      <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="Buscar producto, proveedor, ubicación..."
              value={busqueda}
              onChange={e => { setBusqueda(e.target.value); setPaginaActual(1); }}
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder-gray-500 text-sm focus:outline-none focus:border-yellow-500/50 focus:ring-1 focus:ring-yellow-500/20 transition-all"
            />
          </div>
          <select
            value={filtroCategoria}
            onChange={e => { setFiltroCategoria(e.target.value); setPaginaActual(1); }}
            className="px-3 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500/50 transition-all cursor-pointer"
          >
            {categorias.map(c => <option key={c} value={c}>{c === 'all' ? 'Todas las categorías' : c}</option>)}
          </select>
          <select
            value={filtroEstado}
            onChange={e => { setFiltroEstado(e.target.value); setPaginaActual(1); }}
            className="px-3 py-2.5 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500/50 transition-all cursor-pointer"
          >
            <option value="all">Todos los estados</option>
            <option value="normal">Normal</option>
            <option value="bajo">Bajo Stock</option>
            <option value="sin">Sin Stock</option>
            <option value="sobre">Sobrestock</option>
          </select>
          {/* Vista toggle */}
          <div className="flex bg-zinc-800/50 border border-zinc-700 rounded-xl p-1 gap-1">
            {(['tabla', 'tarjetas', 'movimientos'] as Vista[]).map(v => {
              const icons: Record<Vista, React.ReactNode> = {
                tabla: <ClipboardList className="w-4 h-4" />,
                tarjetas: <Boxes className="w-4 h-4" />,
                movimientos: <History className="w-4 h-4" />,
              };
              return (
                <button
                  key={v}
                  onClick={() => setVista(v)}
                  title={v.charAt(0).toUpperCase() + v.slice(1)}
                  className={`p-2 rounded-lg transition-all ${vista === v ? 'bg-yellow-500 text-black' : 'text-gray-400 hover:text-white'}`}
                >
                  {icons[v]}
                </button>
              );
            })}
          </div>
        </div>

        {/* VISTA TABLA */}
        {vista === 'tabla' && (
          <div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-zinc-800/60 border-b border-zinc-700">
                    {[
                      { col: 'nombre' as OrdenCol, label: 'Material / Insumo' },
                      { col: 'categoria' as OrdenCol, label: 'Categoría' },
                      { col: null, label: 'Unidad' },
                      { col: 'stock' as OrdenCol, label: 'Stock' },
                      { col: null, label: 'Nivel' },
                      { col: 'estado' as OrdenCol, label: 'Estado' },
                      { col: null, label: 'Ubicación' },
                      { col: null, label: 'Acciones' },
                    ].map(({ col, label }) => (
                      <th
                        key={label}
                        onClick={col ? () => toggleOrden(col) : undefined}
                        className={`text-left text-yellow-500/80 text-xs font-bold uppercase tracking-wider px-4 py-3 ${col ? 'cursor-pointer hover:text-yellow-500 select-none' : ''}`}
                      >
                        {label}{col && <SortIcon col={col} ordenCol={ordenCol} ordenDir={ordenDir} />}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60">
                  {itemsPagina.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center text-gray-500 py-12">
                        <Package className="w-10 h-10 mx-auto mb-2 opacity-20" />
                        No hay productos que coincidan
                      </td>
                    </tr>
                  ) : itemsPagina.map(item => {
                    const pct = Math.min((item.stock / item.stockMaximo) * 100, 100);
                    const editando = editandoId === item.productoId;
                    return (
                      <tr key={item.productoId} className="hover:bg-zinc-800/30 transition-colors group">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-zinc-700/50 flex items-center justify-center text-lg flex-shrink-0">
                              {typeof item.imagen === 'string' && item.imagen.length <= 2 ? item.imagen : '📦'}
                            </div>
                            <div>
                              <p className="text-white font-semibold text-sm leading-tight">{item.nombre}</p>
                              <p className="text-gray-600 text-xs">{item.proveedor || '—'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded-md text-xs font-semibold border ${COLORES_CATEGORIA[item.categoria] || 'text-gray-400 bg-gray-500/10 border-gray-500/30'}`}>
                            {item.categoria}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-gray-400 text-xs font-mono">{item.unidad || '—'}</span>
                        </td>
                        <td className="px-4 py-3">
                          {editando ? (
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={editForm.stockMinimo}
                                onChange={e => setEditForm(f => ({ ...f, stockMinimo: parseInt(e.target.value) }))}
                                className="w-14 px-2 py-1 bg-zinc-700 border border-zinc-600 rounded text-white text-xs focus:outline-none focus:border-yellow-500"
                                placeholder="Mín"
                              />
                              <span className="text-gray-600 text-xs">mín</span>
                            </div>
                          ) : (
                            <div>
                              <span className="text-white font-bold text-lg">{item.stock}</span>
                              <span className="text-gray-600 text-xs ml-1">/ {item.stockMinimo}–{item.stockMaximo}</span>
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 min-w-[100px]">
                          <div className="w-full bg-zinc-700/50 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${getBarraColor(item)}`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <p className="text-gray-600 text-xs mt-0.5">{Math.round(pct)}%</p>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-lg text-xs font-bold border ${getEstadoColor(item)}`}>
                            {getEstado(item)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          {editando ? (
                            <input
                              type="text"
                              value={editForm.ubicacion || ''}
                              onChange={e => setEditForm(f => ({ ...f, ubicacion: e.target.value }))}
                              className="w-16 px-2 py-1 bg-zinc-700 border border-zinc-600 rounded text-white text-xs focus:outline-none focus:border-yellow-500 font-mono"
                            />
                          ) : (
                            <span className="text-gray-400 text-xs font-mono">{item.ubicacion || '—'}</span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1.5">
                            {editando ? (
                              <>
                                <button onClick={() => guardarEdicion(item.productoId)} className="p-1.5 bg-green-500/15 hover:bg-green-500/30 text-green-400 rounded-lg transition-all">
                                  <Save className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => setEditandoId(null)} className="p-1.5 bg-zinc-700 hover:bg-zinc-600 text-gray-400 rounded-lg transition-all">
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  onClick={() => { setModalAjuste(item); setAjusteTipo('entrada'); }}
                                  title="Registrar movimiento"
                                  className="p-1.5 bg-yellow-500/10 hover:bg-yellow-500/25 text-yellow-400 rounded-lg transition-all hover:scale-105"
                                >
                                  <ArrowUp className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => { setModalAjuste(item); setAjusteTipo('salida'); }}
                                  title="Registrar salida"
                                  className="p-1.5 bg-red-500/10 hover:bg-red-500/25 text-red-400 rounded-lg transition-all hover:scale-105"
                                >
                                  <ArrowDown className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => iniciarEdicion(item)}
                                  title="Editar parámetros"
                                  className="p-1.5 bg-blue-500/10 hover:bg-blue-500/25 text-blue-400 rounded-lg transition-all hover:scale-105"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Paginación */}
            {totalPaginas > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-zinc-800">
                <span className="text-gray-500 text-xs">
                  {(paginaActual - 1) * ITEMS_POR_PAGINA + 1}–{Math.min(paginaActual * ITEMS_POR_PAGINA, filtrado.length)} de {filtrado.length}
                </span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setPaginaActual(p => Math.max(1, p - 1))}
                    disabled={paginaActual === 1}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-gray-300 rounded-lg text-xs font-semibold transition-all"
                  >
                    Ant.
                  </button>
                  {Array.from({ length: Math.min(5, totalPaginas) }, (_, i) => {
                    const p = Math.max(1, Math.min(paginaActual - 2, totalPaginas - 4)) + i;
                    return (
                      <button
                        key={p}
                        onClick={() => setPaginaActual(p)}
                        className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${p === paginaActual ? 'bg-yellow-500 text-black' : 'bg-zinc-800 hover:bg-zinc-700 text-gray-300'}`}
                      >
                        {p}
                      </button>
                    );
                  })}
                  <button
                    onClick={() => setPaginaActual(p => Math.min(totalPaginas, p + 1))}
                    disabled={paginaActual === totalPaginas}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-gray-300 rounded-lg text-xs font-semibold transition-all"
                  >
                    Sig.
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VISTA TARJETAS */}
        {vista === 'tarjetas' && (
          <div className="p-4">
            {filtrado.length === 0 ? (
              <div className="text-center text-gray-500 py-12">
                <Package className="w-10 h-10 mx-auto mb-2 opacity-20" />No hay productos
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filtrado.slice(0, 40).map(item => {
                  const pct = Math.min((item.stock / item.stockMaximo) * 100, 100);
                  return (
                    <div key={item.productoId} className={`bg-zinc-800/50 border rounded-xl p-4 hover:scale-[1.02] transition-all cursor-default ${
                      getEstado(item) === 'Sin Stock' ? 'border-red-500/30' :
                      getEstado(item) === 'Bajo Stock' ? 'border-orange-500/30' :
                      'border-zinc-700'
                    }`}>
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-10 h-10 rounded-xl bg-zinc-700/50 flex items-center justify-center text-xl">
                          {typeof item.imagen === 'string' && item.imagen.length <= 2 ? item.imagen : '📦'}
                        </div>
                        <span className={`px-2 py-0.5 rounded-md text-xs font-bold border ${getEstadoColor(item)}`}>
                          {getEstado(item)}
                        </span>
                      </div>
                      <p className="text-white font-bold text-sm leading-tight mb-1 line-clamp-2">{item.nombre}</p>
                      <div className="flex items-center gap-1.5 mb-3">
                        <p className="text-gray-500 text-xs">{item.categoria}</p>
                        {item.unidad && <span className="text-gray-700 text-xs">· {item.unidad}</span>}
                      </div>
                      <div className="mb-2">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-500">Stock</span>
                          <span className="text-white font-bold">{item.stock} <span className="text-gray-600 font-normal">/ {item.stockMaximo}</span></span>
                        </div>
                        <div className="w-full bg-zinc-700/50 rounded-full h-1.5">
                          <div className={`h-1.5 rounded-full ${getBarraColor(item)}`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <div className="flex justify-between items-center mt-3 pt-3 border-t border-zinc-700/50">
                        <span className="text-gray-600 text-xs font-mono">{item.ubicacion || '—'}</span>
                        <button
                          onClick={() => { setModalAjuste(item); setAjusteTipo('entrada'); }}
                          className="p-1.5 bg-yellow-500/10 hover:bg-yellow-500/25 text-yellow-400 rounded-lg transition-all hover:scale-105"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* VISTA MOVIMIENTOS */}
        {vista === 'movimientos' && (
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-400 text-sm">{movimientos.length} movimiento{movimientos.length !== 1 ? 's' : ''} registrado{movimientos.length !== 1 ? 's' : ''}</p>
            </div>
            {movimientos.length === 0 ? (
              <div className="text-center text-gray-500 py-12">
                <History className="w-10 h-10 mx-auto mb-2 opacity-20" />
                <p>Aún no hay movimientos registrados</p>
                <p className="text-xs mt-1">Los ajustes de stock aparecerán aquí</p>
              </div>
            ) : movimientos.map(mov => {
              const tipoConfig = {
                entrada: { color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: <ArrowUp className="w-4 h-4" />, label: 'Entrada' },
                salida: { color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: <ArrowDown className="w-4 h-4" />, label: 'Salida' },
                ajuste: { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: <Edit3 className="w-4 h-4" />, label: 'Ajuste' },
              };
              const cfg = tipoConfig[mov.tipo];
              const delta = mov.stockNuevo - mov.stockAnterior;
              return (
                <div key={mov.id} className={`flex items-center gap-4 border rounded-xl px-4 py-3 ${cfg.color}`}>
                  <div className="flex-shrink-0">{cfg.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-white font-semibold text-sm">{mov.nombreProducto}</span>
                      <span className={`text-xs px-2 py-0.5 rounded border ${cfg.color}`}>{cfg.label}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{mov.motivo}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={`font-bold text-sm ${delta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {delta >= 0 ? '+' : ''}{delta} un.
                    </p>
                    <p className="text-gray-600 text-xs">{mov.stockAnterior} → {mov.stockNuevo}</p>
                    <p className="text-gray-700 text-xs">{new Date(mov.fecha).toLocaleDateString('es-CO')}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal Ajuste de Stock */}
      {modalAjuste && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900 border border-yellow-500/40 rounded-2xl max-w-md w-full p-6 shadow-2xl shadow-yellow-500/10">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-white font-black text-lg">Registrar Movimiento</h3>
                <p className="text-gray-500 text-xs mt-0.5">{modalAjuste.nombre}</p>
              </div>
              <div className="text-right">
                <p className="text-3xl text-white font-black">{modalAjuste.stock}</p>
                <p className="text-gray-600 text-xs">stock actual</p>
              </div>
            </div>

            {/* Tipo */}
            <div className="flex gap-2 mb-4">
              {(['entrada', 'salida', 'ajuste'] as const).map(tipo => (
                <button
                  key={tipo}
                  onClick={() => setAjusteTipo(tipo)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold capitalize transition-all ${
                    ajusteTipo === tipo
                      ? tipo === 'entrada' ? 'bg-green-500 text-white'
                        : tipo === 'salida' ? 'bg-red-500 text-white'
                        : 'bg-blue-500 text-white'
                      : 'bg-zinc-800 text-gray-400 hover:text-white'
                  }`}
                >
                  {tipo === 'entrada' ? '↑ Entrada' : tipo === 'salida' ? '↓ Salida' : '⟳ Ajuste'}
                </button>
              ))}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-1.5">
                  {ajusteTipo === 'ajuste' ? 'Nuevo stock total' : 'Cantidad'}
                </label>
                <input
                  type="number"
                  min="1"
                  value={ajusteCantidad}
                  onChange={e => setAjusteCantidad(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-xl font-bold focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                  placeholder="0"
                  autoFocus
                />
                {ajusteCantidad && !isNaN(parseInt(ajusteCantidad)) && (
                  <p className="text-gray-500 text-xs mt-1">
                    Resultado: {' '}
                    <span className="text-white font-semibold">
                      {ajusteTipo === 'entrada' ? modalAjuste.stock + parseInt(ajusteCantidad) :
                       ajusteTipo === 'salida' ? Math.max(0, modalAjuste.stock - parseInt(ajusteCantidad)) :
                       parseInt(ajusteCantidad)} unidades
                    </span>
                  </p>
                )}
              </div>
              <div>
                <label className="block text-yellow-500 text-xs font-bold uppercase tracking-wide mb-1.5">Motivo</label>
                <input
                  type="text"
                  value={ajusteMotivo}
                  onChange={e => setAjusteMotivo(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/20 transition-all"
                  placeholder="Ej: Compra proveedor, Venta, Devolución..."
                />
              </div>
              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => { setModalAjuste(null); setAjusteCantidad(''); setAjusteMotivo(''); }}
                  className="flex-1 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all font-semibold text-sm"
                >
                  Cancelar
                </button>
                <button
                  onClick={aplicarAjuste}
                  disabled={!ajusteCantidad || !ajusteMotivo.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 disabled:opacity-40 disabled:cursor-not-allowed text-black rounded-xl transition-all hover:scale-105 font-black shadow-lg shadow-yellow-500/30 text-sm"
                >
                  Registrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <PQRSWidget modulo="inventario" titulo="PQRS — Inventario" />
    </div>
  );
};
