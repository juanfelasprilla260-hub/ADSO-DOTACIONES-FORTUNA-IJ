import React, { useState, useRef, useEffect } from 'react';
import {
  Camera, User, Phone, Hash, Tag, Mail, Shield, Key,
  Save, Eye, EyeOff, CheckCircle, AlertCircle, Edit3, X
} from 'lucide-react';
import { useAuth, type ProfileUpdate } from '../AuthContext';

const ROLE_LABELS: Record<string, string> = {
  gerente_general:  'Gerente General',
  subgerente:       'Subgerente',
  admin_inventario: 'Administrador de Inventario',
  cliente:          'Cliente',
};

const ROLE_COLORS: Record<string, string> = {
  gerente_general:  'text-red-400 bg-red-500/10 border-red-500/30',
  subgerente:       'text-purple-400 bg-purple-500/10 border-purple-500/30',
  admin_inventario: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  cliente:          'text-green-400 bg-green-500/10 border-green-500/30',
};

export const Perfil: React.FC = () => {
  const { user, updateProfile, changePassword } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);

  // ── Formulario de perfil ──────────────────────────────────
  const [form, setForm] = useState({
    nombre:   user?.nombre   || '',
    apodo:    user?.apodo    || '',
    telefono: user?.telefono || '',
    tipoId:   user?.tipoId   || 'cedula',
    numeroId: user?.numeroId || '',
  });
  const [foto, setFoto]         = useState<string>(user?.foto || '');
  const [profileMsg, setProfileMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [editingProfile, setEditingProfile] = useState(false);

  // ── Formulario contraseña ─────────────────────────────────
  const [passForm, setPassForm] = useState({ current: '', nueva: '', confirmar: '' });
  const [showPass, setShowPass] = useState({ current: false, nueva: false, confirmar: false });
  const [passMsg, setPassMsg]   = useState<{ ok: boolean; text: string } | null>(null);

  // Sincronizar si user cambia
  useEffect(() => {
    if (user) {
      setForm({
        nombre:   user.nombre   || '',
        apodo:    user.apodo    || '',
        telefono: user.telefono || '',
        tipoId:   user.tipoId   || 'cedula',
        numeroId: user.numeroId || '',
      });
      setFoto(user.foto || '');
    }
  }, [user]);

  const handleFotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setProfileMsg({ ok: false, text: 'La foto no debe superar 2 MB' });
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => {
      const result = ev.target?.result as string;
      setFoto(result);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = () => {
    if (!form.nombre.trim()) {
      setProfileMsg({ ok: false, text: 'El nombre no puede estar vacío' });
      return;
    }
    const update: ProfileUpdate = {
      nombre:   form.nombre.trim(),
      apodo:    form.apodo.trim() || undefined,
      telefono: form.telefono.trim() || undefined,
      tipoId:   form.tipoId || undefined,
      numeroId: form.numeroId.trim() || undefined,
      foto:     foto || undefined,
    };
    const ok = updateProfile(update);
    setProfileMsg(ok
      ? { ok: true,  text: '¡Perfil actualizado exitosamente!' }
      : { ok: false, text: 'Error al guardar el perfil' }
    );
    setEditingProfile(false);
    setTimeout(() => setProfileMsg(null), 3000);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    if (passForm.nueva !== passForm.confirmar) {
      setPassMsg({ ok: false, text: 'Las contraseñas nuevas no coinciden' });
      return;
    }
    const result = changePassword(passForm.current, passForm.nueva);
    setPassMsg(result.ok
      ? { ok: true,  text: '¡Contraseña actualizada exitosamente!' }
      : { ok: false, text: result.error || 'Error al cambiar la contraseña' }
    );
    if (result.ok) setPassForm({ current: '', nueva: '', confirmar: '' });
    setTimeout(() => setPassMsg(null), 4000);
  };

  const initials = (user?.apodo || user?.nombre || '?').charAt(0).toUpperCase();

  // Strength bar
  const passStrength = (p: string) => {
    if (!p) return 0;
    let s = 0;
    if (p.length >= 6) s++;
    if (p.length >= 10) s++;
    if (/[A-Z]/.test(p)) s++;
    if (/[0-9]/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p)) s++;
    return Math.min(s, 4);
  };
  const strength     = passStrength(passForm.nueva);
  const strengthCols = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-green-500'];
  const strengthLabels = ['Muy débil', 'Débil', 'Media', 'Fuerte'];

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in pb-12">
      {/* ── Header ── */}
      <div className="flex items-center gap-4">
        <div style={{
          background: 'linear-gradient(135deg, #eab308, #f97316)',
          padding: '12px', borderRadius: '12px', color: 'black',
        }}>
          <User className="w-7 h-7" />
        </div>
        <div>
          <h1 className="text-3xl font-black text-white">Mi Perfil</h1>
          <p className="text-zinc-400 text-sm mt-0.5">Administra tu información personal y seguridad</p>
        </div>
      </div>

      {/* ── Foto + info resumida ── */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-yellow-500/40 shadow-xl shadow-yellow-500/10">
              {foto ? (
                <img src={foto} alt="Foto de perfil" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-black text-3xl font-black">
                  {initials}
                </div>
              )}
            </div>
            <button
              onClick={() => fileRef.current?.click()}
              className="absolute bottom-0 right-0 w-8 h-8 bg-yellow-500 hover:bg-yellow-400 rounded-full flex items-center justify-center text-black shadow-lg transition-all hover:scale-110"
              title="Cambiar foto"
            >
              <Camera className="w-4 h-4" />
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFotoChange}
            />
          </div>

          {/* Info resumida */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-1">
              <h2 className="text-xl font-black text-white">{user?.nombre}</h2>
              {user?.apodo && (
                <span className="text-yellow-400 text-sm font-semibold">«{user.apodo}»</span>
              )}
            </div>
            <p className="text-zinc-400 text-sm mb-2">{user?.email}</p>
            <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${ROLE_COLORS[user?.role || 'cliente']}`}>
                {ROLE_LABELS[user?.role || 'cliente']}
              </span>
              {user?.codigoEmpleado && (
                <span className="px-3 py-1 rounded-full text-xs font-semibold border border-zinc-700 text-zinc-400 font-mono">
                  {user.codigoEmpleado}
                </span>
              )}
            </div>
          </div>

          {/* Botón editar */}
          <button
            onClick={() => setEditingProfile(v => !v)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all hover:scale-105 ${
              editingProfile
                ? 'bg-zinc-800 border border-zinc-700 text-zinc-400'
                : 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg shadow-yellow-500/20'
            }`}
          >
            {editingProfile ? <><X className="w-4 h-4" />Cancelar</> : <><Edit3 className="w-4 h-4" />Editar</>}
          </button>
        </div>

        {/* Mensaje perfil */}
        {profileMsg && (
          <div className={`mt-4 flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold ${
            profileMsg.ok
              ? 'bg-green-500/10 border border-green-500/30 text-green-400'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}>
            {profileMsg.ok ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {profileMsg.text}
          </div>
        )}
      </div>

      {/* ── Información Personal ── */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
        <div className="flex items-center gap-3 px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
          <User className="w-5 h-5 text-yellow-500" />
          <h3 className="text-white font-bold">Información Personal</h3>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Nombre */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <User className="w-3.5 h-3.5 inline mr-1.5" />Nombre completo
              </label>
              {editingProfile ? (
                <input
                  type="text"
                  value={form.nombre}
                  onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))}
                  className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all"
                />
              ) : (
                <p className="text-white font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm">{user?.nombre || '—'}</p>
              )}
            </div>

            {/* Apodo */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Tag className="w-3.5 h-3.5 inline mr-1.5" />Apodo / Nickname
              </label>
              {editingProfile ? (
                <input
                  type="text"
                  value={form.apodo}
                  onChange={e => setForm(f => ({ ...f, apodo: e.target.value }))}
                  placeholder="Como quieres que te llamen"
                  className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all placeholder-zinc-600"
                />
              ) : (
                <p className="text-white font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm">{user?.apodo || <span className="text-zinc-600">Sin apodo</span>}</p>
              )}
            </div>

            {/* Teléfono */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Phone className="w-3.5 h-3.5 inline mr-1.5" />Teléfono
              </label>
              {editingProfile ? (
                <input
                  type="tel"
                  value={form.telefono}
                  onChange={e => setForm(f => ({ ...f, telefono: e.target.value }))}
                  placeholder="3001234567"
                  className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all placeholder-zinc-600"
                />
              ) : (
                <p className="text-white font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm">{user?.telefono || <span className="text-zinc-600">Sin número</span>}</p>
              )}
            </div>

            {/* Email (siempre readonly) */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Mail className="w-3.5 h-3.5 inline mr-1.5" />Correo / Usuario
                <span className="text-zinc-600 font-normal normal-case ml-1">(no editable)</span>
              </label>
              <p className="text-zinc-400 font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm select-all">{user?.email}</p>
            </div>

            {/* Tipo de ID */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Hash className="w-3.5 h-3.5 inline mr-1.5" />Tipo de identificación
              </label>
              {editingProfile ? (
                <select
                  value={form.tipoId}
                  onChange={e => setForm(f => ({ ...f, tipoId: e.target.value }))}
                  className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all cursor-pointer"
                >
                  <option value="cedula">Cédula</option>
                  <option value="nit">NIT</option>
                  <option value="pasaporte">Pasaporte</option>
                </select>
              ) : (
                <p className="text-white font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm capitalize">{user?.tipoId || <span className="text-zinc-600">No especificado</span>}</p>
              )}
            </div>

            {/* Número de ID */}
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Hash className="w-3.5 h-3.5 inline mr-1.5" />N° Identificación
              </label>
              {editingProfile ? (
                <input
                  type="text"
                  value={form.numeroId}
                  onChange={e => setForm(f => ({ ...f, numeroId: e.target.value }))}
                  placeholder="1234567890"
                  className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all placeholder-zinc-600"
                />
              ) : (
                <p className="text-white font-medium px-4 py-2.5 bg-zinc-800/40 rounded-xl text-sm">{user?.numeroId || <span className="text-zinc-600">No registrado</span>}</p>
              )}
            </div>
          </div>

          {/* Rol + código (siempre readonly) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-1 border-t border-zinc-800">
            <div>
              <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                <Shield className="w-3.5 h-3.5 inline mr-1.5" />Rol
                <span className="text-zinc-600 font-normal normal-case ml-1">(no editable)</span>
              </label>
              <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold border ${ROLE_COLORS[user?.role || 'cliente']}`}>
                {ROLE_LABELS[user?.role || 'cliente']}
              </span>
            </div>
            {user?.codigoEmpleado && (
              <div>
                <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">
                  <Key className="w-3.5 h-3.5 inline mr-1.5" />Código de empleado
                </label>
                <p className="text-yellow-400 font-mono font-bold px-4 py-2.5 bg-yellow-500/5 border border-yellow-500/20 rounded-xl text-sm">
                  {user.codigoEmpleado}
                </p>
              </div>
            )}
          </div>

          {/* Botón guardar (solo si editando) */}
          {editingProfile && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveProfile}
                className="flex items-center gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-black px-6 py-2.5 rounded-xl transition-all hover:scale-105 shadow-lg shadow-yellow-500/20"
              >
                <Save className="w-4 h-4" />
                Guardar cambios
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Cambiar contraseña ── */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
        <div className="flex items-center gap-3 px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
          <Key className="w-5 h-5 text-yellow-500" />
          <h3 className="text-white font-bold">Cambiar contraseña</h3>
        </div>
        <div className="p-6">
          <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
            {/* Contraseña actual */}
            {[
              { key: 'current',    label: 'Contraseña actual',    placeholder: '••••••••' },
              { key: 'nueva',      label: 'Nueva contraseña',     placeholder: 'Mínimo 6 caracteres' },
              { key: 'confirmar',  label: 'Confirmar contraseña', placeholder: 'Repite la nueva contraseña' },
            ].map(field => (
              <div key={field.key}>
                <label className="block text-zinc-400 text-xs font-bold uppercase tracking-wide mb-2">{field.label}</label>
                <div className="relative">
                  <input
                    type={showPass[field.key as keyof typeof showPass] ? 'text' : 'password'}
                    value={passForm[field.key as keyof typeof passForm]}
                    onChange={e => setPassForm(f => ({ ...f, [field.key]: e.target.value }))}
                    placeholder={field.placeholder}
                    required
                    className="w-full px-4 py-2.5 pr-10 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all placeholder-zinc-600"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(p => ({ ...p, [field.key]: !p[field.key as keyof typeof p] }))}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors"
                  >
                    {showPass[field.key as keyof typeof showPass] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Indicador de fuerza (solo campo nueva) */}
                {field.key === 'nueva' && passForm.nueva && (
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      {[0, 1, 2, 3].map(i => (
                        <div key={i} className={`flex-1 h-1 rounded-full transition-all ${i < strength ? strengthCols[strength - 1] : 'bg-zinc-700'}`} />
                      ))}
                    </div>
                    <p className="text-xs text-zinc-500">{strengthLabels[Math.max(0, strength - 1)] || 'Muy débil'}</p>
                  </div>
                )}
              </div>
            ))}

            {passMsg && (
              <div className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold ${
                passMsg.ok
                  ? 'bg-green-500/10 border border-green-500/30 text-green-400'
                  : 'bg-red-500/10 border border-red-500/30 text-red-400'
              }`}>
                {passMsg.ok ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                {passMsg.text}
              </div>
            )}

            <button
              type="submit"
              className="flex items-center gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-black px-6 py-2.5 rounded-xl transition-all hover:scale-105 shadow-lg shadow-yellow-500/20"
            >
              <Key className="w-4 h-4" />
              Actualizar contraseña
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
