import React, { useState, useEffect } from 'react';
import { FileText, Download, TrendingUp, Clock, Package, Truck, CheckCircle, XCircle, Hammer, ChevronDown, ChevronUp, Receipt } from 'lucide-react';
import { useAuth } from '../AuthContext';
import { PQRSWidget } from './PQRSWidget';
import { TicketModal, type PedidoParaTicket } from './TicketModal';
import { buscarFicha, FICHA_GENERICA, minutosATexto } from '../../data/fichasTecnicas';

interface Pedido {
  id: string;
  ticketId?: string;
  clienteNombre: string;
  clienteEmail: string;
  productos: Array<{ nombre: string; cantidad: number; precio: number }>;
  total: number;
  estado: 'pendiente' | 'fabricando' | 'procesando' | 'enviado' | 'entregado' | 'cancelado';
  fecha: string;
  historial?: Array<{ estado: string; fecha: string; nota?: string }>;
}

// ── Colores fieles a styles.css ──────────────────────────────
const ESTADO_META: Record<string, { label: string; icon: React.ReactNode; badgeBg: string; badgeColor: string; btnActive: string }> = {
  pendiente:  { label: 'Pendiente',  icon: <Clock className="w-3.5 h-3.5" />,       badgeBg: 'bg-yellow-500/20',  badgeColor: 'text-yellow-300 border-yellow-500/40',  btnActive: 'bg-[#2a3a1c] border-[#4a7a28] text-white' },
  fabricando: { label: 'Fabricando', icon: <Hammer className="w-3.5 h-3.5" />,      badgeBg: 'bg-blue-600/25',    badgeColor: 'text-white border-blue-600',             btnActive: 'bg-[#1e3a5f] border-[#2563eb] text-white' },
  procesando: { label: 'Procesando', icon: <Package className="w-3.5 h-3.5" />,     badgeBg: 'bg-blue-600/25',    badgeColor: 'text-white border-blue-600',             btnActive: 'bg-[#1e3a5f] border-[#2563eb] text-white' },
  enviado:    { label: 'Enviado',    icon: <Truck className="w-3.5 h-3.5" />,        badgeBg: 'bg-purple-500/20',  badgeColor: 'text-purple-300 border-purple-500/40',  btnActive: 'bg-[#2d1b69] border-[#7c3aed] text-white' },
  entregado:  { label: 'Entregado',  icon: <CheckCircle className="w-3.5 h-3.5" />, badgeBg: 'bg-green-600/20',   badgeColor: 'text-green-300 border-green-600/50',    btnActive: 'bg-[#14532d] border-[#16a34a] text-white' },
  cancelado:  { label: 'Cancelado',  icon: <XCircle className="w-3.5 h-3.5" />,     badgeBg: 'bg-red-600/20',     badgeColor: 'text-red-300 border-red-600/50',        btnActive: 'bg-[#450a0a] border-[#dc2626] text-white' },
};

const ESTADOS_TIMELINE = ['pendiente', 'fabricando', 'enviado', 'entregado'] as const;

export const Pedidos: React.FC = () => {
  const { user } = useAuth();
  const [pedidos, setPedidos]           = useState<Pedido[]>([]);
  const [filtroEstado, setFiltroEstado] = useState<string>('todos');
  const [searchTerm, setSearchTerm]     = useState('');
  const [expandedId, setExpandedId]     = useState<string | null>(null);
  const [ticketPedido, setTicketPedido] = useState<PedidoParaTicket | null>(null);

  const canManage = user?.role === 'gerente_general' || user?.role === 'subgerente' || user?.role === 'admin_inventario';
  const isCliente = user?.role === 'cliente';

  useEffect(() => {
    const stored = localStorage.getItem('pedidos');
    if (stored) {
      setPedidos(JSON.parse(stored));
    } else {
      const initial: Pedido[] = [
        {
          id: '1',
          clienteNombre: 'Juan Pérez',
          clienteEmail: 'juan@empresa.com',
          productos: [
            { nombre: 'Uniforme Empresarial', cantidad: 5, precio: 315000 },
            { nombre: 'Botas de Seguridad',   cantidad: 3, precio: 298000 },
          ],
          total: 2469000,
          estado: 'fabricando',
          fecha: new Date().toISOString(),
          historial: [{ estado: 'pendiente', fecha: new Date().toISOString(), nota: 'Pedido recibido' }],
        },
        {
          id: '2',
          clienteNombre: 'María García',
          clienteEmail: 'maria@empresa.com',
          productos: [{ nombre: 'Casco Protector', cantidad: 10, precio: 133000 }],
          total: 1330000,
          estado: 'entregado',
          fecha: new Date(Date.now() - 86400000).toISOString(),
          historial: [
            { estado: 'pendiente',  fecha: new Date(Date.now() - 86400000).toISOString() },
            { estado: 'fabricando', fecha: new Date(Date.now() - 43200000).toISOString() },
            { estado: 'entregado',  fecha: new Date(Date.now() - 3600000).toISOString()  },
          ],
        },
      ];
      setPedidos(initial);
      localStorage.setItem('pedidos', JSON.stringify(initial));
    }
  }, []);

  const actualizarEstado = (id: string, nuevoEstado: Pedido['estado']) => {
    const updated = pedidos.map(p => {
      if (p.id !== id) return p;
      const historial = [...(p.historial || []), {
        estado: nuevoEstado,
        fecha: new Date().toISOString(),
        nota: `Actualizado por ${user?.nombre}`,
      }];
      return { ...p, estado: nuevoEstado, historial };
    });
    setPedidos(updated);
    localStorage.setItem('pedidos', JSON.stringify(updated));
  };

  const generarInformePedido = (pedido: Pedido) => {
    const fecha = new Date(pedido.fecha);
    const fechaStr = fecha.toLocaleDateString('es-CO', { day:'2-digit', month:'2-digit', year:'numeric' });
    const SEP  = '═════════════════════════════════════════════════════════════';
    const SEP2 = '─────────────────────────────────────────────────────────────';

    // Helper: tabla ASCII con columnas fijas
    const tabla = (cols: number[], headers: string[], rows: string[][]): string[] => {
      const borde = '+' + cols.map(w => '-'.repeat(w + 2)).join('+') + '+';
      const fila = (cells: string[]) =>
        '| ' + cells.map((c, i) => c.padEnd(cols[i])).join(' | ') + ' |';
      return [borde, fila(headers), borde, ...rows.map(r => fila(r)), borde];
    };

    const lineas: string[] = [];
    lineas.push(SEP);
    lineas.push('                        DOTACIONES FORTUNA IJ');
    lineas.push('                 INFORME TÉCNICO DE PRODUCCIÓN');
    lineas.push(SEP);
    lineas.push('');
    lineas.push(`PEDIDO No.:        ${pedido.id}`);
    lineas.push(`FECHA:             ${fechaStr}`);
    lineas.push(`CLIENTE:           ${pedido.clienteNombre}`);
    lineas.push(`CORREO:            ${pedido.clienteEmail}`);
    lineas.push(`ESTADO:            ${(ESTADO_META[pedido.estado]?.label || pedido.estado).toUpperCase()}`);
    lineas.push('');
    lineas.push(SEP);
    lineas.push('                          PRODUCTOS SOLICITADOS');
    lineas.push(SEP);
    lineas.push('');

    // Tabla de productos
    const prodRows = pedido.productos.map(p => [
      p.nombre,
      (p as any).talla || 'M',
      String(p.cantidad),
      `$${p.precio.toLocaleString('es-CO')}`,
      `$${(p.cantidad * p.precio).toLocaleString('es-CO')}`,
    ]);
    tabla([26, 6, 8, 13, 13],
      ['Producto', 'Talla', 'Cantidad', 'Valor Unit.', 'Subtotal'],
      prodRows
    ).forEach(l => lineas.push(l));
    lineas.push('');
    lineas.push(`TOTAL DEL PEDIDO: $${pedido.total.toLocaleString('es-CO', { maximumFractionDigits: 0 })} COP`);
    lineas.push('');

    // Detalle técnico por producto
    lineas.push(SEP);
    lineas.push('                    DETALLE TÉCNICO DE PRODUCCIÓN');
    lineas.push(SEP);

    let totalMinsAllProducts = 0;
    const resumenMateriales: Record<string, { unidad: string; total: number }> = {};

    pedido.productos.forEach(prod => {
      lineas.push('');
      lineas.push('PRODUCTO:');
      lineas.push(prod.nombre);
      lineas.push('');
      lineas.push(`Cantidad solicitada: ${prod.cantidad} unidades`);
      lineas.push('');
      lineas.push(SEP2);
      lineas.push('CONSUMO DE MATERIA PRIMA');
      lineas.push(SEP2);
      lineas.push('');

      const ficha = buscarFicha(prod.nombre) ?? { ...FICHA_GENERICA, nombre: prod.nombre, keywords: [] };
      const matRows = ficha.materiales.map(m => {
        const total = m.consumoXPrenda * prod.cantidad;
        // Acumular en resumen
        if (!resumenMateriales[m.material]) resumenMateriales[m.material] = { unidad: m.unidad, total: 0 };
        resumenMateriales[m.material].total += total;
        return [
          m.material,
          m.unidad,
          String(m.consumoXPrenda),
          String(Math.round(total * 100) / 100),
        ];
      });

      tabla([22, 7, 18, 22],
        ['Material', 'Unidad', 'Consumo x Prenda', 'Consumo Total Pedido'],
        matRows
      ).forEach(l => lineas.push(l));

      lineas.push('');
      lineas.push(SEP);
      lineas.push('                      TIEMPOS DE FABRICACIÓN');
      lineas.push(SEP);
      lineas.push('');

      const tiempoRows = ficha.procesos.map(p => [
        p.proceso,
        `${p.minutosXPrenda} minutos`,
        `${p.minutosXPrenda * prod.cantidad} minutos`,
      ]);

      tabla([27, 17, 25],
        ['Proceso', 'Tiempo x Prenda', 'Tiempo Total Pedido'],
        tiempoRows
      ).forEach(l => lineas.push(l));

      const tiempoTotalPedido = ficha.tiempoTotalXPrenda * prod.cantidad;
      totalMinsAllProducts += tiempoTotalPedido;
      lineas.push('');
      lineas.push(`TIEMPO TOTAL POR PRENDA : ${ficha.tiempoTotalXPrenda} minutos`);
      lineas.push('');
      lineas.push(`TIEMPO TOTAL DEL PEDIDO : ${tiempoTotalPedido} minutos`);
      lineas.push(`                         = ${minutosATexto(tiempoTotalPedido)}`);
    });

    // Resumen ejecutivo
    lineas.push('');
    lineas.push(SEP);
    lineas.push('                          RESUMEN EJECUTIVO');
    lineas.push(SEP);
    lineas.push('');
    lineas.push('RESUMEN DE MATERIA PRIMA');
    lineas.push('');
    Object.entries(resumenMateriales).forEach(([mat, data]) => {
      const dots = '.'.repeat(Math.max(2, 30 - mat.length));
      lineas.push(`• ${mat} ${dots} ${data.total} ${data.unidad.toLowerCase()}${data.total !== 1 ? 's' : ''}`);
    });

    lineas.push('');
    lineas.push(SEP2);
    lineas.push('');
    lineas.push('RESUMEN DE PRODUCCIÓN');
    lineas.push('');
    const totalPrendas = pedido.productos.reduce((s, p) => s + p.cantidad, 0);
    lineas.push(`Cantidad total de prendas : ${totalPrendas}`);
    lineas.push('');
    lineas.push(`Tiempo total de producción : ${minutosATexto(totalMinsAllProducts)}`);
    lineas.push('');
    lineas.push(`Estado actual del pedido : ${(ESTADO_META[pedido.estado]?.label || pedido.estado).toUpperCase()}`);

    // Historial
    if (pedido.historial && pedido.historial.length > 0) {
      lineas.push('');
      lineas.push(SEP);
      lineas.push('                         HISTORIAL DEL PEDIDO');
      lineas.push(SEP);
      lineas.push('');
      pedido.historial.forEach(h => {
        const d = new Date(h.fecha);
        const ds = `${d.toLocaleDateString('es-CO')} ${d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}`;
        lineas.push(`${ds}    ${(ESTADO_META[h.estado]?.label || h.estado).toUpperCase()}`);
        lineas.push('');
      });
    }

    // Observaciones
    lineas.push(SEP);
    lineas.push('                           OBSERVACIONES');
    lineas.push(SEP);
    lineas.push('');
    lineas.push('• El consumo de materia prima fue calculado automáticamente a partir de la');
    lineas.push('  ficha técnica registrada para cada prenda.');
    lineas.push('');
    lineas.push('• Los tiempos corresponden al proceso completo de fabricación, incluyendo');
    lineas.push('  corte, confección, acabados, control de calidad y empaque.');
    lineas.push('');
    lineas.push('• Este informe constituye un soporte técnico del pedido y permite conocer');
    lineas.push('  los recursos utilizados para la elaboración de las prendas solicitadas.');
    lineas.push('');
    lineas.push(SEP);
    lineas.push('                 DOTACIONES FORTUNA IJ © 2026');
    lineas.push('        Sistema Integrado de Gestión de Producción Textil');
    lineas.push(SEP);

    const blob = new Blob([lineas.join('\n')], { type: 'text/plain; charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = `informe-pedido-${pedido.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Clientes: solo sus pedidos; gestores: todos
  const pedidosVisibles = isCliente
    ? pedidos.filter(p => p.clienteEmail === user?.email)
    : pedidos;

  const pedidosFiltrados = pedidosVisibles.filter(p => {
    const matchEstado = filtroEstado === 'todos' || p.estado === filtroEstado;
    const matchSearch = !searchTerm ||
      p.clienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.clienteEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.id.includes(searchTerm);
    return matchEstado && matchSearch;
  });

  const estadisticas = {
    total:      pedidosVisibles.length,
    valorTotal: pedidosVisibles.reduce((s, p) => s + p.total, 0),
    pendientes: pedidosVisibles.filter(p => p.estado === 'pendiente').length,
    entregados: pedidosVisibles.filter(p => p.estado === 'entregado').length,
  };

  const getTimelineIdx = (estado: string) => ESTADOS_TIMELINE.indexOf(estado as any);

  return (
    <>
      <div className="space-y-6 animate-fade-in">
        {/* ── Header (fiel a contenido-principal del HTML) ── */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div style={{
              backgroundColor: '#1e2030',
              borderRadius: '12px',
              width: '50px',
              height: '50px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
              border: '1px solid #2a2d3e',
            }}>📄</div>
            <div>
              <h1 style={{ fontSize: '28px', fontWeight: 700, color: '#f1f5f9', lineHeight: 1.1 }}>
                {isCliente ? 'Mis Pedidos' : 'Pedidos'}
              </h1>
              <p style={{ fontSize: '13px', color: '#64748b', marginTop: '2px' }}>
                {isCliente
                  ? `${estadisticas.total} pedido${estadisticas.total !== 1 ? 's' : ''} realizados`
                  : 'Gestiona y genera informes de pedidos.'}
              </p>
            </div>
          </div>
        </div>

        {/* ── STAT CARDS (fiel a alinear-cartas del HTML) ── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '16px' }}>
          {[
            { label: 'Total Pedidos', valor: estadisticas.total,      icon: '📄', cls: 'orange' },
            { label: 'Valor Total',   valor: `$${(estadisticas.valorTotal / 1000).toFixed(0)}K`, icon: '📈', cls: 'green' },
            { label: 'Pendientes',    valor: estadisticas.pendientes,  icon: '📅', cls: 'blue'   },
            { label: 'Entregados',    valor: estadisticas.entregados,  icon: '📋', cls: 'purple' },
          ].map(c => (
            <div key={c.label} style={{
              backgroundColor: '#13151c',
              border: '1px solid #1e2030',
              borderRadius: '14px',
              padding: '20px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              minHeight: '96px',
            }}>
              <div>
                <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '6px', fontWeight: 500 }}>{c.label}</p>
                <p style={{ fontSize: '28px', fontWeight: 700, color: '#f1f5f9' }}>{c.valor}</p>
              </div>
              <div style={{
                width: '48px', height: '48px', borderRadius: '12px',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px',
                backgroundColor: c.cls === 'orange' ? 'rgba(245,166,35,0.18)' : c.cls === 'green' ? 'rgba(34,197,94,0.15)' : c.cls === 'blue' ? 'rgba(59,130,246,0.15)' : 'rgba(168,85,247,0.15)',
              }}>
                {c.icon}
              </div>
            </div>
          ))}
        </div>

        {/* ── SEARCH + FILTER (fiel a search-row del HTML) ── */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {!isCliente && (
            <input
              type="text"
              placeholder="Buscar por cliente..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              style={{
                flex: 1,
                backgroundColor: '#13151c',
                border: '1px solid #1e2030',
                borderRadius: '10px',
                padding: '12px 18px',
                color: '#94a3b8',
                fontSize: '14px',
                outline: 'none',
                fontFamily: 'Inter, sans-serif',
              }}
              onFocus={e => { e.target.style.borderColor = '#f5a623'; }}
              onBlur={e => { e.target.style.borderColor = '#1e2030'; }}
            />
          )}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '8px',
            backgroundColor: '#13151c', border: '1px solid #1e2030',
            borderRadius: '10px', padding: '10px 14px',
          }}>
            <span style={{ fontSize: '15px', color: '#64748b' }}>⚙️</span>
            <select
              value={filtroEstado}
              onChange={e => setFiltroEstado(e.target.value)}
              style={{
                background: 'none', border: 'none', color: '#94a3b8',
                fontSize: '13.5px', outline: 'none', cursor: 'pointer',
                fontFamily: 'Inter, sans-serif',
              }}
            >
              <option value="todos">Todos los estados</option>
              <option value="pendiente">Pendiente</option>
              <option value="fabricando">Fabricando</option>
              <option value="enviado">Enviado</option>
              <option value="entregado">Entregado</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
        </div>

        {/* ── LISTA DE PEDIDOS ── */}
        <div className="space-y-4">
          {pedidosFiltrados.length === 0 && (
            <div style={{
              backgroundColor: '#13151c', border: '1px solid #1e2030',
              borderRadius: '14px', padding: '48px', textAlign: 'center',
            }}>
              <div style={{ fontSize: '48px', marginBottom: '12px' }}>📄</div>
              <p style={{ color: '#64748b', fontSize: '14px' }}>
                {isCliente ? 'Aún no tienes pedidos realizados' : 'No se encontraron pedidos'}
              </p>
            </div>
          )}

          {pedidosFiltrados.map(pedido => {
            const meta       = ESTADO_META[pedido.estado] || ESTADO_META.pendiente;
            const tlIdx      = getTimelineIdx(pedido.estado);
            const cancelado  = pedido.estado === 'cancelado';
            const expanded   = expandedId === pedido.id;

            return (
              <div key={pedido.id} style={{
                backgroundColor: '#13151c',
                border: '1px solid #1e2030',
                borderRadius: '14px',
                padding: '24px 26px',
              }}>
                {/* ── order-header ── */}
                <div
                  style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px', cursor: 'pointer' }}
                  onClick={() => setExpandedId(expanded ? null : pedido.id)}
                >
                  <div>
                    <h3 style={{ fontSize: '17px', fontWeight: 700, color: '#f1f5f9', marginBottom: '4px' }}>
                      Pedido # {pedido.id}
                    </h3>
                    {!isCliente && (
                      <p style={{ fontSize: '13px', color: '#94a3b8', marginBottom: '2px' }}>
                        {pedido.clienteNombre} - {pedido.clienteEmail}
                      </p>
                    )}
                    {pedido.ticketId && (
                      <p style={{ fontSize: '12px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        🧾 {pedido.ticketId}
                      </p>
                    )}
                    <p style={{ fontSize: '12px', color: '#64748b' }}>
                      {new Date(pedido.fecha).toLocaleString('es-CO')}
                    </p>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}>
                    <p style={{ fontSize: '22px', fontWeight: 700, color: '#f5a623' }}>
                      ${pedido.total.toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                    </p>
                    <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${meta.badgeColor} ${meta.badgeBg}`}>
                      {meta.label}
                    </span>
                    {expanded
                      ? <ChevronUp className="w-4 h-4" style={{ color: '#64748b' }} />
                      : <ChevronDown className="w-4 h-4" style={{ color: '#64748b' }} />
                    }
                  </div>
                </div>

                {/* ── Timeline ── */}
                {!cancelado && (
                  <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px', gap: 0 }}>
                    {ESTADOS_TIMELINE.map((e, i) => {
                      const done   = i <= tlIdx;
                      const active = i === tlIdx;
                      return (
                        <React.Fragment key={e}>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                            <div style={{
                              width: '28px', height: '28px', borderRadius: '50%',
                              border: `2px solid ${done ? '#f5a623' : '#2a2d3e'}`,
                              backgroundColor: done ? 'rgba(245,166,35,0.15)' : '#1e2030',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              boxShadow: active ? '0 0 0 3px rgba(245,166,35,0.2)' : 'none',
                              transition: 'all 0.2s',
                            }}>
                              <span style={{ fontSize: '11px' }}>
                                {e === 'pendiente' ? '⏳' : e === 'fabricando' ? '🔨' : e === 'enviado' ? '🚚' : '✅'}
                              </span>
                            </div>
                            <span style={{ fontSize: '10px', fontWeight: 600, color: done ? '#f5a623' : '#4a5568', whiteSpace: 'nowrap', textTransform: 'capitalize' }}>
                              {ESTADO_META[e]?.label || e}
                            </span>
                          </div>
                          {i < ESTADOS_TIMELINE.length - 1 && (
                            <div style={{ flex: 1, height: '2px', backgroundColor: i < tlIdx ? 'rgba(245,166,35,0.5)' : '#2a2d3e', marginBottom: '16px', marginLeft: '2px', marginRight: '2px' }} />
                          )}
                        </React.Fragment>
                      );
                    })}
                  </div>
                )}

                {/* ── order-products ── */}
                <div style={{ borderTop: '1px solid #1e2030', paddingTop: '16px', marginBottom: '20px' }}>
                  <p style={{ fontSize: '11.5px', fontWeight: 700, color: '#f5a623', letterSpacing: '1px', marginBottom: '10px', textTransform: 'uppercase' }}>
                    PRODUCTOS
                  </p>
                  {pedido.productos.map((prod, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '5px 0', fontSize: '14px', color: '#cbd5e1' }}>
                      <span>{prod.nombre} x{prod.cantidad}</span>
                      <span style={{ color: '#94a3b8', fontVariantNumeric: 'tabular-nums' }}>
                        ${(prod.cantidad * prod.precio).toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                  ))}
                </div>

                {/* ── Expandido: historial + cambio estado ── */}
                {expanded && (
                  <>
                    {pedido.historial && pedido.historial.length > 0 && (
                      <div style={{ borderTop: '1px solid #1e2030', paddingTop: '14px', marginBottom: '16px' }}>
                        <p style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '10px' }}>
                          Historial
                        </p>
                        {[...pedido.historial].reverse().map((h, i) => (
                          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '12px', marginBottom: '6px' }}>
                            <span style={{
                              width: '8px', height: '8px', borderRadius: '50%', flexShrink: 0,
                              backgroundColor: h.estado === 'entregado' ? '#4ade80' : h.estado === 'cancelado' ? '#f87171' : h.estado === 'enviado' ? '#a78bfa' : h.estado === 'fabricando' ? '#60a5fa' : '#fbbf24',
                            }} />
                            <span style={{ color: '#cbd5e1', fontWeight: 600, textTransform: 'capitalize' }}>{h.estado}</span>
                            <span style={{ color: '#4a5568' }}>{new Date(h.fecha).toLocaleString('es-CO')}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                {/* ── order-status-change + botones ── */}
                <div style={{ borderTop: '1px solid #1e2030', paddingTop: '16px' }}>
                  {canManage && pedido.estado !== 'entregado' && pedido.estado !== 'cancelado' && (
                    <>
                      <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '10px' }}>Cambiar estado:</p>
                      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '12px' }}>
                        {(['pendiente', 'fabricando', 'enviado', 'entregado', 'cancelado'] as Pedido['estado'][]).map(e => (
                          <button
                            key={e}
                            onClick={() => actualizarEstado(pedido.id, e)}
                            className={`text-xs font-medium rounded-lg transition-all hover:scale-105 ${
                              pedido.estado === e ? ESTADO_META[e].btnActive : ''
                            }`}
                            style={{
                              backgroundColor: pedido.estado === e ? undefined : '#1e2030',
                              border: pedido.estado === e ? undefined : '1px solid #2a2d3e',
                              color: pedido.estado === e ? undefined : '#94a3b8',
                              borderRadius: '8px',
                              padding: '8px 16px',
                              fontSize: '13px',
                              fontWeight: 500,
                              cursor: 'pointer',
                              fontFamily: 'Inter, sans-serif',
                            }}
                          >
                            {ESTADO_META[e].label}
                          </button>
                        ))}
                      </div>
                    </>
                  )}

                  {/* Botones generar ticket + informe */}
                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => setTicketPedido(pedido as PedidoParaTicket)}
                      style={{
                        backgroundColor: '#f5a623', color: '#0f1117', border: 'none',
                        borderRadius: '10px', padding: '12px 22px', fontSize: '14px',
                        fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center',
                        gap: '8px', fontFamily: 'Inter, sans-serif', whiteSpace: 'nowrap',
                      }}
                      onMouseEnter={e => { (e.target as HTMLElement).style.backgroundColor = '#d4881a'; }}
                      onMouseLeave={e => { (e.target as HTMLElement).style.backgroundColor = '#f5a623'; }}
                    >
                      🧾 Generar Ticket
                    </button>
                    <button
                      onClick={() => generarInformePedido(pedido)}
                      style={{
                        backgroundColor: '#f5a623', color: '#0f1117', border: 'none',
                        borderRadius: '10px', padding: '12px 22px', fontSize: '14px',
                        fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center',
                        gap: '8px', fontFamily: 'Inter, sans-serif', whiteSpace: 'nowrap',
                      }}
                      onMouseEnter={e => { (e.target as HTMLElement).style.backgroundColor = '#d4881a'; }}
                      onMouseLeave={e => { (e.target as HTMLElement).style.backgroundColor = '#f5a623'; }}
                    >
                      ⬇ Generar Informe Pedido
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <PQRSWidget modulo="pedidos" titulo="PQRS — Pedidos" />
      </div>

      {/* ── Modal Ticket ── */}
      {ticketPedido && (
        <TicketModal pedido={ticketPedido} onClose={() => setTicketPedido(null)} />
      )}
    </>
  );
};
