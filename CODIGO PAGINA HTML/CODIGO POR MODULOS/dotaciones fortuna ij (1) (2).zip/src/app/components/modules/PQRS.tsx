import React, { useState, useEffect } from 'react';
import {
  MessageSquare, Plus, CheckCircle, Clock, AlertCircle, XCircle,
  Send, Filter, Search, ChevronDown, ChevronUp, User,
  Warehouse, ShoppingCart, Package, ShoppingBag, Receipt, Shield, Globe
} from 'lucide-react';
import { useAuth } from '../AuthContext';
import { type PQRSItem, type PQRSModulo, loadPQRS, savePQRSAll } from './PQRSWidget';

// Defined locally to avoid cross-module JSX initialization issues
const ESTADO_CONFIG: Record<string, { color: string; Icon: React.FC<{className?:string}>; label: string }> = {
  abierto:     { color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', Icon: Clock,        label: 'Abierto' },
  en_revision: { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',       Icon: AlertCircle,  label: 'En Revisión' },
  resuelto:    { color: 'text-green-400 bg-green-500/10 border-green-500/20',     Icon: CheckCircle,  label: 'Resuelto' },
  cerrado:     { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20',        Icon: XCircle,      label: 'Cerrado' },
};

const FALLBACK_ESTADO = { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20', Icon: Clock, label: 'Desconocido' };

const MODULO_CONFIG: Record<string, { label: string; Icon: React.FC<{className?:string}>; color: string }> = {
  administrativo: { label: 'Administrativo', Icon: Shield,       color: 'text-red-400 bg-red-500/10 border-red-500/30' },
  ventas:         { label: 'Ventas',          Icon: ShoppingCart, color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
  inventario:     { label: 'Inventario',      Icon: Warehouse,    color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30' },
  productos:      { label: 'Productos',       Icon: Package,      color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
  pedidos:        { label: 'Pedidos',         Icon: ShoppingBag,  color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
  tickets:        { label: 'Tickets',         Icon: Receipt,      color: 'text-teal-400 bg-teal-500/10 border-teal-500/30' },
  general:        { label: 'General',         Icon: Globe,        color: 'text-gray-400 bg-gray-500/10 border-gray-500/30' },
};

const FALLBACK_MODULO = { label: 'General', Icon: Globe, color: 'text-gray-400 bg-gray-500/10 border-gray-500/20' };

const TIPO_COLOR: Record<string, string> = {
  peticion:   'bg-blue-500/15 text-blue-400 border-blue-500/30',
  queja:      'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  reclamo:    'bg-red-500/15 text-red-400 border-red-500/30',
  sugerencia: 'bg-green-500/15 text-green-400 border-green-500/30',
};

export const PQRS: React.FC = () => {
  const { user } = useAuth();
  const [pqrs, setPqrs] = useState<PQRSItem[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [filtroModulo, setFiltroModulo] = useState<string>('all');
  const [filtroEstado, setFiltroEstado] = useState<string>('all');
  const [busqueda, setBusqueda] = useState('');
  const [formData, setFormData] = useState({
    tipo: 'peticion' as PQRSItem['tipo'],
    modulo: 'general' as PQRSModulo,
    asunto: '',
    descripcion: '',
  });

  const canManage = ['gerente_general', 'subgerente', 'admin_inventario'].includes(user?.role || '');

  useEffect(() => {
    const stored = loadPQRS();
    if (stored.length > 0) {
      setPqrs(stored);
    } else {
      const inicial: PQRSItem[] = [
        {
          id: '1', tipo: 'sugerencia', modulo: 'productos',
          asunto: 'Ampliar catálogo de uniformes deportivos',
          descripcion: 'Sería útil contar con más variedad en uniformes deportivos para colegios.',
          usuario: 'Cliente Demo', email: 'cliente@demo.com',
          estado: 'abierto', fecha: new Date().toISOString(),
        },
        {
          id: '2', tipo: 'reclamo', modulo: 'ventas',
          asunto: 'Error en cobro de mi pedido',
          descripcion: 'Me cobraron dos veces el mismo pedido del 15 de junio.',
          usuario: 'María García', email: 'maria@demo.com',
          estado: 'en_revision', fecha: new Date(Date.now() - 86400000).toISOString(),
        },
        {
          id: '3', tipo: 'peticion', modulo: 'inventario',
          asunto: 'Solicitud de reposición de botas de seguridad',
          descripcion: 'El stock de botas talla 42 está agotado, se necesita reposición urgente.',
          usuario: 'Carlos López', email: 'carlos@demo.com',
          estado: 'abierto', fecha: new Date(Date.now() - 172800000).toISOString(),
        },
      ];
      savePQRSAll(inicial);
      setPqrs(inicial);
    }
  }, []);

  const refresh = () => setPqrs(loadPQRS());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const all = loadPQRS();
    const nueva: PQRSItem = {
      id: Date.now().toString(),
      tipo: formData.tipo,
      modulo: formData.modulo,
      asunto: formData.asunto,
      descripcion: formData.descripcion,
      usuario: user?.nombre || 'Anónimo',
      email: user?.email || '',
      estado: 'abierto',
      fecha: new Date().toISOString(),
    };
    savePQRSAll([...all, nueva]);
    setFormData({ tipo: 'peticion', modulo: 'general', asunto: '', descripcion: '' });
    setShowModal(false);
    refresh();
  };

  const cambiarEstado = (id: string, estado: PQRSItem['estado']) => {
    const all = loadPQRS();
    savePQRSAll(all.map(p => p.id === id ? { ...p, estado } : p));
    refresh();
  };

  const responder = (id: string) => {
    const texto = respuestas[id]?.trim();
    if (!texto) return;
    const all = loadPQRS();
    savePQRSAll(all.map(p => p.id === id ? {
      ...p, respuesta: texto,
      respondidoPor: user?.nombre,
      fechaRespuesta: new Date().toISOString(),
      estado: 'resuelto',
    } : p));
    setRespuestas(r => ({ ...r, [id]: '' }));
    refresh();
  };

  const filtrado = pqrs.filter(p => {
    const matchMod = filtroModulo === 'all' || p.modulo === filtroModulo;
    const matchEst = filtroEstado === 'all' || p.estado === filtroEstado;
    const matchBus = !busqueda || p.asunto.toLowerCase().includes(busqueda.toLowerCase()) || p.descripcion.toLowerCase().includes(busqueda.toLowerCase()) || p.usuario.toLowerCase().includes(busqueda.toLowerCase());
    return matchMod && matchEst && matchBus;
  });

  // Conteos por módulo
  const countByModulo = (m: PQRSModulo) => pqrs.filter(p => p.modulo === m && (p.estado === 'abierto' || p.estado === 'en_revision')).length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-br from-purple-500 to-purple-700 p-3 rounded-2xl shadow-xl shadow-purple-500/30 ring-1 ring-purple-400/20">
            <MessageSquare className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-3xl text-white font-black tracking-tight">PQRS</h2>
            <p className="text-gray-400 text-sm mt-0.5">Peticiones · Quejas · Reclamos · Sugerencias</p>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white px-5 py-2.5 rounded-xl transition-all font-bold shadow-lg shadow-purple-500/20 hover:scale-105 text-sm"
        >
          <Plus className="w-4 h-4" />
          Nueva PQRS
        </button>
      </div>

      {/* Mapa de módulos */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {(Object.keys(MODULO_CONFIG) as PQRSModulo[]).map(m => {
          const cfg = MODULO_CONFIG[m];
          const total = pqrs.filter(p => p.modulo === m).length;
          const pendientes = countByModulo(m);
          return (
            <button
              key={m}
              onClick={() => setFiltroModulo(filtroModulo === m ? 'all' : m)}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all hover:scale-105 text-center ${
                filtroModulo === m
                  ? cfg.color + ' scale-105'
                  : 'bg-zinc-900/60 border-zinc-800 text-gray-400 hover:border-zinc-600'
              }`}
            >
              <cfg.Icon className="w-4 h-4" />
              <span className="text-xs font-semibold leading-tight">{cfg.label}</span>
              <div className="flex gap-1 items-center">
                <span className="text-xs font-black">{total}</span>
                {pendientes > 0 && (
                  <span className="w-4 h-4 rounded-full bg-orange-500 text-white text-xs font-black flex items-center justify-center leading-none">{pendientes}</span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Estadísticas de estado */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {(['abierto', 'en_revision', 'resuelto', 'cerrado'] as PQRSItem['estado'][]).map(e => {
          const cfg = ESTADO_CONFIG[e] ?? FALLBACK_ESTADO;
          const count = pqrs.filter(p => p.estado === e).length;
          return (
            <button
              key={e}
              onClick={() => setFiltroEstado(filtroEstado === e ? 'all' : e)}
              className={`flex items-center gap-3 p-4 rounded-xl border transition-all hover:scale-105 ${
                filtroEstado === e ? cfg.color : 'bg-zinc-900/60 border-zinc-800 text-gray-400 hover:border-zinc-700'
              }`}
            >
              <cfg.Icon className="w-5 h-5" />
              <div className="text-left">
                <p className="text-xl font-black text-white">{count}</p>
                <p className="text-xs">{cfg.label}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filtros */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Buscar por asunto, descripción o usuario..."
            value={busqueda}
            onChange={e => setBusqueda(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-zinc-900/60 border border-zinc-800 rounded-xl text-white placeholder-gray-600 text-sm focus:outline-none focus:border-purple-500/50 transition-all"
          />
        </div>
        <div className="flex items-center gap-2 text-gray-500 text-xs bg-zinc-900/40 px-3 py-2 rounded-xl border border-zinc-800">
          <Filter className="w-3.5 h-3.5" />
          {filtrado.length} resultado{filtrado.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* Lista de PQRS */}
      <div className="space-y-3">
        {filtrado.length === 0 ? (
          <div className="text-center py-16 bg-zinc-900/40 rounded-2xl border border-zinc-800">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-700" />
            <p className="text-gray-500">No hay PQRS que coincidan con los filtros</p>
          </div>
        ) : filtrado.map(item => {
          const modCfg = MODULO_CONFIG[item.modulo] ?? FALLBACK_MODULO;
          const estCfg = ESTADO_CONFIG[item.estado] ?? FALLBACK_ESTADO;
          const expanded = expandedId === item.id;
          return (
            <div key={item.id} className={`bg-zinc-900/70 border rounded-xl overflow-hidden transition-all ${
              item.estado === 'cerrado' ? 'border-zinc-800 opacity-70' : 'border-zinc-700 hover:border-zinc-600'
            }`}>
              {/* Banda de módulo */}
              <div className={`h-1 w-full ${
                item.modulo === 'administrativo' ? 'bg-red-500' :
                item.modulo === 'ventas' ? 'bg-blue-500' :
                item.modulo === 'inventario' ? 'bg-yellow-500' :
                item.modulo === 'productos' ? 'bg-orange-500' :
                item.modulo === 'pedidos' ? 'bg-purple-500' :
                item.modulo === 'tickets' ? 'bg-teal-500' : 'bg-gray-500'
              }`} />

              <div className="p-4">
                {/* Fila principal clickeable */}
                <div
                  className="flex items-start gap-3 cursor-pointer"
                  onClick={() => setExpandedId(expanded ? null : item.id)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      {/* Módulo */}
                      <span className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-bold border ${modCfg.color}`}>
                        <modCfg.Icon className="w-3.5 h-3.5" />
                        {modCfg.label}
                      </span>
                      {/* Tipo */}
                      <span className={`px-2 py-0.5 rounded-md text-xs font-bold border ${TIPO_COLOR[item.tipo]}`}>
                        {item.tipo.charAt(0).toUpperCase() + item.tipo.slice(1)}
                      </span>
                      {/* Estado */}
                      <span className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold border ${estCfg.color}`}>
                        <estCfg.Icon className="w-3.5 h-3.5" />
                        {estCfg.label}
                      </span>
                    </div>
                    <p className="text-white font-semibold text-sm">{item.asunto}</p>
                    <div className="flex items-center gap-1.5 mt-1 text-gray-600 text-xs">
                      <User className="w-3 h-3" />
                      <span>{item.usuario}</span>
                      <span>·</span>
                      <span>{new Date(item.fecha).toLocaleDateString('es-CO')}</span>
                    </div>
                  </div>
                  {expanded
                    ? <ChevronUp className="w-4 h-4 text-gray-500 flex-shrink-0 mt-1" />
                    : <ChevronDown className="w-4 h-4 text-gray-500 flex-shrink-0 mt-1" />
                  }
                </div>

                {/* Detalle expandido */}
                {expanded && (
                  <div className="mt-4 space-y-3 border-t border-zinc-800 pt-4">
                    <p className="text-gray-300 text-sm bg-zinc-800/40 rounded-xl p-3">{item.descripcion}</p>
                    <p className="text-gray-600 text-xs">Correo: {item.email}</p>

                    {item.respuesta && (
                      <div className="bg-green-500/8 border border-green-500/20 rounded-xl p-3">
                        <p className="text-green-400 text-xs font-bold mb-1">
                          Respuesta{item.respondidoPor ? ` por ${item.respondidoPor}` : ''}
                          {item.fechaRespuesta ? ` · ${new Date(item.fechaRespuesta).toLocaleDateString('es-CO')}` : ''}
                        </p>
                        <p className="text-gray-300 text-sm">{item.respuesta}</p>
                      </div>
                    )}

                    {canManage && item.estado !== 'cerrado' && (
                      <div className="space-y-3">
                        <div className="flex flex-wrap gap-1.5">
                          {(['abierto', 'en_revision', 'resuelto', 'cerrado'] as PQRSItem['estado'][]).map(e => (
                            <button
                              key={e}
                              onClick={() => cambiarEstado(item.id, e)}
                              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                                item.estado === e
                                  ? (ESTADO_CONFIG[e] ?? FALLBACK_ESTADO).color
                                  : 'bg-zinc-800 border-zinc-700 text-gray-400 hover:bg-zinc-700'
                              }`}
                            >
                              {React.createElement((ESTADO_CONFIG[e] ?? FALLBACK_ESTADO).Icon, { className: 'w-3.5 h-3.5' })}
                              {(ESTADO_CONFIG[e] ?? FALLBACK_ESTADO).label}
                            </button>
                          ))}
                        </div>
                        {!item.respuesta && (
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={respuestas[item.id] || ''}
                              onChange={e => setRespuestas(r => ({ ...r, [item.id]: e.target.value }))}
                              placeholder="Escribe una respuesta y pulsa Enter..."
                              className="flex-1 px-3 py-2 bg-zinc-800/60 border border-zinc-700 rounded-lg text-white text-sm placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all"
                              onKeyDown={e => { if (e.key === 'Enter') responder(item.id); }}
                            />
                            <button
                              onClick={() => responder(item.id)}
                              disabled={!respuestas[item.id]?.trim()}
                              className="flex items-center gap-1.5 px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg text-sm font-bold transition-all hover:scale-105"
                            >
                              <Send className="w-4 h-4" />
                              Responder
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal nueva PQRS */}
      {showModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900 border border-purple-500/40 rounded-2xl max-w-lg w-full p-6 shadow-2xl shadow-purple-500/10">
            <h3 className="text-white font-black text-xl mb-5 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-purple-400" />
              Nueva PQRS
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1.5">Tipo</label>
                  <select
                    value={formData.tipo}
                    onChange={e => setFormData(f => ({ ...f, tipo: e.target.value as PQRSItem['tipo'] }))}
                    className="w-full px-3 py-2.5 bg-zinc-800/60 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-purple-500/50 transition-all cursor-pointer"
                  >
                    <option value="peticion">Petición</option>
                    <option value="queja">Queja</option>
                    <option value="reclamo">Reclamo</option>
                    <option value="sugerencia">Sugerencia</option>
                  </select>
                </div>
                <div>
                  <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1.5">Dirigir a módulo</label>
                  <select
                    value={formData.modulo}
                    onChange={e => setFormData(f => ({ ...f, modulo: e.target.value as PQRSModulo }))}
                    className="w-full px-3 py-2.5 bg-zinc-800/60 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-purple-500/50 transition-all cursor-pointer"
                  >
                    {(Object.keys(MODULO_CONFIG) as PQRSModulo[]).map(m => (
                      <option key={m} value={m}>{MODULO_CONFIG[m].label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Vista previa del módulo seleccionado */}
              {(() => {
                const mc = MODULO_CONFIG[formData.modulo] ?? FALLBACK_MODULO;
                return (
                  <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-semibold ${mc.color}`}>
                    <mc.Icon className="w-4 h-4" />
                    Esta PQRS será visible y gestionada desde el módulo de <strong>{mc.label}</strong>
                  </div>
                );
              })()}

              <div>
                <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1.5">Asunto</label>
                <input
                  type="text"
                  value={formData.asunto}
                  onChange={e => setFormData(f => ({ ...f, asunto: e.target.value }))}
                  placeholder="Título breve de la solicitud"
                  required
                  className="w-full px-4 py-2.5 bg-zinc-800/60 border border-zinc-700 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all"
                />
              </div>
              <div>
                <label className="block text-purple-400 text-xs font-bold uppercase tracking-wide mb-1.5">Descripción</label>
                <textarea
                  value={formData.descripcion}
                  onChange={e => setFormData(f => ({ ...f, descripcion: e.target.value }))}
                  placeholder="Describe detalladamente tu solicitud..."
                  rows={4}
                  required
                  className="w-full px-4 py-2.5 bg-zinc-800/60 border border-zinc-700 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-purple-500/50 transition-all resize-none"
                />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all font-semibold text-sm">
                  Cancelar
                </button>
                <button type="submit" className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white rounded-xl transition-all hover:scale-105 font-black shadow-lg shadow-purple-500/20 text-sm">
                  <Send className="w-4 h-4" />
                  Enviar PQRS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
