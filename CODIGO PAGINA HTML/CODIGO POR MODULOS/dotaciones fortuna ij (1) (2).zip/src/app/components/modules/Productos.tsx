import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Search, Package, ShoppingCart, X, Check, Star, Ruler, Tag, Layers, AlertTriangle, ChevronRight, ZoomIn } from 'lucide-react';
import { useAuth } from '../AuthContext';
import { ImageWithFallback } from '../ImageWithFallback';
import { PQRSWidget } from './PQRSWidget';

// Foto específica por producto — Unsplash (w=600 para carga rápida)
const UNS = 'crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600';
const PRODUCT_IMAGES: Record<string, string> = {
  // Uniformes SENA
  '1':  `https://images.unsplash.com/photo-1621072156002-e2fccdc0b176?${UNS}`,  // admin camisa blanca
  '2':  `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // overol industrial naranja
  '3':  `https://images.unsplash.com/photo-1612363584451-cd060fb62018?${UNS}`,  // uniforme salud médico
  '4':  `https://images.unsplash.com/photo-1759521296013-559479e2a891?${UNS}`,  // chef blanco
  '5':  `https://images.unsplash.com/photo-1608908272009-5834650fb600?${UNS}`,  // polo gris sistemas
  '6':  `https://images.unsplash.com/photo-1605000797499-95a51c5269ae?${UNS}`,  // agropecuario campo
  '7':  `https://images.unsplash.com/photo-1610659695933-66bce236eda4?${UNS}`,  // uniforme belleza negro
  // Ropa Industrial
  '18': `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // chaleco naranja reflectivo
  '19': `https://images.unsplash.com/photo-1511947527012-6bb5876f488a?${UNS}`,  // chaleco/parka amarillo
  '20': `https://images.unsplash.com/photo-1624548140129-74786c5f1279?${UNS}`,  // overol azul
  '21': `https://images.unsplash.com/photo-1547069553-12f23c839aaa?${UNS}`,     // overol verde
  '22': `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // overol naranja
  '23': `https://images.unsplash.com/photo-1511947527012-6bb5876f488a?${UNS}`,  // parka amarilla impermeable
  '24': `https://images.unsplash.com/photo-1624548140129-74786c5f1279?${UNS}`,  // chaqueta azul marino
  '25': `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // conjunto reflectivo
  '26': `https://images.unsplash.com/photo-1466992133056-ae8de8e22809?${UNS}`,  // gorra roja
  '27': `https://images.unsplash.com/photo-1737438696465-516c17c5e0f8?${UNS}`,  // gorra verde/gris
  // Vestuario Casual
  '28': `https://images.unsplash.com/photo-1614214191247-5b2d3a734f1b?${UNS}`,  // buzo negro
  '29': `https://images.unsplash.com/photo-1547069553-12f23c839aaa?${UNS}`,     // buzo verde neón
  '30': `https://images.unsplash.com/photo-1564557287817-3785e38ec1f5?${UNS}`,  // buzo gris
  '31': `https://images.unsplash.com/photo-1759521296013-559479e2a891?${UNS}`,  // chaqueta chef blanca
  '32': `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // chaleco reflectivo
  '33': `https://images.unsplash.com/photo-1641377162508-aa0b0a6be927?${UNS}`,  // pantalón jean industrial
  '34': `https://images.unsplash.com/photo-1661784396787-2a43e31a5689?${UNS}`,  // pantalón negro trabajo
  // Calzado Seguridad
  '35': `https://images.unsplash.com/photo-1613325267798-05214c4d65f1?${UNS}`,  // botas negras punta acero
  '36': `https://images.unsplash.com/photo-1520639888713-7851133b1ed0?${UNS}`,  // botas café dieléctricas
  '37': `https://images.unsplash.com/photo-1709258228137-19a8c193be39?${UNS}`,  // zapatos blancos deportivos
  '38': `https://images.unsplash.com/photo-1774569036555-c3d233425a13?${UNS}`,  // botas grises
  '39': `https://images.unsplash.com/photo-1709258228137-19a8c193be39?${UNS}`,  // zapatos seguridad deportivos
  '40': `https://images.unsplash.com/photo-1520639888713-7851133b1ed0?${UNS}`,  // botas café oscuro
  // Seguridad y EPP
  '8':  `https://images.unsplash.com/photo-1613325267798-05214c4d65f1?${UNS}`,  // botas punta acero
  '9':  `https://images.unsplash.com/photo-1768158988512-ad31657fe5b8?${UNS}`,  // casco amarillo
  '10': `https://images.unsplash.com/photo-1681812508281-7589b75b2e46?${UNS}`,  // chaleco reflectivo básico
  '11': `https://images.unsplash.com/photo-1634852836003-c0aa5b67d243?${UNS}`,  // guantes amarillos
  '12': `https://images.unsplash.com/photo-1593854519602-687eae339d57?${UNS}`,  // gafas protección
  '13': `https://images.unsplash.com/photo-1709258228137-19a8c193be39?${UNS}`,  // zapatos antideslizantes
  '14': `https://images.unsplash.com/photo-1614290501125-d72aeb735c10?${UNS}`,  // tapabocas quirúrgico
  '15': `https://images.unsplash.com/photo-1608908272009-5834650fb600?${UNS}`,  // camisa polo corporativa
  '16': `https://images.unsplash.com/photo-1661784396787-2a43e31a5689?${UNS}`,  // pantalón trabajo básico
  '17': `https://images.unsplash.com/photo-1760383934256-a154111d701c?${UNS}`,  // arnés seguridad alturas
  '41': `https://images.unsplash.com/photo-1781157080615-ffde66c035a5?${UNS}`,  // casco con visor
  '42': `https://images.unsplash.com/photo-1624548140129-74786c5f1279?${UNS}`,  // overol azul protección
  '43': `https://images.unsplash.com/photo-1673294861057-4584f92b91d2?${UNS}`,  // tapones auditivos (gloves)
  '44': `https://images.unsplash.com/photo-1593854519602-687eae339d57?${UNS}`,  // audífonos protección
  '45': `https://images.unsplash.com/photo-1712842955521-55c8c01ef148?${UNS}`,  // pañal geriátrico médico
};

interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;
  categoria: string;
  imagen: string;
  imagenUrl?: string;
  stock?: number;
  stockMinimo?: number;
}

export const Productos: React.FC = () => {
  const { user } = useAuth();
  const [productos, setProductos] = useState<Producto[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>('todas');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Producto | null>(null);
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    precio: '',
    categoria: '',
    imagen: '',
    stock: '',
    stockMinimo: ''
  });

  const canEdit = user?.role === 'gerente_general' || user?.role === 'admin_inventario' || user?.role === 'subgerente';
  const canBuy  = user?.role === 'cliente' || user?.role === 'gerente_general' || user?.role === 'subgerente';

  const [detalleProducto, setDetalleProducto] = useState<Producto | null>(null);
  const [cantidadDetalle, setCantidadDetalle] = useState(1);
  const [addedToCart, setAddedToCart] = useState<string | null>(null);

  const agregarAlCarrito = (producto: Producto, cantidad = 1) => {
    const carrito: any[] = JSON.parse(localStorage.getItem('carrito') || '[]');
    const existe = carrito.find((i: any) => i.producto.id === producto.id);
    if (existe) {
      existe.cantidad += cantidad;
      localStorage.setItem('carrito', JSON.stringify(carrito));
    } else {
      carrito.push({ producto, cantidad });
      localStorage.setItem('carrito', JSON.stringify(carrito));
    }
    setAddedToCart(producto.id);
    setTimeout(() => setAddedToCart(null), 2000);
  };

  // Datos extra enriquecidos por categoría
  const getDetallesExtra = (producto: Producto) => {
    const cat = producto.categoria;
    const tallas = cat.includes('Calzado') || cat.includes('Seguridad') && producto.nombre.toLowerCase().includes('bota')
      ? ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45']
      : cat.includes('Calzado')
      ? ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45']
      : ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

    const materialMap: Record<string, string> = {
      'Uniformes SENA':  'Poliéster 65% / Algodón 35% — resistente y transpirable',
      'Ropa Industrial': 'Drill 100% algodón — alta resistencia a la abrasión',
      'Vestuario Casual':'Algodón 80% / Poliéster 20% — suave y duradero',
      'Calzado Seguridad':'Cuero genuino con puntera de acero — norma ICONTEC',
      'Seguridad':       'Materiales técnicos certificados bajo normas ISO y NTC',
    };

    const caracteristicasMap: Record<string, string[]> = {
      'Uniformes SENA':  ['Costuras reforzadas de doble pespunte', 'Colores resistentes al lavado industrial', 'Diseño ergonómico', 'Cumple estándares SENA'],
      'Ropa Industrial': ['Cintas reflectivas certificadas 3M', 'Costuras de seguridad triple', 'Resistente a líquidos industriales', 'Tela ignífuga disponible'],
      'Vestuario Casual':['Fácil mantenimiento', 'Secado rápido', 'Tejido anti-arrugas', 'Diseño corporativo'],
      'Calzado Seguridad':['Puntera de acero 200J', 'Suela antideslizante', 'Plantilla antibacterial removible', 'Certificado NTC 1741'],
      'Seguridad':       ['Certificación ISO 9001', 'Cumple normativa ICONTEC', 'Alta visibilidad', 'Resistencia probada en campo'],
    };

    return {
      tallas,
      material: materialMap[cat] || 'Material de alta calidad, especificaciones según etiqueta del producto',
      caracteristicas: caracteristicasMap[cat] || ['Alta durabilidad', 'Diseño funcional', 'Control de calidad certificado'],
      cuidados: ['Lavar a máquina máx. 40°C', 'No usar blanqueador', 'Planchar a temperatura media', 'No lavar en seco'],
      origen: 'Colombia — Fabricación nacional',
      garantia: '3 meses por defectos de fabricación',
    };
  };

  useEffect(() => {
    // Precios reales 2024-2025 por ID
    const REAL_PRICES: Record<string, number> = {
      '1':89000,'2':112000,'3':95000,'4':118000,'5':48000,'6':145000,'7':92000,
      '18':28000,'19':32000,'20':85000,'21':85000,'22':92000,'23':75000,'24':82000,
      '25':120000,'26':18000,'27':18000,'28':58000,'29':62000,'30':58000,'31':72000,
      '32':38000,'33':72000,'34':65000,'35':128000,'36':198000,'37':115000,'38':142000,
      '39':128000,'40':152000,'8':128000,'9':28000,'10':22000,'11':15000,'12':12000,
      '13':82000,'14':15000,'15':55000,'16':65000,'17':185000,'41':58000,'42':108000,
      '43':9500,'44':58000,'45':28000,
    };

    const stored = localStorage.getItem('productos');
    if (stored) {
      // Migrar: aplicar fotos específicas Y precios reales a instalaciones existentes
      const parsed = JSON.parse(stored);
      const migrated = parsed.map((p: Producto) => ({
        ...p,
        ...(PRODUCT_IMAGES[p.id] ? { imagenUrl: PRODUCT_IMAGES[p.id] } : {}),
        ...(REAL_PRICES[p.id]    ? { precio: REAL_PRICES[p.id] }        : {}),
      }));
      setProductos(migrated);
      localStorage.setItem('productos', JSON.stringify(migrated));
      return;
    } else {
      // Precios ajustados al mercado colombiano real 2024-2025
      // Fuentes de referencia: Mercado Libre CO, distribuidores de dotaciones, EPP Colombia
      const initial: Producto[] = [
        // Uniformes SENA — rango real $68.000 – $145.000 por conjunto
        { id: '1', nombre: 'Uniforme Administrativo SENA', descripcion: 'Camisa blanca y pantalón negro - Línea administrativa', precio: 89000, categoria: 'Uniformes SENA', imagen: '👔', stock: 50, stockMinimo: 10 },
        { id: '2', nombre: 'Uniforme Industrial SENA', descripcion: 'Overol azul con cintas reflectivas de seguridad', precio: 112000, categoria: 'Uniformes SENA', imagen: '👷', stock: 35, stockMinimo: 10 },
        { id: '3', nombre: 'Uniforme Salud SENA', descripcion: 'Uniforme clínico blanco completo', precio: 95000, categoria: 'Uniformes SENA', imagen: '⚕️', stock: 40, stockMinimo: 15 },
        { id: '4', nombre: 'Uniforme Gastronomía SENA', descripcion: 'Chaqueta de chef blanca con pantalón negro', precio: 118000, categoria: 'Uniformes SENA', imagen: '👨‍🍳', stock: 30, stockMinimo: 10 },
        { id: '5', nombre: 'Uniforme Sistemas SENA', descripcion: 'Camiseta tipo polo gris', precio: 48000, categoria: 'Uniformes SENA', imagen: '💻', stock: 60, stockMinimo: 15 },
        { id: '6', nombre: 'Uniforme Agropecuario SENA', descripcion: 'Uniforme café con botas de caucho incluidas', precio: 145000, categoria: 'Uniformes SENA', imagen: '🌾', stock: 25, stockMinimo: 8 },
        { id: '7', nombre: 'Uniforme Belleza SENA', descripcion: 'Uniforme negro completo', precio: 92000, categoria: 'Uniformes SENA', imagen: '💇', stock: 45, stockMinimo: 12 },

        // Ropa Industrial — chalecos $18.000-$45.000 · overoles $65.000-$120.000
        { id: '18', nombre: 'Chaleco Alta Visibilidad Naranja', descripcion: 'Chaleco reflectivo con bandas plateadas, certificado', precio: 28000, categoria: 'Ropa Industrial', imagen: '🦺', stock: 120, stockMinimo: 25 },
        { id: '19', nombre: 'Chaleco Alta Visibilidad Amarillo', descripcion: 'Chaleco reflectivo amarillo con cintas 3M', precio: 32000, categoria: 'Ropa Industrial', imagen: '🦺', stock: 110, stockMinimo: 25 },
        { id: '20', nombre: 'Overol Industrial Azul', descripcion: 'Overol completo azul oscuro de drill', precio: 85000, categoria: 'Ropa Industrial', imagen: '👷', stock: 45, stockMinimo: 10 },
        { id: '21', nombre: 'Overol Industrial Verde', descripcion: 'Overol verde oliva resistente', precio: 85000, categoria: 'Ropa Industrial', imagen: '👷', stock: 40, stockMinimo: 10 },
        { id: '22', nombre: 'Overol Industrial Naranja', descripcion: 'Overol naranja alta visibilidad', precio: 92000, categoria: 'Ropa Industrial', imagen: '👷', stock: 35, stockMinimo: 10 },
        { id: '23', nombre: 'Parka Impermeable Amarilla', descripcion: 'Chaqueta impermeable con capucha y reflectivos', precio: 75000, categoria: 'Ropa Industrial', imagen: '🧥', stock: 30, stockMinimo: 8 },
        { id: '24', nombre: 'Chaqueta Impermeable Azul Marino', descripcion: 'Chaqueta industrial impermeable con forro', precio: 82000, categoria: 'Ropa Industrial', imagen: '🧥', stock: 28, stockMinimo: 8 },
        { id: '25', nombre: 'Conjunto Reflectivo Amarillo', descripcion: 'Chaqueta y pantalón impermeable reflectivo', precio: 120000, categoria: 'Ropa Industrial', imagen: '🦺', stock: 20, stockMinimo: 5 },
        { id: '26', nombre: 'Gorra Industrial Roja', descripcion: 'Gorra ajustable de algodón', precio: 18000, categoria: 'Ropa Industrial', imagen: '🧢', stock: 80, stockMinimo: 20 },
        { id: '27', nombre: 'Gorra Industrial Verde', descripcion: 'Gorra ajustable resistente', precio: 18000, categoria: 'Ropa Industrial', imagen: '🧢', stock: 75, stockMinimo: 20 },

        // Vestuario Casual — buzos $42.000-$72.000 · pantalones $55.000-$75.000
        { id: '28', nombre: 'Buzo Negro', descripcion: 'Sudadera con capucha de algodón', precio: 58000, categoria: 'Vestuario Casual', imagen: '👕', stock: 60, stockMinimo: 15 },
        { id: '29', nombre: 'Buzo Verde Neón', descripcion: 'Sudadera alta visibilidad con capucha', precio: 62000, categoria: 'Vestuario Casual', imagen: '👕', stock: 50, stockMinimo: 12 },
        { id: '30', nombre: 'Buzo Gris', descripcion: 'Sudadera gris con capucha y bolsillos', precio: 58000, categoria: 'Vestuario Casual', imagen: '👕', stock: 55, stockMinimo: 15 },
        { id: '31', nombre: 'Chaqueta Chef Blanca', descripcion: 'Chaqueta de chef manga larga', precio: 72000, categoria: 'Vestuario Casual', imagen: '👨‍🍳', stock: 35, stockMinimo: 10 },
        { id: '32', nombre: 'Chaleco Reflectivo Industrial', descripcion: 'Chaleco naranja con múltiples bolsillos', precio: 38000, categoria: 'Vestuario Casual', imagen: '🦺', stock: 70, stockMinimo: 18 },
        { id: '33', nombre: 'Pantalón Jean Industrial', descripcion: 'Pantalón jean azul reforzado', precio: 72000, categoria: 'Vestuario Casual', imagen: '👖', stock: 65, stockMinimo: 15 },
        { id: '34', nombre: 'Pantalón Negro de Trabajo', descripcion: 'Pantalón negro multibolsillos', precio: 65000, categoria: 'Vestuario Casual', imagen: '👖', stock: 70, stockMinimo: 15 },

        // Calzado Seguridad — botas $95.000-$198.000 · zapatos $85.000-$145.000
        { id: '35', nombre: 'Botas Industriales Negras', descripcion: 'Botas de seguridad punta de acero negras', precio: 128000, categoria: 'Calzado Seguridad', imagen: '🥾', stock: 40, stockMinimo: 10 },
        { id: '36', nombre: 'Botas Dieléctricas Café', descripcion: 'Botas dieléctricas café para electricistas', precio: 198000, categoria: 'Calzado Seguridad', imagen: '🥾', stock: 35, stockMinimo: 8 },
        { id: '37', nombre: 'Zapatos Seguridad Blancos', descripcion: 'Zapatos de seguridad blancos tipo deportivo', precio: 115000, categoria: 'Calzado Seguridad', imagen: '👟', stock: 45, stockMinimo: 12 },
        { id: '38', nombre: 'Botas Seguridad Grises', descripcion: 'Botas industriales grises antideslizantes', precio: 142000, categoria: 'Calzado Seguridad', imagen: '🥾', stock: 38, stockMinimo: 10 },
        { id: '39', nombre: 'Zapatos Seguridad Deportivos', descripcion: 'Zapatos de seguridad estilo deportivo negro/gris', precio: 128000, categoria: 'Calzado Seguridad', imagen: '👟', stock: 50, stockMinimo: 12 },
        { id: '40', nombre: 'Botas Seguridad Café Oscuro', descripcion: 'Botas industriales café con suela antideslizante', precio: 152000, categoria: 'Calzado Seguridad', imagen: '🥾', stock: 32, stockMinimo: 8 },

        // Seguridad y EPP — precios reales colombianos
        { id: '8',  nombre: 'Botas de Seguridad Punta Acero', descripcion: 'Botas negras con punta de acero reforzada', precio: 128000, categoria: 'Seguridad', imagen: '🥾', stock: 45, stockMinimo: 10 },
        { id: '9',  nombre: 'Casco Industrial Amarillo', descripcion: 'Casco protector amarillo certificado ISO', precio: 28000, categoria: 'Seguridad', imagen: '⛑️', stock: 80, stockMinimo: 15 },
        { id: '10', nombre: 'Chaleco Reflectivo Básico', descripcion: 'Chaleco alta visibilidad con cintas reflectivas', precio: 22000, categoria: 'Seguridad', imagen: '🦺', stock: 100, stockMinimo: 20 },
        { id: '11', nombre: 'Guantes de Seguridad Amarillos', descripcion: 'Guantes industriales de cuero reforzado', precio: 15000, categoria: 'Seguridad', imagen: '🧤', stock: 150, stockMinimo: 30 },
        { id: '12', nombre: 'Gafas de Protección', descripcion: 'Gafas anti-impacto con protección UV', precio: 12000, categoria: 'Seguridad', imagen: '🥽', stock: 90, stockMinimo: 20 },
        { id: '13', nombre: 'Zapatos Antideslizantes', descripcion: 'Calzado con suela antideslizante', precio: 82000, categoria: 'Seguridad', imagen: '👟', stock: 60, stockMinimo: 15 },
        { id: '14', nombre: 'Tapabocas Quirúrgico', descripcion: 'Caja x50 mascarillas desechables 3 capas', precio: 15000, categoria: 'Seguridad', imagen: '😷', stock: 800, stockMinimo: 150 },
        { id: '15', nombre: 'Camisa Polo Corporativa', descripcion: 'Polo corporativo con logo bordado', precio: 55000, categoria: 'Seguridad', imagen: '👕', stock: 75, stockMinimo: 15 },
        { id: '16', nombre: 'Pantalón de Trabajo Básico', descripcion: 'Pantalón resistente multibolsillos', precio: 65000, categoria: 'Seguridad', imagen: '👖', stock: 65, stockMinimo: 15 },
        { id: '17', nombre: 'Arnés de Seguridad', descripcion: 'Arnés completo para trabajo en alturas', precio: 185000, categoria: 'Seguridad', imagen: '🪢', stock: 25, stockMinimo: 5 },
        { id: '41', nombre: 'Casco con Visor Amarillo', descripcion: 'Casco industrial con visor de protección facial', precio: 58000, categoria: 'Seguridad', imagen: '⛑️', stock: 40, stockMinimo: 10 },
        { id: '42', nombre: 'Overol Protección Azul Oscuro', descripcion: 'Overol completo de protección industrial', precio: 108000, categoria: 'Seguridad', imagen: '👷', stock: 35, stockMinimo: 8 },
        { id: '43', nombre: 'Tapones Auditivos Naranja', descripcion: 'Caja x50 pares, tapones espuma alta densidad con cordón', precio: 9500, categoria: 'Seguridad', imagen: '🔌', stock: 300, stockMinimo: 60 },
        { id: '44', nombre: 'Audífonos de Protección', descripcion: 'Protectores auditivos tipo copa profesionales NRR 25dB', precio: 58000, categoria: 'Seguridad', imagen: '🎧', stock: 55, stockMinimo: 12 },
        { id: '45', nombre: 'Pañal Adulto Geriátrico', descripcion: 'Pañal desechable uso médico/geriátrico, bolsa x10 und', precio: 28000, categoria: 'Seguridad', imagen: '🩹', stock: 200, stockMinimo: 40 },
      ];
      // Asignar foto específica por producto
      const withPhotos = initial.map(p => ({
        ...p,
        imagenUrl: PRODUCT_IMAGES[p.id] ?? undefined,
      }));
      setProductos(withPhotos);
      localStorage.setItem('productos', JSON.stringify(withPhotos));

      // También sincronizar con inventario
      const inventarioInicial = initial.map(p => ({
        productoId: p.id,
        nombre: p.nombre,
        stock: p.stock || 0,
        stockMinimo: p.stockMinimo || 10,
        imagen: p.imagen
      }));
      localStorage.setItem('inventario', JSON.stringify(inventarioInicial));
    }
  }, []);

  const saveProductos = (newProductos: Producto[]) => {
    setProductos(newProductos);
    localStorage.setItem('productos', JSON.stringify(newProductos));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const producto: Producto = {
      id: editingProduct?.id || Date.now().toString(),
      nombre: formData.nombre,
      descripcion: formData.descripcion,
      precio: parseFloat(formData.precio),
      categoria: formData.categoria,
      imagen: formData.imagen || '📦',
      imagenUrl: editingProduct?.imagenUrl,
      stock: parseInt(formData.stock) || 0,
      stockMinimo: parseInt(formData.stockMinimo) || 10
    };

    let nuevosProductos;
    if (editingProduct) {
      nuevosProductos = productos.map(p => p.id === producto.id ? producto : p);
    } else {
      nuevosProductos = [...productos, producto];
    }

    saveProductos(nuevosProductos);

    // Sincronizar con inventario
    const inventario = JSON.parse(localStorage.getItem('inventario') || '[]');
    const inventarioActualizado = editingProduct
      ? inventario.map((item: any) =>
          item.productoId === producto.id
            ? { ...item, nombre: producto.nombre, stock: producto.stock, stockMinimo: producto.stockMinimo, imagen: producto.imagen }
            : item
        )
      : [...inventario, {
          productoId: producto.id,
          nombre: producto.nombre,
          stock: producto.stock || 0,
          stockMinimo: producto.stockMinimo || 10,
          imagen: producto.imagen
        }];
    localStorage.setItem('inventario', JSON.stringify(inventarioActualizado));

    setFormData({ nombre: '', descripcion: '', precio: '', categoria: '', imagen: '', stock: '', stockMinimo: '' });
    setEditingProduct(null);
    setShowModal(false);
  };

  const handleEdit = (producto: Producto) => {
    setEditingProduct(producto);
    setFormData({
      nombre: producto.nombre,
      descripcion: producto.descripcion,
      precio: producto.precio.toString(),
      categoria: producto.categoria,
      imagen: producto.imagen,
      stock: producto.stock?.toString() || '0',
      stockMinimo: producto.stockMinimo?.toString() || '10'
    });
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('¿Estás seguro de eliminar este producto?')) {
      saveProductos(productos.filter(p => p.id !== id));

      // También eliminar del inventario
      const inventario = JSON.parse(localStorage.getItem('inventario') || '[]');
      const inventarioActualizado = inventario.filter((item: any) => item.productoId !== id);
      localStorage.setItem('inventario', JSON.stringify(inventarioActualizado));
    }
  };

  const categorias = ['todas', ...Array.from(new Set(productos.map(p => p.categoria)))];

  const filteredProductos = productos.filter(p => {
    const matchSearch = p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        p.categoria.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategoria = categoriaFiltro === 'todas' || p.categoria === categoriaFiltro;
    return matchSearch && matchCategoria;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex-1 w-full md:max-w-md space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar productos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-zinc-900/80 backdrop-blur border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {categorias.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoriaFiltro(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  categoriaFiltro === cat
                    ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/30'
                    : 'bg-zinc-800 text-gray-400 hover:bg-zinc-700'
                }`}
              >
                {cat === 'todas' ? 'Todas' : cat}
              </button>
            ))}
          </div>
        </div>

        {canEdit && (
          <button
            onClick={() => {
              setEditingProduct(null);
              setFormData({ nombre: '', descripcion: '', precio: '', categoria: '', imagen: '', stock: '0', stockMinimo: '10' });
              setShowModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black px-6 py-3 rounded-xl transition-all font-semibold shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            Nuevo Producto
          </button>
        )}
      </div>

      {/* Contador de resultados */}
      <div className="flex items-center justify-between">
        <p className="text-gray-400">
          Mostrando <span className="text-yellow-500 font-semibold">{filteredProductos.length}</span> de {productos.length} productos
        </p>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filteredProductos.map((producto) => {
          const sinStock = (producto.stock || 0) === 0;
          const bajoStock = !sinStock && (producto.stock || 0) <= (producto.stockMinimo || 10);
          const added = addedToCart === producto.id;
          return (
            <div
              key={producto.id}
              className="group bg-zinc-900/80 backdrop-blur border border-zinc-800 hover:border-yellow-500/60 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-yellow-500/10 flex flex-col"
            >
              {/* Imagen */}
              <div
                className="relative h-44 bg-gradient-to-br from-zinc-800 to-zinc-900 overflow-hidden cursor-pointer"
                onClick={() => { setDetalleProducto(producto); setCantidadDetalle(1); }}
              >
                {producto.imagenUrl ? (
                  <ImageWithFallback
                    src={producto.imagenUrl}
                    alt={producto.nombre}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <span className="absolute inset-0 flex items-center justify-center text-6xl group-hover:scale-110 transition-transform">{producto.imagen}</span>
                )}
                {/* Overlay ver detalle */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-3 py-1.5 flex items-center gap-1.5 text-white text-xs font-bold">
                    <ZoomIn className="w-3.5 h-3.5" />
                    Ver detalle
                  </div>
                </div>
                {/* Badge stock */}
                {sinStock && (
                  <span className="absolute top-2 left-2 bg-red-500/90 text-white text-xs font-bold px-2 py-0.5 rounded-lg">Sin stock</span>
                )}
                {bajoStock && (
                  <span className="absolute top-2 left-2 bg-orange-500/90 text-white text-xs font-bold px-2 py-0.5 rounded-lg">Últimas unidades</span>
                )}
                {/* Badge categoría */}
                <span className="absolute top-2 right-2 bg-black/50 backdrop-blur text-yellow-400 text-xs font-semibold px-2 py-0.5 rounded-lg border border-yellow-500/20">
                  {producto.categoria}
                </span>
              </div>

              {/* Info */}
              <div className="p-4 flex flex-col flex-1">
                <h3
                  className="text-white font-bold text-sm leading-tight mb-1 cursor-pointer hover:text-yellow-400 transition-colors line-clamp-2"
                  onClick={() => { setDetalleProducto(producto); setCantidadDetalle(1); }}
                >
                  {producto.nombre}
                </h3>
                <p className="text-gray-500 text-xs mb-3 line-clamp-2 flex-1">{producto.descripcion}</p>

                <div className="flex items-center justify-between mb-3">
                  <span className="text-yellow-500 text-xl font-black">${producto.precio.toLocaleString('es-CO')}</span>
                  {canEdit && (
                    <span className={`text-xs font-semibold ${sinStock ? 'text-red-400' : bajoStock ? 'text-orange-400' : 'text-green-400'}`}>
                      {producto.stock || 0} uds.
                    </span>
                  )}
                </div>

                {/* Acciones */}
                <div className="flex gap-2">
                  <button
                    onClick={() => { setDetalleProducto(producto); setCantidadDetalle(1); }}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-yellow-500/40 text-gray-300 hover:text-white px-3 py-2 rounded-xl transition-all text-xs font-semibold"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                    Ver más
                  </button>
                  {canBuy && (
                    <button
                      onClick={() => agregarAlCarrito(producto)}
                      disabled={sinStock}
                      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl transition-all text-xs font-bold ${
                        added
                          ? 'bg-green-500 text-white shadow-lg shadow-green-500/30'
                          : sinStock
                          ? 'bg-zinc-800 text-gray-600 cursor-not-allowed'
                          : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black shadow-lg shadow-yellow-500/20 hover:scale-105'
                      }`}
                    >
                      {added ? <><Check className="w-3.5 h-3.5" />Agregado</> : <><ShoppingCart className="w-3.5 h-3.5" />Añadir</>}
                    </button>
                  )}
                  {canEdit && (
                    <>
                      <button onClick={() => handleEdit(producto)} className="p-2 bg-zinc-800 hover:bg-zinc-700 text-yellow-500 rounded-xl transition-all hover:scale-105">
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleDelete(producto.id)} className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all hover:scale-105">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── MODAL DETALLE PRODUCTO ── */}
      {detalleProducto && (() => {
        const p = detalleProducto;
        const extra = getDetallesExtra(p);
        const sinStock = (p.stock || 0) === 0;
        const added = addedToCart === p.id;
        return (
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in"
            onClick={e => { if (e.target === e.currentTarget) setDetalleProducto(null); }}
          >
            <div className="bg-zinc-900 border border-zinc-700 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl shadow-black/50">
              {/* Header imagen */}
              <div className="relative h-64 sm:h-80 bg-gradient-to-br from-zinc-800 to-zinc-900 rounded-t-2xl overflow-hidden">
                {p.imagenUrl ? (
                  <ImageWithFallback src={p.imagenUrl} alt={p.nombre} className="w-full h-full object-cover" />
                ) : (
                  <span className="absolute inset-0 flex items-center justify-center text-8xl">{p.imagen}</span>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
                {/* Cerrar */}
                <button
                  onClick={() => setDetalleProducto(null)}
                  className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 backdrop-blur text-white p-2 rounded-xl transition-all hover:scale-110"
                >
                  <X className="w-5 h-5" />
                </button>
                {/* Badge categoría */}
                <span className="absolute top-4 left-4 bg-yellow-500/90 text-black text-xs font-black px-3 py-1 rounded-lg">
                  {p.categoria}
                </span>
                {/* Precio flotante */}
                <div className="absolute bottom-4 left-5">
                  <p className="text-yellow-400 text-3xl font-black">${p.precio.toLocaleString('es-CO')}</p>
                  <p className="text-gray-400 text-xs">COP · Precio unitario</p>
                </div>
              </div>

              {/* Contenido */}
              <div className="p-6 space-y-6">
                {/* Nombre y descripción */}
                <div>
                  <h2 className="text-2xl text-white font-black mb-2">{p.nombre}</h2>
                  <p className="text-gray-400 leading-relaxed">{p.descripcion}</p>
                </div>

                {/* Tallas disponibles */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Ruler className="w-4 h-4 text-yellow-500" />
                    <h4 className="text-white font-bold text-sm">Tallas disponibles</h4>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {extra.tallas.map(t => (
                      <span key={t} className="px-3 py-1.5 bg-zinc-800 border border-zinc-700 hover:border-yellow-500/50 text-gray-300 rounded-lg text-xs font-semibold cursor-default transition-colors">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Material */}
                  <div className="bg-zinc-800/50 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Layers className="w-4 h-4 text-blue-400" />
                      <h4 className="text-white font-bold text-sm">Material</h4>
                    </div>
                    <p className="text-gray-400 text-sm leading-relaxed">{extra.material}</p>
                  </div>

                  {/* Garantía y origen */}
                  <div className="bg-zinc-800/50 rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 mb-2">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <h4 className="text-white font-bold text-sm">Información</h4>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Origen</span>
                      <span className="text-gray-300 font-medium">{extra.origen}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Garantía</span>
                      <span className="text-gray-300 font-medium">{extra.garantia}</span>
                    </div>
                    {canEdit && (
                      <div className="flex justify-between text-xs pt-1 border-t border-zinc-700">
                        <span className="text-gray-500">Stock disponible</span>
                        <span className={`font-bold ${sinStock ? 'text-red-400' : (p.stock || 0) <= (p.stockMinimo || 10) ? 'text-orange-400' : 'text-green-400'}`}>
                          {p.stock || 0} unidades
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Características */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Tag className="w-4 h-4 text-green-400" />
                    <h4 className="text-white font-bold text-sm">Características principales</h4>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {extra.caracteristicas.map((c, i) => (
                      <div key={i} className="flex items-start gap-2 bg-zinc-800/40 rounded-lg px-3 py-2">
                        <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300 text-xs">{c}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cuidados */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-4 h-4 text-orange-400" />
                    <h4 className="text-white font-bold text-sm">Instrucciones de cuidado</h4>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {extra.cuidados.map((c, i) => (
                      <span key={i} className="bg-orange-500/10 border border-orange-500/20 text-orange-300 text-xs px-3 py-1 rounded-lg">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Añadir al carrito */}
                {canBuy && (
                  <div className="border-t border-zinc-800 pt-5 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                    <div className="flex items-center gap-1 bg-zinc-800 border border-zinc-700 rounded-xl p-1">
                      <button
                        onClick={() => setCantidadDetalle(q => Math.max(1, q - 1))}
                        className="w-9 h-9 flex items-center justify-center bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg transition-all font-bold text-lg"
                      >−</button>
                      <span className="w-10 text-center text-white font-black">{cantidadDetalle}</span>
                      <button
                        onClick={() => setCantidadDetalle(q => Math.min(p.stock || 99, q + 1))}
                        disabled={sinStock}
                        className="w-9 h-9 flex items-center justify-center bg-zinc-700 hover:bg-zinc-600 disabled:opacity-30 text-white rounded-lg transition-all font-bold text-lg"
                      >+</button>
                    </div>
                    <div className="flex-1 flex items-center justify-between bg-zinc-800/50 rounded-xl px-4 py-2.5">
                      <span className="text-gray-400 text-sm">Subtotal</span>
                      <span className="text-yellow-400 font-black text-lg">${(p.precio * cantidadDetalle).toLocaleString('es-CO')}</span>
                    </div>
                    <button
                      onClick={() => { agregarAlCarrito(p, cantidadDetalle); }}
                      disabled={sinStock}
                      className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-black text-sm transition-all ${
                        added
                          ? 'bg-green-500 text-white shadow-lg shadow-green-500/30'
                          : sinStock
                          ? 'bg-zinc-800 text-gray-600 cursor-not-allowed'
                          : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black shadow-lg shadow-yellow-500/30 hover:scale-105'
                      }`}
                    >
                      {added
                        ? <><Check className="w-4 h-4" />¡Agregado!</>
                        : sinStock
                        ? 'Sin stock'
                        : <><ShoppingCart className="w-4 h-4" />Añadir al carrito</>
                      }
                    </button>
                  </div>
                )}

                {/* Botones editar/eliminar para admins */}
                {canEdit && (
                  <div className="flex gap-3 pt-2 border-t border-zinc-800">
                    <button
                      onClick={() => { handleEdit(p); setDetalleProducto(null); }}
                      className="flex-1 flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-yellow-400 px-4 py-2.5 rounded-xl transition-all font-semibold text-sm"
                    >
                      <Edit className="w-4 h-4" />
                      Editar producto
                    </button>
                    <button
                      onClick={() => { handleDelete(p.id); setDetalleProducto(null); }}
                      className="flex items-center justify-center gap-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 px-4 py-2.5 rounded-xl transition-all text-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                      Eliminar
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-zinc-900/95 backdrop-blur border border-yellow-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl shadow-yellow-500/20">
            <h3 className="text-3xl text-white mb-6 bg-gradient-to-r from-white to-yellow-500 bg-clip-text text-transparent font-bold">
              {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-yellow-500 mb-2 font-semibold">Nombre</label>
                <input
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                  className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                  placeholder="Ej: Uniforme Empresarial"
                  required
                />
              </div>

              <div>
                <label className="block text-yellow-500 mb-2 font-semibold">Descripción</label>
                <textarea
                  value={formData.descripcion}
                  onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                  className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                  placeholder="Descripción detallada del producto"
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-yellow-500 mb-2 font-semibold">Precio</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.precio}
                    onChange={(e) => setFormData({ ...formData, precio: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                    placeholder="0.00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-yellow-500 mb-2 font-semibold">Categoría</label>
                  <input
                    type="text"
                    value={formData.categoria}
                    onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                    placeholder="Vestuario"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-yellow-500 mb-2 font-semibold">Icono</label>
                  <input
                    type="text"
                    value={formData.imagen}
                    onChange={(e) => setFormData({ ...formData, imagen: e.target.value })}
                    placeholder="📦"
                    className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all text-center text-2xl"
                  />
                </div>

                <div>
                  <label className="block text-yellow-500 mb-2 font-semibold">Stock</label>
                  <input
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                    placeholder="0"
                  />
                </div>

                <div>
                  <label className="block text-yellow-500 mb-2 font-semibold">Mínimo</label>
                  <input
                    type="number"
                    value={formData.stockMinimo}
                    onChange={(e) => setFormData({ ...formData, stockMinimo: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800/50 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all"
                    placeholder="10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-yellow-500 mb-2">Stock Inicial</label>
                  <input
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded text-white focus:outline-none focus:border-yellow-500"
                    required
                    min="0"
                  />
                </div>

                <div>
                  <label className="block text-yellow-500 mb-2">Stock Mínimo</label>
                  <input
                    type="number"
                    value={formData.stockMinimo}
                    onChange={(e) => setFormData({ ...formData, stockMinimo: e.target.value })}
                    className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded text-white focus:outline-none focus:border-yellow-500"
                    required
                    min="0"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingProduct(null);
                  }}
                  className="flex-1 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg transition-all hover:scale-105 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black rounded-lg transition-all hover:scale-105 font-semibold shadow-lg shadow-yellow-500/30"
                >
                  {editingProduct ? 'Actualizar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <PQRSWidget modulo="productos" titulo="PQRS — Productos" />
    </div>
  );
};
