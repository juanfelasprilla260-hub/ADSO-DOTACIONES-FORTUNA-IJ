import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router';
import { useAuth } from './AuthContext';
import { LogOut, Package, ShoppingCart, Warehouse, Receipt, Menu, X, Home, ArrowLeft, ArrowRight, ShoppingBag, MessageSquare, BookOpen, Shield, GraduationCap, HardHat, UserCircle } from 'lucide-react';
import { ImageWithFallback } from './ImageWithFallback';
import logoFortunaIJ from '../../imports/image-2.png';

type Module = 'productos' | 'ventas' | 'inventario' | 'tickets' | 'pedidos' | 'pqrs' | 'guia' | 'admin' | 'catalogo-sena' | 'catalogo-industrial' | 'perfil';

export const DashboardLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [carritoCount, setCarritoCount] = useState(0);

  useEffect(() => {
    const leer = () => {
      try {
        const items = JSON.parse(localStorage.getItem('carrito') || '[]');
        setCarritoCount(items.reduce((s: number, i: any) => s + (i.cantidad || 1), 0));
      } catch { setCarritoCount(0); }
    };
    leer();
    window.addEventListener('storage', leer);
    const interval = setInterval(leer, 1000);
    return () => { window.removeEventListener('storage', leer); clearInterval(interval); };
  }, []);

  const getRoleName = (role: string) => {
    switch (role) {
      case 'gerente_general':
        return 'Gerente General';
      case 'admin_inventario':
        return 'Administrador de Inventario';
      case 'subgerente':
        return 'Subgerente';
      case 'cliente':
        return 'Cliente';
      default:
        return role;
    }
  };

  const canAccess = (module: Module) => {
    if (module === 'perfil') return true; // todos pueden acceder a su perfil
    if (user?.role === 'gerente_general') return true;
    if (user?.role === 'subgerente') return !['admin', 'catalogo-sena', 'catalogo-industrial'].includes(module);
    if (user?.role === 'admin_inventario') return ['productos', 'inventario', 'tickets', 'pedidos', 'pqrs'].includes(module);
    if (user?.role === 'cliente') return ['productos', 'ventas', 'tickets', 'pedidos', 'pqrs', 'guia'].includes(module);
    return false;
  };

  const menuItems = [
    { id: 'admin' as Module, icon: Shield, label: 'Administración', path: '/dashboard/admin' },
    { id: 'catalogo-sena' as Module, icon: GraduationCap, label: 'Catálogo SENA', path: '/dashboard/catalogo-sena' },
    { id: 'catalogo-industrial' as Module, icon: HardHat, label: 'Catálogo Industrial', path: '/dashboard/catalogo-industrial' },
    { id: 'productos' as Module, icon: Package, label: 'Productos', path: '/dashboard/productos' },
    { id: 'ventas' as Module, icon: ShoppingCart, label: 'Ventas', path: '/dashboard/ventas' },
    { id: 'inventario' as Module, icon: Warehouse, label: 'Inventario', path: '/dashboard/inventario' },
    { id: 'pedidos' as Module, icon: ShoppingBag, label: 'Pedidos', path: '/dashboard/pedidos' },
    { id: 'tickets' as Module, icon: Receipt, label: 'Tickets', path: '/dashboard/tickets' },
    { id: 'pqrs' as Module, icon: MessageSquare, label: 'PQRS', path: '/dashboard/pqrs' },
    { id: 'guia' as Module, icon: BookOpen, label: 'Guía', path: '/dashboard/guia' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const currentModule = menuItems.find(item => location.pathname === item.path);

  return (
    <div className="h-screen flex bg-gradient-to-br from-black via-zinc-900 to-black overflow-hidden relative">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-yellow-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-yellow-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-0'} bg-zinc-900/80 backdrop-blur-xl border-r border-yellow-500/50 transition-all duration-300 overflow-hidden flex flex-col relative z-10 shadow-2xl shadow-yellow-500/10`}>
        <div className="p-6 border-b border-zinc-800/50">
          <div className="flex items-center justify-center mb-3">
            <ImageWithFallback
              src={logoFortunaIJ}
              alt="Dotaciones Fortuna IJ"
              className="h-16 w-auto"
            />
          </div>
          {/* User card — clickable → profile */}
          <button
            onClick={() => navigate('/dashboard/perfil')}
            className="w-full bg-zinc-800/50 hover:bg-zinc-800 p-3 rounded-lg border border-yellow-500/20 hover:border-yellow-500/50 transition-all text-left group"
          >
            <div className="flex items-center gap-2.5">
              {/* Avatar */}
              <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 border border-yellow-500/30">
                {user?.foto ? (
                  <img src={user.foto} alt="foto" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-black text-xs font-black">
                    {(user?.apodo || user?.nombre || '?').charAt(0).toUpperCase()}
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white font-semibold truncate">
                  {user?.apodo || user?.nombre}
                </p>
                <p className="text-xs text-yellow-500 truncate">{getRoleName(user?.role || '')}</p>
              </div>
              <UserCircle className="w-4 h-4 text-zinc-600 group-hover:text-yellow-500 transition-colors flex-shrink-0" />
            </div>
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.filter(item => canAccess(item.id)).map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-black shadow-lg shadow-yellow-500/30 scale-105'
                    : 'text-white hover:bg-zinc-800/50 hover:scale-105'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1">{item.label}</span>
                {item.id === 'ventas' && carritoCount > 0 && (
                  <span className={`text-xs font-black px-1.5 py-0.5 rounded-full min-w-5 text-center ${isActive ? 'bg-black/30 text-black' : 'bg-yellow-500 text-black'}`}>
                    {carritoCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-zinc-800">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Cerrar Sesión</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative z-10">
        {/* Header */}
        <header className="bg-zinc-900/80 backdrop-blur-xl border-b border-yellow-500/50 px-6 py-4 flex items-center justify-between shadow-lg shadow-yellow-500/5">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-yellow-500 hover:text-yellow-400 transition-colors"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-gray-400 hover:text-yellow-500 transition-colors"
              title="Ir a la página de inicio"
            >
              <Home className="w-5 h-5" />
              <span className="hidden md:inline">Inicio</span>
            </button>
          </div>

          <h2 className="text-xl text-white">
            {currentModule?.label || 'Dashboard'}
          </h2>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.history.back()}
              className="text-gray-400 hover:text-yellow-500 transition-colors p-2"
              title="Página anterior"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => window.history.forward()}
              className="text-gray-400 hover:text-yellow-500 transition-colors p-2"
              title="Página siguiente"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            {/* Profile avatar button */}
            <button
              onClick={() => navigate('/dashboard/perfil')}
              className="w-9 h-9 rounded-full overflow-hidden border-2 border-yellow-500/30 hover:border-yellow-500 transition-all hover:scale-110 flex-shrink-0"
              title="Mi perfil"
            >
              {user?.foto ? (
                <img src={user.foto} alt="perfil" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-black text-sm font-black">
                  {(user?.apodo || user?.nombre || '?').charAt(0).toUpperCase()}
                </div>
              )}
            </button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto bg-transparent p-6">
          <div className="animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
