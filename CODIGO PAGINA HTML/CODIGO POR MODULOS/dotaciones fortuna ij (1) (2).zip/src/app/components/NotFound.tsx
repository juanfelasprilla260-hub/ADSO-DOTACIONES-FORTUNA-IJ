import React from 'react';
import { useNavigate } from 'react-router';
import { SearchX, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './ImageWithFallback';
import logoFortunaIJ from '../../imports/image-2.png';

export const NotFound: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="text-center relative z-10 animate-fade-in">
        <div className="flex justify-center mb-6">
          <ImageWithFallback
            src={logoFortunaIJ}
            alt="Dotaciones Fortuna IJ"
            className="h-16 w-auto opacity-50"
          />
        </div>

        <div className="flex justify-center mb-8">
          <div className="bg-yellow-500/10 p-8 rounded-full border-4 border-yellow-500/50 shadow-2xl shadow-yellow-500/20 animate-bounce-slow">
            <SearchX className="w-24 h-24 text-yellow-500" />
          </div>
        </div>

        <h1 className="text-9xl font-bold mb-4 bg-gradient-to-r from-yellow-500 to-yellow-600 bg-clip-text text-transparent">
          404
        </h1>
        <h2 className="text-4xl text-white mb-4 font-bold">Página No Encontrada</h2>
        <p className="text-gray-400 text-xl mb-12 max-w-md mx-auto leading-relaxed">
          La página que buscas no existe o ha sido movida.
        </p>

        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black px-8 py-4 rounded-xl transition-all shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 hover:scale-105 font-semibold text-lg"
        >
          <ArrowLeft className="w-5 h-5" />
          Volver al Inicio
        </button>
      </div>
    </div>
  );
};
