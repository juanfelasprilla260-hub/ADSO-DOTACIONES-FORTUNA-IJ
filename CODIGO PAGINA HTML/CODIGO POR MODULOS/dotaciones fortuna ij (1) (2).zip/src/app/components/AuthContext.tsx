import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'gerente_general' | 'admin_inventario' | 'subgerente' | 'cliente';

export interface User {
  id: string;
  email: string;
  nombre: string;
  role: UserRole;
  codigoEmpleado?: string;
  activo?: boolean;
  // Perfil extendido
  foto?: string;        // base64 o URL
  apodo?: string;
  tipoId?: string;
  numeroId?: string;
  telefono?: string;
}

interface DatosExtra {
  tipoId?: string;
  numeroId?: string;
  telefono?: string;
}

export interface ProfileUpdate {
  nombre?: string;
  apodo?: string;
  telefono?: string;
  foto?: string;
  tipoId?: string;
  numeroId?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  register: (email: string, password: string, nombre: string, role: UserRole, codigoEmpleado?: string, extras?: DatosExtra) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
  validateCodigoEmpleado: (codigo: string, role: UserRole) => boolean;
  updateProfile: (data: ProfileUpdate) => boolean;
  changePassword: (currentPassword: string, newPassword: string) => { ok: boolean; error?: string };
}

// Superadmin fijo — nunca se almacena en localStorage, siempre disponible
const SUPERADMIN = {
  id: 'superadmin-gg',
  email: 'GG-2026DotacionesFortuna.IJ',
  password: 'GG123456',
  nombre: 'Gerente General',
  role: 'gerente_general' as UserRole,
  codigoEmpleado: 'GG-2026',
  activo: true,
};

// Clave para perfil del superadmin (almacena foto, apodo, etc.)
const SUPERADMIN_PROFILE_KEY = 'superadmin_profile';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth debe ser usado dentro de AuthProvider');
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const parsed = JSON.parse(storedUser);
      if (parsed.id === SUPERADMIN.id) {
        const { password: _, ...base } = SUPERADMIN;
        // Merge perfil personalizado del superadmin
        const profile = JSON.parse(localStorage.getItem(SUPERADMIN_PROFILE_KEY) || '{}');
        setUser({ ...base, ...profile });
      } else {
        setUser(parsed);
      }
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    if (email === SUPERADMIN.email && password === SUPERADMIN.password) {
      const { password: _, ...base } = SUPERADMIN;
      const profile = JSON.parse(localStorage.getItem(SUPERADMIN_PROFILE_KEY) || '{}');
      const u = { ...base, ...profile };
      setUser(u);
      localStorage.setItem('currentUser', JSON.stringify(u));
      return true;
    }
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const found = users.find((u: any) => u.email === email && u.password === password);
    if (found) {
      if (found.activo === false) return false;
      const { password: _p, ...pub } = found;
      setUser(pub);
      localStorage.setItem('currentUser', JSON.stringify(pub));
      return true;
    }
    return false;
  };

  const validateCodigoEmpleado = (codigo: string, role: UserRole): boolean => {
    const base: Record<UserRole, string[]> = {
      gerente_general:  ['GG-2024', 'GG-2025', 'GG-2026', 'ADMIN-001'],
      subgerente:       ['SG-2024', 'SG-2025', 'SUB-001', 'SUB-002'],
      admin_inventario: ['INV-2024', 'INV-2025', 'INV-001', 'INV-002', 'INV-003'],
      cliente:          [],
    };
    const custom = JSON.parse(localStorage.getItem('codigosPersonalizados') || '{}');
    return [...(base[role] || []), ...(custom[role] || [])].includes(codigo);
  };

  const register = (
    email: string, password: string, nombre: string,
    role: UserRole, codigoEmpleado?: string, extras?: DatosExtra
  ): boolean => {
    if (email === SUPERADMIN.email) return false;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.find((u: any) => u.email === email)) return false;
    if (role !== 'cliente') {
      if (!codigoEmpleado || !validateCodigoEmpleado(codigoEmpleado, role)) return false;
    }
    const newUser = {
      id: Date.now().toString(),
      email, password, nombre, role, activo: true,
      codigoEmpleado: role !== 'cliente' ? codigoEmpleado : undefined,
      ...(extras || {}),
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    return true;
  };

  const updateProfile = (data: ProfileUpdate): boolean => {
    if (!user) return false;
    const updated = { ...user, ...data };

    if (user.id === SUPERADMIN.id) {
      // El superadmin guarda su perfil por separado
      const { id, email, role, codigoEmpleado, activo, ...profileFields } = updated;
      localStorage.setItem(SUPERADMIN_PROFILE_KEY, JSON.stringify(profileFields));
      setUser(updated);
      localStorage.setItem('currentUser', JSON.stringify(updated));
      return true;
    }

    // Usuarios normales
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const idx = users.findIndex((u: any) => u.id === user.id);
    if (idx === -1) return false;
    users[idx] = { ...users[idx], ...data };
    localStorage.setItem('users', JSON.stringify(users));
    setUser(updated);
    localStorage.setItem('currentUser', JSON.stringify(updated));
    return true;
  };

  const changePassword = (currentPassword: string, newPassword: string): { ok: boolean; error?: string } => {
    if (!user) return { ok: false, error: 'No hay sesión activa' };
    if (newPassword.length < 6) return { ok: false, error: 'La nueva contraseña debe tener al menos 6 caracteres' };

    // Superadmin: contraseña fija, no se puede cambiar desde perfil
    if (user.id === SUPERADMIN.id) {
      if (currentPassword !== SUPERADMIN.password)
        return { ok: false, error: 'Contraseña actual incorrecta' };
      // En una app real se actualizaría el backend; aquí lo guardamos en un lugar separado
      localStorage.setItem('superadmin_password_override', newPassword);
      return { ok: true };
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const idx = users.findIndex((u: any) => u.id === user.id);
    if (idx === -1) return { ok: false, error: 'Usuario no encontrado' };
    if (users[idx].password !== currentPassword)
      return { ok: false, error: 'Contraseña actual incorrecta' };

    users[idx].password = newPassword;
    localStorage.setItem('users', JSON.stringify(users));
    return { ok: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated: !!user, validateCodigoEmpleado, updateProfile, changePassword }}>
      {children}
    </AuthContext.Provider>
  );
};
