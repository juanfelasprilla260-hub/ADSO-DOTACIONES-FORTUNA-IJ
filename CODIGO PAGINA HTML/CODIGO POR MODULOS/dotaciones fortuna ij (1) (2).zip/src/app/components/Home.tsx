import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from './AuthContext';
import { ImageWithFallback } from './ImageWithFallback';
import { DocumentTitle } from './DocumentTitle';
import senaUniformes from '../../imports/image.png';
import dotacionesIndustriales from '../../imports/image-3.png';
import uniformesVariados from '../../imports/image-4.png';
import equipoSeguridad from '../../imports/image-5.png';
import logoFortunaIJ from '../../imports/image-2.png';

interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;
  categoria: string;
  imagen: string;
  imagenUrl?: string;
}

const CATEGORIAS = [
  { nombre: 'Uniformes SENA',    imagen: senaUniformes,          count: 7  },
  { nombre: 'Ropa Industrial',   imagen: dotacionesIndustriales, count: 18 },
  { nombre: 'Vestuario Casual',  imagen: uniformesVariados,       count: 17 },
  { nombre: 'Calzado Seguridad', imagen: uniformesVariados,       count: 8  },
  { nombre: 'Seguridad',         imagen: equipoSeguridad,         count: 10 },
];

const SENA_LINEAS = [
  { nombre: 'Administrativo', emoji: '👔' },
  { nombre: 'Industrial',     emoji: '👷' },
  { nombre: 'Salud',          emoji: '⚕️' },
  { nombre: 'Gastronomía',    emoji: '👨‍🍳' },
  { nombre: 'Sistemas',       emoji: '💻' },
  { nombre: 'Agronomía',      emoji: '🌾' },
  { nombre: 'Belleza',        emoji: '💇' },
];

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [productos, setProductos] = useState<Producto[]>([]);

  useEffect(() => {
    if (isAuthenticated) navigate('/dashboard/productos');
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const stored = localStorage.getItem('productos');
    if (stored) {
      const all: Producto[] = JSON.parse(stored);
      const sena = all.filter(p => p.categoria === 'Uniformes SENA');
      const otros = all.filter(p => p.categoria !== 'Uniformes SENA');
      setProductos([...sena.slice(0, 3), ...otros.slice(0, 3)]);
    }
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <DocumentTitle title="Inicio" />

      {/* ── HEADER ── */}
      <header className="sticky top-0 z-50 bg-black/90 backdrop-blur-xl border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <img
            src={logoFortunaIJ}
            alt="Dotaciones Fortuna IJ"
            className="h-12 w-auto object-contain"
            onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <nav className="flex items-center gap-3">
            <button
              onClick={() => navigate('/nosotros')}
              className="text-gray-300 hover:text-white transition-colors text-sm font-medium px-3 py-2"
            >
              Nosotros
            </button>
            <button
              onClick={() => navigate('/login')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-5 py-2 rounded-lg text-sm transition-all hover:scale-105"
            >
              Iniciar Sesión
            </button>
            <button
              onClick={() => navigate('/register')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-5 py-2 rounded-lg text-sm transition-all hover:scale-105"
            >
              Registrarse
            </button>
          </nav>
        </div>
      </header>

      {/* ── HERO ── */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden">
        {/* Glow blobs */}
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-yellow-500/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-yellow-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-6 py-24">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-yellow-500/15 border border-yellow-500/30 text-yellow-400 text-sm font-semibold px-4 py-2 rounded-full mb-8">
            ✓ Vestimos tu trabajo, impulsamos tu empresa
          </div>

          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-black leading-tight mb-6">
            Dotaciones<br />
            <span className="text-yellow-500">Fortuna IJ</span>
          </h1>

          <p className="text-xl text-gray-400 max-w-xl mb-10 leading-relaxed">
            Dotaciones profesionales de calidad superior.<br />
            Uniformes, equipos de seguridad y todo lo que tu empresa necesita.
          </p>

          <div className="flex flex-wrap gap-4 mb-16">
            <button
              onClick={() => navigate('/register')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 shadow-lg shadow-yellow-500/30"
            >
              Conocer Ahora
            </button>
            <button
              onClick={() => navigate('/login')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 shadow-lg shadow-yellow-500/30"
            >
              Iniciar Sesión
            </button>
          </div>

          {/* Feature cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
            {[
              { title: 'Amplio Catálogo',       desc: 'Más de 100 productos disponibles.' },
              { title: 'Calidad Certificada',   desc: 'Materiales y acabados premium.'    },
              { title: 'Entrega Rápida',        desc: 'Despachos eficientes.'              },
            ].map(f => (
              <div key={f.title} className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 hover:border-yellow-500/40 transition-all">
                <h3 className="text-white font-bold mb-1">{f.title}</h3>
                <p className="text-gray-400 text-sm">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRODUCTOS ── */}
      <section className="py-20 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black text-white mb-3">Nuestros Productos</h2>
            <p className="text-gray-400 text-lg">Las mejores dotaciones para tu empresa</p>
          </div>

          {productos.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📦</div>
              <p className="text-gray-500">Cargando productos...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
              {productos.map(p => (
                <div key={p.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden hover:border-yellow-500/40 hover:shadow-xl hover:shadow-yellow-500/10 transition-all hover:-translate-y-1 group">
                  <div className="h-48 bg-zinc-800 overflow-hidden flex items-center justify-center">
                    {p.imagenUrl ? (
                      <ImageWithFallback src={p.imagenUrl} alt={p.nombre} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : (
                      <span className="text-5xl">{p.imagen}</span>
                    )}
                  </div>
                  <div className="p-5">
                    <p className="text-yellow-500 text-xs font-semibold uppercase tracking-wide mb-1">{p.categoria}</p>
                    <h3 className="text-white font-bold text-base mb-2 line-clamp-2">{p.nombre}</h3>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">{p.descripcion}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-yellow-500 text-xl font-black">${p.precio.toLocaleString('es-CO')}</span>
                      <button
                        onClick={() => navigate('/register')}
                        className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-4 py-2 rounded-lg text-sm transition-all hover:scale-105"
                      >
                        Ver más
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="text-center">
            <button
              onClick={() => navigate('/register')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 shadow-lg shadow-yellow-500/30"
            >
              Ver Todos los Productos
            </button>
          </div>
        </div>
      </section>

      {/* ── SENA ── */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black text-white mb-3">
              Uniformes del <span className="text-green-400">SENA</span>
            </h2>
            <p className="text-gray-400 text-lg">Uniformes certificados para todas las líneas de formación.</p>
          </div>

          {/* Main SENA image */}
          <div className="rounded-2xl overflow-hidden mb-10 max-h-72">
            <ImageWithFallback src={senaUniformes} alt="Uniformes SENA" className="w-full h-full object-cover" />
          </div>

          {/* Líneas grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-12">
            {SENA_LINEAS.map(linea => (
              <div
                key={linea.nombre}
                className="bg-zinc-900 border border-zinc-800 hover:border-green-500/40 rounded-xl p-4 text-center transition-all hover:scale-105 cursor-default"
              >
                <div className="text-3xl mb-2">{linea.emoji}</div>
                <p className="text-white text-xs font-semibold leading-tight">{linea.nombre}</p>
              </div>
            ))}
          </div>

          {/* Feature row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
            {[
              { title: 'Calidad Certificada', desc: 'Materiales duraderos.'      },
              { title: 'Diseño Oficial',      desc: 'Modelos institucionales.'   },
              { title: 'Entrega Rápida',      desc: 'Cobertura nacional.'        },
            ].map(f => (
              <div key={f.title} className="bg-zinc-900/80 border border-green-500/20 rounded-xl p-4 hover:border-green-500/50 transition-all">
                <h3 className="text-white font-bold mb-1">{f.title}</h3>
                <p className="text-gray-400 text-sm">{f.desc}</p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={() => navigate('/register')}
              className="bg-green-500 hover:bg-green-400 text-black font-bold px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 shadow-lg shadow-green-500/30"
            >
              Ver Catálogo SENA Completo
            </button>
          </div>
        </div>
      </section>

      {/* ── CATEGORÍAS ── */}
      <section className="py-20 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-black text-white text-center mb-12">Nuestras Categorías</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {CATEGORIAS.map(cat => (
              <div
                key={cat.nombre}
                className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden hover:border-yellow-500/40 hover:shadow-xl hover:shadow-yellow-500/10 transition-all hover:-translate-y-1 cursor-pointer group"
                onClick={() => navigate('/register')}
              >
                <div className="h-36 overflow-hidden">
                  <ImageWithFallback src={cat.imagen} alt={cat.nombre} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                </div>
                <div className="p-4">
                  <h3 className="text-white font-bold text-sm mb-1">{cat.nombre}</h3>
                  <span className="text-yellow-500 text-xs font-semibold">{cat.count} productos</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-24 bg-gradient-to-br from-zinc-900 via-black to-zinc-900 border-y border-yellow-500/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-yellow-500/5 pointer-events-none" />
        <div className="relative max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-4xl sm:text-5xl font-black text-white mb-4">
            ¿Listo para equipar tu empresa?
          </h2>
          <p className="text-gray-400 text-xl mb-10">
            Únete a miles de empresas que confían en nosotros.
          </p>
          <button
            onClick={() => navigate('/register')}
            className="bg-yellow-500 hover:bg-yellow-400 text-black font-black px-12 py-5 rounded-xl text-xl transition-all hover:scale-105 shadow-xl shadow-yellow-500/30"
          >
            Crear Cuenta
          </button>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="bg-black border-t border-zinc-800 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-10">
            {/* Mapa */}
            <div className="rounded-2xl overflow-hidden h-56">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15907.852707168846!2d-74.114137!3d4.6006184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f996bf35afae5%3A0xc7ce950475538f58!2sAlkosto%20Carrera%2030!5e0!3m2!1ses-419!2sco!4v1782314845501!5m2!1ses-419!2sco"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="strict-origin-when-cross-origin"
                title="Ubicación Dotaciones Fortuna IJ"
              />
            </div>

            {/* Info */}
            <div className="space-y-4">
              <img src={logoFortunaIJ} alt="Dotaciones Fortuna IJ" className="h-16 w-auto object-contain mb-4"
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
              <p className="text-yellow-400 font-bold text-lg">Vestimos tu trabajo, impulsamos tu empresa</p>
              <div className="space-y-2 text-gray-400 text-sm">
                <p>📞 312 388 8729 — 313 851 6917</p>
                <p>📍 Cra 63 No. 22 - 22 sur</p>
                <p>✉️ dotacionesfortunaij@gmail.com</p>
                <p>📱 @dotacionesfortunaij</p>
              </div>
            </div>
          </div>

          <div className="border-t border-zinc-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-600 text-sm">© 2026 Dotaciones Fortuna IJ. Todos los derechos reservados.</p>
            <div className="flex gap-4">
              <button onClick={() => navigate('/nosotros')} className="text-gray-500 hover:text-yellow-400 text-sm transition-colors">Nosotros</button>
              <button onClick={() => navigate('/login')} className="text-gray-500 hover:text-yellow-400 text-sm transition-colors">Iniciar Sesión</button>
              <button onClick={() => navigate('/register')} className="text-gray-500 hover:text-yellow-400 text-sm transition-colors">Registrarse</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
