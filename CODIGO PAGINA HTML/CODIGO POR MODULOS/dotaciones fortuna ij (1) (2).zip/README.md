
  # dotaciones fortuna ij

  This is a code bundle for dotaciones fortuna ij. The original project is available at https://www.figma.com/design/Kw49RM1hx0Pfjz8zKFrM2N/dotaciones-fortuna-ij.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  