let pqrs =
JSON.parse(localStorage.getItem("pqrs")) || [];

const modal =
document.getElementById("modal");

const tabla =
document.getElementById("tablaPQRS");

document
.getElementById("btnNuevaPQRS")
.onclick=()=>{

modal.style.display="block";

};

document
.getElementById("cerrarModal")
.onclick=()=>{

modal.style.display="none";

};

document
.getElementById("modo")
.addEventListener("change",function(){

document
.getElementById("datosUsuario")
.style.display=
this.value==="usuario"
?
"block"
:
"none";

});

document
.getElementById("formPQRS")
.addEventListener("submit",function(e){

e.preventDefault();

let registro={

id:Date.now(),

tipo:
document.getElementById("tipo").value,

usuario:
document.getElementById("modo").value==="anonimo"
?
"Anónimo"
:
document.getElementById("nombre").value,

correo:
document.getElementById("correo").value,

asunto:
document.getElementById("asunto").value,

descripcion:
document.getElementById("descripcion").value,

estado:"Pendiente",

fecha:
new Date().toLocaleDateString()

};

pqrs.push(registro);

guardar();

this.reset();

modal.style.display="none";

});

function guardar(){

localStorage.setItem(
"pqrs",
JSON.stringify(pqrs)
);

render();

}

function render(){

tabla.innerHTML="";

let busqueda=
document.getElementById("buscar").value
.toLowerCase();

let estadoFiltro=
document.getElementById("filtroEstado").value;

let datos=
pqrs.filter(item=>{

let cumpleBusqueda=
item.asunto
.toLowerCase()
.includes(busqueda);

let cumpleEstado=
estadoFiltro===""
||
item.estado===estadoFiltro;

return cumpleBusqueda
&&
cumpleEstado;

});

datos.forEach((item,index)=>{

tabla.innerHTML+=`

<tr>

<td>${item.id}</td>

<td>${item.tipo}</td>

<td>${item.usuario}</td>

<td>${item.asunto}</td>

<td>${item.estado}</td>

<td>${item.fecha}</td>

<td>

<button
class="editar"
onclick="editar(${index})">
Editar
</button>

<button
class="estado"
onclick="cambiarEstado(${index})">
Estado
</button>

<button
class="eliminar"
onclick="eliminarPQRS(${index})">
Eliminar
</button>

</td>

</tr>

`;

});

actualizarDashboard();

}

function editar(index){

let nuevo=
prompt(
"Editar asunto",
pqrs[index].asunto
);

if(nuevo){

pqrs[index].asunto=nuevo;

guardar();

}

}

function eliminarPQRS(index){

if(confirm("¿Eliminar PQRS?")){

pqrs.splice(index,1);

guardar();

}

}

function cambiarEstado(index){

let estados=[
"Pendiente",
"En Proceso",
"Resuelta"
];

let actual=
estados.indexOf(
pqrs[index].estado
);

actual++;

if(actual>=estados.length){

actual=0;

}

pqrs[index].estado=
estados[actual];

guardar();

}

function actualizarDashboard(){

document.getElementById("totalPQRS")
.innerText=pqrs.length;

document.getElementById("pendientes")
.innerText=
pqrs.filter(x=>
x.estado==="Pendiente"
).length;

document.getElementById("proceso")
.innerText=
pqrs.filter(x=>
x.estado==="En Proceso"
).length;

document.getElementById("resueltas")
.innerText=
pqrs.filter(x=>
x.estado==="Resuelta"
).length;

}

document
.getElementById("buscar")
.addEventListener("keyup",render);

document
.getElementById("filtroEstado")
.addEventListener("change",render);

render();